package com.example.autotpa;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_476;
import net.minecraft.class_742;

public class AhSniperManager {

    public static boolean isSniperEnabled = false;

    private enum SniperState {
        IDLE, NEXT_QUERY, WAIT_MENU, ANALYZE_PAGE,
        BUY_ITEM, WAIT_CONFIRM, CLICK_CONFIRM, WAIT_REFRESH,
        FIND_NEXT_SELL_ITEM, PRICE_CHECK_SEND, PRICE_CHECK_WAIT, PRICE_CHECK_READ,
        SELL_ITEM_DIRECTLY, WAIT_SELL_DELAY
    }

    private static SniperState state = SniperState.IDLE;
    private static int delayTicks = 0;

    // Список базовых фильтров для монополизации
    private static final String[] SNIPER_QUERIES = {
            "neth helmet protection 4 unbreaking 3 mending",
            "neth chestplate protection 4 unbreaking 3 mending",
            "neth leggings protection 4 unbreaking 3 mending",
            "neth boots protection 4 unbreaking 3 mending",
            "neth leggings blast protection 4 unbreaking 3 mending",
            "neth boots blast protection 4 unbreaking 3 mending"
    };

    private static int queryIndex = 0;
    
    // Переменные для перепродажи
    private static double currentBuyPrice = 0.0;
    private static double targetSellPrice = 0.0;
    private static int itemsToBuy = 0;

    // Переменные для проверки экстра-чаров
    private static int currentSellSlot = -1;
    private static double dynamicSellPrice = 0.0;
    private static String currentSpecificQuery = "";

    public static void startSniper() {
        isSniperEnabled = true;
        state = SniperState.NEXT_QUERY;
        queryIndex = 0;
        delayTicks = 0;
        Autotpa.sendFeedback("§6[AH Снайпер] §eАлгоритм монополизации рынка запущен!");
    }

    public static void stopSniper() {
        isSniperEnabled = false;
        state = SniperState.IDLE;
        Autotpa.sendFeedback("§c[AH Снайпер] Остановлен.");
    }

    public static void tick(class_310 client) {
        if (!isSniperEnabled || client.field_1724 == null || client.field_1687 == null) return;

        // --- 1. АНТИ-ПАЛЕВО (РАДАР 50 БЛОКОВ) ---
        for (class_742 player : client.field_1687.method_18456()) {
            if (player == client.field_1724) continue;
            String name = player.method_5477().getString();
            
            if (name.equalsIgnoreCase("G0tou") || name.equalsIgnoreCase("itzNatsuu")) continue;

            if (client.field_1724.method_5739(player) <= 50.0) {
                Autotpa.sendFeedback("§4§l[ТРЕВОГА] §cИгрок §e" + name + " §cближе 50 блоков! Экстренный /rtp...");
                if (client.field_1755 != null) client.field_1724.method_7346();
                CommandQueue.send("rtp");
                
                state = SniperState.NEXT_QUERY;
                delayTicks = 300; // Пауза 15 сек
                return;
            }
        }

        if (delayTicks > 0) {
            delayTicks--;
            return;
        }

        switch (state) {
            case IDLE -> { }

            case NEXT_QUERY -> {
                if (client.field_1755 != null) client.field_1724.method_7346();
                
                String query = SNIPER_QUERIES[queryIndex];
                CommandQueue.send("ah " + query);
                
                queryIndex++;
                if (queryIndex >= SNIPER_QUERIES.length) queryIndex = 0;

                state = SniperState.WAIT_MENU;
                delayTicks = 15;
            }

            case WAIT_MENU -> {
                if (client.field_1755 instanceof class_476) {
                    state = SniperState.ANALYZE_PAGE;
                    delayTicks = 5;
                } else {
                    state = SniperState.NEXT_QUERY;
                    delayTicks = 20;
                }
            }

            case ANALYZE_PAGE -> {
                if (!(client.field_1755 instanceof class_476 screen)) {
                    state = SniperState.NEXT_QUERY;
                    return;
                }

                int slotsCount = screen.method_17577().field_7761.size();
                double priceA = 0; 
                int countA = 0;    
                double priceB = 0; 

                for (int i = 0; i < Math.min(slotsCount, 45); i++) {
                    class_1799 stack = screen.method_17577().method_7611(i).method_7677();
                    if (stack.method_7960()) continue;

                    double price = AutoSellManager.getItemPrice(client, stack);
                    if (price <= 0) continue;

                    if (priceA == 0) {
                        priceA = price; 
                        countA = 1;
                    } else if (price == priceA) {
                        countA++; 
                    } else if (price > priceA) {
                        priceB = price; 
                        break;
                    }
                }

                if (priceA > 0 && priceB > priceA && countA <= 6) {
                    currentBuyPrice = priceA;
                    targetSellPrice = priceB;
                    itemsToBuy = countA;
                    
                    Autotpa.sendFeedback("§a[AH Снайпер] Найдено " + countA + " лотов по §e" + AutoSellManager.formatPrice(priceA) + "§a. Следующая: §b" + AutoSellManager.formatPrice(priceB) + "§a. ВЫКУПАЕМ!");
                    state = SniperState.BUY_ITEM;
                    delayTicks = 5;
                } else {
                    client.field_1724.method_7346();
                    state = SniperState.NEXT_QUERY;
                    delayTicks = 20;
                }
            }

            case BUY_ITEM -> {
                if (!(client.field_1755 instanceof class_476 screen)) {
                    state = SniperState.FIND_NEXT_SELL_ITEM;
                    return;
                }

                if (itemsToBuy <= 0) {
                    client.field_1724.method_7346();
                    state = SniperState.FIND_NEXT_SELL_ITEM;
                    delayTicks = 10;
                    return;
                }

                class_1799 slot0 = screen.method_17577().method_7611(0).method_7677();
                if (slot0.method_7960()) {
                    client.field_1724.method_7346();
                    state = SniperState.FIND_NEXT_SELL_ITEM;
                    return;
                }

                double currentSlotPrice = AutoSellManager.getItemPrice(client, slot0);
                if (currentSlotPrice == currentBuyPrice) {
                    client.field_1761.method_2906(screen.method_17577().field_7763, 0, 0, class_1713.field_7790, client.field_1724);
                    state = SniperState.WAIT_CONFIRM;
                    delayTicks = 5;
                } else {
                    Autotpa.sendFeedback("§c[AH Снайпер] Цена изменилась! Отмена покупки.");
                    client.field_1724.method_7346();
                    state = SniperState.FIND_NEXT_SELL_ITEM;
                    delayTicks = 10;
                }
            }

            case WAIT_CONFIRM -> {
                if (client.field_1755 instanceof class_476 screen) {
                    String title = Autotpa.cleanText(screen.method_25440().getString()).toLowerCase();
                    if (title.contains("confirm") || title.contains("подтверд") || title.contains("buy") || title.contains("купить")) {
                        state = SniperState.CLICK_CONFIRM;
                        delayTicks = 3;
                    } else {
                        state = SniperState.WAIT_REFRESH;
                        delayTicks = 10;
                    }
                }
            }

            case CLICK_CONFIRM -> {
                if (client.field_1755 instanceof class_476 screen) {
                    for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                        class_1799 s = screen.method_17577().method_7611(i).method_7677();
                        if (s.method_7909() == class_1802.field_8656 || s.method_7909() == class_1802.field_19057 || s.method_7909() == class_1802.field_8798) {
                            client.field_1761.method_2906(screen.method_17577().field_7763, i, 0, class_1713.field_7790, client.field_1724);
                            break;
                        }
                    }
                    itemsToBuy--;
                    state = SniperState.WAIT_REFRESH;
                    delayTicks = 15;
                }
            }

            case WAIT_REFRESH -> {
                if (client.field_1755 instanceof class_476) {
                    state = SniperState.BUY_ITEM;
                    delayTicks = 5;
                } else {
                    state = SniperState.FIND_NEXT_SELL_ITEM;
                    delayTicks = 10;
                }
            }

            // --- ПОИСК КУПЛЕННЫХ ВЕЩЕЙ И ПРОВЕРКА ЭКСТРА-ЧАРОВ ---
            case FIND_NEXT_SELL_ITEM -> {
                if (client.field_1755 != null) client.field_1724.method_7346();
                currentSellSlot = -1;

                // Ищем незеритку в рюкзаке
                for (int i = 9; i <= 35; i++) {
                    class_1799 s = client.field_1724.method_31548().method_5438(i);
                    if (s.method_7960()) continue;
                    String name = s.method_7909().toString().toLowerCase();
                    if (name.contains("netherite_helmet") || name.contains("netherite_chestplate") 
                            || name.contains("netherite_leggings") || name.contains("netherite_boots")) {
                        currentSellSlot = i;
                        break;
                    }
                }

                if (currentSellSlot == -1) {
                    // Всё продали, идем к следующему поиску
                    state = SniperState.NEXT_QUERY;
                    delayTicks = 30;
                    return;
                }

                class_1799 stackToSell = client.field_1724.method_31548().method_5438(currentSellSlot);
                
                // Проверяем, есть ли God-Enchants
                if (hasExtraMaxEnchants(stackToSell)) {
                    currentSpecificQuery = AutoSellManager.buildAhSearchQuery(stackToSell);
                    state = SniperState.PRICE_CHECK_SEND;
                    delayTicks = 5;
                } else {
                    dynamicSellPrice = targetSellPrice;
                    state = SniperState.SELL_ITEM_DIRECTLY;
                    delayTicks = 5;
                }
            }

            // --- ПРОВЕРКА ЦЕНЫ ДЛЯ GOD-TIER ВЕЩЕЙ ---
            case PRICE_CHECK_SEND -> {
                CommandQueue.send("ah " + currentSpecificQuery);
                Autotpa.sendFeedback("§d[AH Снайпер] Обнаружены Топ-Чары! Проверка рынка: §e/ah " + currentSpecificQuery);
                state = SniperState.PRICE_CHECK_WAIT;
                delayTicks = 15;
            }

            case PRICE_CHECK_WAIT -> {
                if (client.field_1755 instanceof class_476) {
                    state = SniperState.PRICE_CHECK_READ;
                    delayTicks = 5;
                } else {
                    dynamicSellPrice = targetSellPrice;
                    state = SniperState.SELL_ITEM_DIRECTLY;
                    delayTicks = 5;
                }
            }

            case PRICE_CHECK_READ -> {
                if (client.field_1755 instanceof class_476 screen) {
                    class_1799 slot0 = screen.method_17577().method_7611(0).method_7677();
                    double lowestPrice = 0;
                    if (!slot0.method_7960()) {
                        lowestPrice = AutoSellManager.getItemPrice(client, slot0);
                    }

                    if (lowestPrice > 0) {
                        // Перебиваем цену на 100k, но не падаем ниже оригинальной цены перепродажи!
                        dynamicSellPrice = Math.max(targetSellPrice, lowestPrice - 100_000.0);
                        Autotpa.sendFeedback("§a[AH Снайпер] Конкурент найден: §e" + AutoSellManager.formatPrice(lowestPrice) + "§a. Продаем за §b" + AutoSellManager.formatPrice(dynamicSellPrice));
                    } else {
                        // Эксклюзив (на аукционе таких нет) -> накидываем +2 миллиона сверху!
                        dynamicSellPrice = targetSellPrice + 2_000_000.0;
                        Autotpa.sendFeedback("§d[AH Снайпер] ЭКСКЛЮЗИВНЫЕ ЧАРЫ! Конкурентов нет, продаем за §b" + AutoSellManager.formatPrice(dynamicSellPrice));
                    }

                    client.field_1724.method_7346();
                    state = SniperState.SELL_ITEM_DIRECTLY;
                    delayTicks = 10;
                } else {
                    state = SniperState.SELL_ITEM_DIRECTLY;
                }
            }

            // --- ВЫСТАВЛЕНИЕ ПРЕДМЕТА НА ПРОДАЖУ ---
            case SELL_ITEM_DIRECTLY -> {
                int syncId = client.field_1724.field_7498.field_7763;
                // Берем вещь в руку
                client.field_1761.method_2906(syncId, currentSellSlot, 0, class_1713.field_7791, client.field_1724);
                
                CommandQueue.send("ah sell " + AutoSellManager.formatPrice(dynamicSellPrice));
                Autotpa.sendFeedback("§e[AH Снайпер] Перепродажа: лот выставлен за §b" + AutoSellManager.formatPrice(dynamicSellPrice) + "!");
                
                state = SniperState.WAIT_SELL_DELAY;
                delayTicks = 15;
            }

            case WAIT_SELL_DELAY -> {
                // Убираем вещь обратно в инвентарь (или возвращаем меч на место)
                client.field_1761.method_2906(client.field_1724.field_7498.field_7763, currentSellSlot, 0, class_1713.field_7791, client.field_1724);
                
                state = SniperState.FIND_NEXT_SELL_ITEM;
                delayTicks = 10;
            }
        }
    }

    // --- ПРОВЕРКА НА GOD ENCHANTS ---
    private static boolean hasExtraMaxEnchants(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        String query = AutoSellManager.buildAhSearchQuery(stack).toLowerCase();
        
        return query.contains("thorns 3") || 
               query.contains("swift sneak 3") || 
               query.contains("soul speed 3") || 
               query.contains("depth strider 3") || 
               query.contains("respiration 3");
    }
}
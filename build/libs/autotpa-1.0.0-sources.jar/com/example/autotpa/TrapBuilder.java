package com.example.autotpa;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class TrapBuilder {
    private enum State {
        IDLE, WAITING_RTP, FIND_FLAT_LAND, WALK_TO_SPOT, EQUIP_PICKAXE,
        DIG_TO_BOTTOM, MINE_FLOOR_B2, PLACE_FLOOR_B2, STEP_ONTO_B2,
        MINE_FLOOR_B1, PLACE_FLOOR_B1, PLACE_ROOF, BUILD_WALLS, PLACE_COBWEBS, SET_HOME, WAIT_HOME_SEQUENCE
    }

    private static State currentState = State.IDLE;
    private static int delayTicks = 0;
    private static int airConfirmTicks = 0;
    public static boolean needsRebuildAfterShop = false;
    
    private static double rtpStartX = 0, rtpStartZ = 0;
    private static int rtpTimeoutTicks = 0;

    private static class_2338 b1;
    private static class_2338 b2;
    private static final List<class_2338> blocksToDig = new ArrayList<>();
    private static final List<class_2338> wallsToBuild = new ArrayList<>();
    
    public static void init(File configDir) {}

    public static void start(class_310 client) {
        if (client.field_1724 == null) return;
        Autotpa.currentBotState = Autotpa.BotState.TRAP_BUILDING;
        CombatManager.releaseControls(client);
        
        int obsCount = countTotalItem(client, class_1802.field_8281);
        int webCount = countTotalItem(client, class_1802.field_8786);
        boolean hasPick = hasAnyPickaxe(client);

        if (!hasPick || obsCount < 16 || webCount < 2) {
            Autotpa.sendFeedback("§e[Builder] Не хватает ресурсов (Кирка/Обсидиан/Паутина)! Закупка в /shop...");
            needsRebuildAfterShop = true;
            AutoSellManager.startAutoSell(client);
            return;
        }

        rtpStartX = client.field_1724.method_23317();
        rtpStartZ = client.field_1724.method_23321();
        rtpTimeoutTicks = 300;
        delayTicks = 0;
        airConfirmTicks = 0;

        CommandQueue.send("rtp");
        currentState = State.WAITING_RTP;
        Autotpa.sendFeedback("§e[Builder] Отправлен /rtp. Ищу безопасную точку для постройки...");
    }

    public static void tick(class_310 client) {
        if (currentState == State.IDLE || client.field_1724 == null || client.field_1687 == null) return;

        if (delayTicks > 0) {
            delayTicks--;
            return;
        }

        switch (currentState) {
            case WAITING_RTP -> {
                double dx = client.field_1724.method_23317() - rtpStartX;
                double dz = client.field_1724.method_23321() - rtpStartZ;
                double movedDist = Math.sqrt(dx * dx + dz * dz);

                if (movedDist > 50.0) {
                    Autotpa.sendFeedback("§a[Builder] Телепортация успешна! Проверяю местность...");
                    currentState = State.FIND_FLAT_LAND;
                    delayTicks = 30;
                    return;
                }

                if (rtpTimeoutTicks > 0) {
                    rtpTimeoutTicks--;
                } else {
                    Autotpa.sendFeedback("§e[Builder] Повторяю команду /rtp...");
                    rtpStartX = client.field_1724.method_23317();
                    rtpStartZ = client.field_1724.method_23321();
                    rtpTimeoutTicks = 300;
                    CommandQueue.send("rtp");
                }
            }

            case FIND_FLAT_LAND -> {
                class_2338 p = client.field_1724.method_24515();
                
                boolean inLiquid = client.field_1687.method_8320(p).method_27852(class_2246.field_10382) 
                        || client.field_1687.method_8320(p.method_10074()).method_27852(class_2246.field_10382)
                        || client.field_1687.method_8320(p).method_27852(class_2246.field_10164)
                        || client.field_1687.method_8320(p.method_10074()).method_27852(class_2246.field_10164);

                if (inLiquid) {
                    triggerNewRtp(client);
                    return;
                }

                class_2338 safeSpot = findFlatSolidSpot(client);
                if (safeSpot != null) {
                    setupBlueprint(client, safeSpot);
                    currentState = State.WALK_TO_SPOT;
                    delayTicks = 5;
                } else {
                    triggerNewRtp(client);
                }
            }

            case WALK_TO_SPOT -> {
                class_243 target = class_243.method_24955(b1.method_10084());
                double dx = target.field_1352 - client.field_1724.method_23317();
                double dz = target.field_1350 - client.field_1724.method_23321();
                double dist = Math.sqrt(dx * dx + dz * dz);

                if (dist < 0.3) {
                    client.field_1690.field_1894.method_23481(false);
                    client.field_1690.field_1903.method_23481(false);
                    Autotpa.sendFeedback("§a[Builder] Встал на точку. Достаю кирку...");
                    currentState = State.EQUIP_PICKAXE;
                    delayTicks = 5;
                } else {
                    float moveYaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                    client.field_1724.method_36456(moveYaw);
                    client.field_1724.method_36457(0);
                    client.field_1690.field_1894.method_23481(true);

                    if (client.field_1724.field_5976 || target.field_1351 > client.field_1724.method_23318() + 0.5) {
                        client.field_1690.field_1903.method_23481(true);
                    } else {
                        client.field_1690.field_1903.method_23481(false);
                    }
                }
            }

            case EQUIP_PICKAXE -> {
                int pickSlot = ensurePickaxeInHotbar(client);
                if (pickSlot != -1) {
                    client.field_1724.method_31548().method_61496(pickSlot);
                    currentState = State.DIG_TO_BOTTOM;
                    airConfirmTicks = 0;
                } else {
                    Autotpa.sendFeedback("§c[Builder] Кирка не найдена! Иду в /shop...");
                    needsRebuildAfterShop = true;
                    AutoSellManager.startAutoSell(client);
                    reset();
                }
            }

            // 1. УМНОЕ КОПАНИЕ ЯМЫ (Без списков: проверяет с 1-го до 6-го блока каждый тик!)
            case DIG_TO_BOTTOM -> {
                class_2338 target = null;
                // Ищем первый несломанный блок строго сверху вниз
                for (class_2338 p : blocksToDig) {
                    if (!client.field_1687.method_8320(p).method_26215()) {
                        target = p;
                        break;
                    }
                }

                if (target == null) {
                    // Все 6 блоков ямы стали воздухом! Ждем 5 тиков контрольной проверки.
                    airConfirmTicks++;
                    if (airConfirmTicks >= 5) {
                        BlockInteractionHelper.stopBreaking(client);
                        currentState = State.MINE_FLOOR_B2;
                        airConfirmTicks = 0;
                        delayTicks = 2;
                    }
                } else {
                    // Если блок вернулся из-за отката — цикл сам найдет его и начнет копать заново!
                    airConfirmTicks = 0;
                    BlockInteractionHelper.breakBlockLegit(client, target);
                }
            }

            case MINE_FLOOR_B2 -> {
                class_2338 floorB2 = b2.method_10087(3);
                if (client.field_1687.method_8320(floorB2).method_26215()) {
                    airConfirmTicks++;
                    if (airConfirmTicks >= 5) {
                        BlockInteractionHelper.stopBreaking(client);
                        currentState = State.PLACE_FLOOR_B2;
                        airConfirmTicks = 0;
                        delayTicks = 2;
                    }
                } else {
                    airConfirmTicks = 0;
                    BlockInteractionHelper.breakBlockLegit(client, floorB2);
                }
            }

            case PLACE_FLOOR_B2 -> {
                class_2338 floorB2 = b2.method_10087(3);
                class_2680 state = client.field_1687.method_8320(floorB2);

                if (state.method_27852(class_2246.field_10540)) {
                    currentState = State.STEP_ONTO_B2;
                    delayTicks = 3;
                } else if (!state.method_26215()) {
                    currentState = State.MINE_FLOOR_B2;
                    delayTicks = 2;
                } else {
                    BlockInteractionHelper.placeBlockLegit(client, floorB2, class_1802.field_8281);
                    delayTicks = 5;
                }
            }

            case STEP_ONTO_B2 -> {
                class_243 target = class_243.method_24955(b2.method_10087(2));
                double dx = target.field_1352 - client.field_1724.method_23317();
                double dz = target.field_1350 - client.field_1724.method_23321();
                double dist = Math.sqrt(dx * dx + dz * dz);

                if (dist < 0.25) {
                    client.field_1690.field_1894.method_23481(false);
                    currentState = State.MINE_FLOOR_B1;
                    airConfirmTicks = 0;
                    delayTicks = 3;
                } else {
                    float moveYaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                    client.field_1724.method_36456(moveYaw);
                    client.field_1690.field_1894.method_23481(true);
                }
            }

            case MINE_FLOOR_B1 -> {
                class_2338 floorB1 = b1.method_10087(3);
                if (client.field_1687.method_8320(floorB1).method_26215()) {
                    airConfirmTicks++;
                    if (airConfirmTicks >= 5) {
                        BlockInteractionHelper.stopBreaking(client);
                        currentState = State.PLACE_FLOOR_B1;
                        airConfirmTicks = 0;
                        delayTicks = 2;
                    }
                } else {
                    airConfirmTicks = 0;
                    BlockInteractionHelper.breakBlockLegit(client, floorB1);
                }
            }

            case PLACE_FLOOR_B1 -> {
                class_2338 floorB1 = b1.method_10087(3);
                class_2680 state = client.field_1687.method_8320(floorB1);

                if (state.method_27852(class_2246.field_10540)) {
                    currentState = State.PLACE_ROOF;
                    delayTicks = 3;
                } else if (!state.method_26215()) {
                    currentState = State.MINE_FLOOR_B1;
                    delayTicks = 2;
                } else {
                    BlockInteractionHelper.placeBlockLegit(client, floorB1, class_1802.field_8281);
                    delayTicks = 5;
                }
            }

            case PLACE_ROOF -> {
                boolean b1Placed = client.field_1687.method_8320(b1.method_10084()).method_27852(class_2246.field_10540);
                boolean b2Placed = client.field_1687.method_8320(b2.method_10084()).method_27852(class_2246.field_10540);

                if (b1Placed && b2Placed) {
                    currentState = State.BUILD_WALLS;
                    delayTicks = 3;
                    return;
                }

                if (!b1Placed) {
                    BlockInteractionHelper.placeBlockLegit(client, b1.method_10084(), class_1802.field_8281);
                    delayTicks = 5;
                    return;
                }

                if (!b2Placed) {
                    BlockInteractionHelper.placeBlockLegit(client, b2.method_10084(), class_1802.field_8281);
                    delayTicks = 5;
                }
            }

            // 8. УМНАЯ ПОСТРОЙКА СТЕН (Без списков: проверяет по кругу, пока все не станут обсидианом!)
            case BUILD_WALLS -> {
                class_2338 targetWall = null;
                for (class_2338 wp : wallsToBuild) {
                    if (!client.field_1687.method_8320(wp).method_27852(class_2246.field_10540)) {
                        targetWall = wp;
                        break;
                    }
                }

                if (targetWall == null) {
                    BlockInteractionHelper.stopBreaking(client);
                    currentState = State.PLACE_COBWEBS;
                    delayTicks = 4;
                    return;
                }

                class_2680 state = client.field_1687.method_8320(targetWall);
                if (!state.method_26215()) {
                    BlockInteractionHelper.breakBlockLegit(client, targetWall);
                } else {
                    BlockInteractionHelper.stopBreaking(client);
                    BlockInteractionHelper.placeBlockLegit(client, targetWall, class_1802.field_8281);
                    delayTicks = 5;
                }
            }

            case PLACE_COBWEBS -> {
                class_2338 web1 = b1.method_10087(2);
                class_2338 web2 = b2.method_10087(2);

                boolean web1Placed = client.field_1687.method_8320(web1).method_27852(class_2246.field_10343);
                boolean web2Placed = client.field_1687.method_8320(web2).method_27852(class_2246.field_10343);

                if (web1Placed && web2Placed) {
                    currentState = State.SET_HOME;
                    delayTicks = 5;
                    return;
                }

                if (!web1Placed) {
                    BlockInteractionHelper.placeBlockLegit(client, web1, class_1802.field_8786);
                    delayTicks = 5;
                    return;
                }

                if (!web2Placed) {
                    BlockInteractionHelper.placeBlockLegit(client, web2, class_1802.field_8786);
                    delayTicks = 5;
                }
            }

            case SET_HOME -> {
                CombatManager.saveTrap(client);
                HomeSequence.startSequence(client);
                currentState = State.WAIT_HOME_SEQUENCE;
                delayTicks = 10;
            }

            case WAIT_HOME_SEQUENCE -> {
                if (HomeSequence.isIdle()) {
                    currentState = State.IDLE;
                    Autotpa.currentBotState = Autotpa.BotState.IDLE_TRAPPING;
                    Autotpa.sendFeedback("§a[Builder] Ловушка успешно построена и проверена! Дом 1 установлен.");
                } else {
                    delayTicks = 5;
                }
            }
        }
    }

    private static int ensurePickaxeInHotbar(class_310 client) {
        if (client.field_1724 == null) return -1;
        for (int i = 0; i < 9; i++) {
            String name = client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase();
            if (name.contains("pickaxe")) return i;
        }
        for (int i = 9; i <= 35; i++) {
            String name = client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase();
            if (name.contains("pickaxe")) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, 7, class_1713.field_7791, client.field_1724);
                return 7;
            }
        }
        return -1;
    }

    private static boolean hasAnyPickaxe(class_310 client) {
        if (client.field_1724 == null) return false;
        for (int i = 0; i <= 35; i++) {
            String name = client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase();
            if (name.contains("pickaxe")) return true;
        }
        return false;
    }

    private static int countTotalItem(class_310 client, net.minecraft.class_1792 item) {
        if (client.field_1724 == null) return 0;
        int total = 0;
        for (int i = 0; i <= 35; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(item)) total += stack.method_7947();
        }
        return total;
    }

    private static void triggerNewRtp(class_310 client) {
        rtpStartX = client.field_1724.method_23317();
        rtpStartZ = client.field_1724.method_23321();
        rtpTimeoutTicks = 300;
        CommandQueue.send("rtp");
        currentState = State.WAITING_RTP;
        delayTicks = 20;
    }

    private static class_2338 findFlatSolidSpot(class_310 client) {
        class_2338 playerPos = client.field_1724.method_24515();
        class_2350 facing = client.field_1724.method_5735();

        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                class_2338 candidate1 = playerPos.method_10069(x, -1, z);
                class_2338 candidate2 = candidate1.method_10093(facing);

                if (isTerrainSuitable(client, candidate1) && isTerrainSuitable(client, candidate2)) {
                    return candidate1;
                }
            }
        }
        return null;
    }

    private static boolean isTerrainSuitable(class_310 client, class_2338 pos) {
        if (client.field_1687 == null) return false;

        for (int dy = 1; dy <= 3; dy++) {
            if (!client.field_1687.method_8320(pos.method_10086(dy)).method_26215()) return false;
        }

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy <= 5; dy++) {
                    class_2338 check = pos.method_10069(dx, -dy, dz);
                    class_2680 bs = client.field_1687.method_8320(check);
                    class_2248 b = bs.method_26204();

                    if (b instanceof class_2346 
                            || bs.method_27852(class_2246.field_10102) 
                            || bs.method_27852(class_2246.field_10534) 
                            || bs.method_27852(class_2246.field_10255)
                            || bs.method_27852(class_2246.field_42728)
                            || bs.method_27852(class_2246.field_43227)
                            || bs.method_27852(class_2246.field_9979)
                            || bs.method_27852(class_2246.field_10344)) {
                        return false;
                    }

                    if (bs.method_27852(class_2246.field_10382) || bs.method_27852(class_2246.field_10164)) {
                        return false;
                    }

                    if (bs.method_26215() || bs.method_45474()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private static void setupBlueprint(class_310 client, class_2338 spot) {
        b1 = spot;
        class_2350 f = client.field_1724.method_5735();
        b2 = b1.method_10093(f);

        blocksToDig.clear();
        wallsToBuild.clear();

        for (int depth = 0; depth < 3; depth++) {
            blocksToDig.add(b1.method_10087(depth));
            blocksToDig.add(b2.method_10087(depth));
        }

        for (int dy = 0; dy <= 2; dy++) {
            addWallIfUnique(b1.method_10087(dy).method_10095());
            addWallIfUnique(b1.method_10087(dy).method_10072());
            addWallIfUnique(b1.method_10087(dy).method_10078());
            addWallIfUnique(b1.method_10087(dy).method_10067());
            addWallIfUnique(b2.method_10087(dy).method_10095());
            addWallIfUnique(b2.method_10087(dy).method_10072());
            addWallIfUnique(b2.method_10087(dy).method_10078());
            addWallIfUnique(b2.method_10087(dy).method_10067());
        }
    }

    private static void addWallIfUnique(class_2338 p) {
        if (!wallsToBuild.contains(p) && !isCenterBlock(p)) {
            wallsToBuild.add(p);
        }
    }

    private static boolean isCenterBlock(class_2338 p) {
        for (int i = 0; i < 4; i++) {
            if (p.equals(b1.method_10087(i)) || p.equals(b2.method_10087(i))) return true;
        }
        return false;
    }

    public static void reset() {
        currentState = State.IDLE;
        BlockInteractionHelper.stopBreaking(class_310.method_1551());
        blocksToDig.clear();
        wallsToBuild.clear();
        airConfirmTicks = 0;
    }
}
package com.example.autotpa;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_6880;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class AutoSellManager {

    public enum SellState {
        IDLE, PREPARING_SHOP, WAITING_SHOP_OPEN, SCANNING_SHOP_AND_BUYING, 
        PREPARING_SELL, WAITING_SELL_OPEN, FILLING_SELL_MENU, CLICKING_CONFIRM_SELL, 
        WAITING_AFTER_SELL, 
        AH_START_ITEM, AH_SEARCH_WAIT_OPEN, AH_SEARCH_READ_PRICE,
        AH_STEP1_SWAP_TO_HAND, AH_STEP2_VERIFY_AND_SEND, AH_STEP3_RESTORE_WEAPON, 
        CHECKING_GROUND_LOOT,
        DEATH_OPEN_SHOP, DEATH_BUYING, DEATH_SORTING,
        BUYING_SWORD,
        OPENING_ECHEST_FOR_SPAWNERS, STORING_SPAWNERS
    }

    public static SellState currentState = SellState.IDLE;
    private static int stateDelayTicks = 0;
    public static int globalCooldown = 0;
    private static int guiOpenTimeout = 0;
    private static int restockCheckCooldown = 0;
    private static int payCooldownTicks = 0;
    private static int sessionWatchdogTicks = 0;
    private static int consecutiveGuiFailures = 0;

    // --- ПЕРЕМЕННЫЕ ПОШАГОВОЙ БЕЗОПАСНОЙ СОРТИРОВКИ ДЛЯ АНТИЧИТА ---
    private static int sortSubState = 0; // 0: Поиск/Взять, 1: Положить в цель, 2: Вернуть остаток
    private static int pendingFromSlot = -1;
    private static int pendingToSlot = -1;

    private static class_1792 ahExpectedItem = null;
    private static final Pattern PRICE_PATTERN = Pattern.compile("(?i)(?:\\$|цена|price|cost)?\\s*~?\\s*\\$?\\s*([0-9.,]+(?:\\s*[kKmMbB])?)");

    private record NormalizedGearKey(class_1792 item, String enchantsKey) {}
    private static final Map<NormalizedGearKey, String> dynamicShopPrices = new HashMap<>();
    private static final Map<class_1792, Integer> pendingShopBuys = new HashMap<>();

    private static final List<Integer> sellSlotQueue = new ArrayList<>();
    private static final List<AhItemTarget> ahItemQueue = new ArrayList<>();
    private static int currentAhIndex = 0;

    public static class AhItemTarget {
        final int inventorySlotIndex;
        final class_1792 expectedItem;
        String priceString;
        final String searchQuery;

        AhItemTarget(int inventorySlotIndex, class_1792 expectedItem, String priceString, String searchQuery) {
            this.inventorySlotIndex = inventorySlotIndex;
            this.expectedItem = expectedItem;
            this.priceString = priceString;
            this.searchQuery = searchQuery;
        }
    }

    public static boolean isSpawner(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (stack.method_31574(class_1802.field_8849)) return true;
        String name = Autotpa.cleanText(stack.method_7964().getString()).toLowerCase();
        if (name.contains("spawner") || name.contains("спавнер")) return true;
        String transKey = stack.method_7909().method_7876().toLowerCase();
        return transKey.contains("spawner") || transKey.contains("спавнер");
    }

    public static boolean hasSpawnersInInventory(class_310 client) {
        if (client.field_1724 == null) return false;
        for (int i = 0; i <= 35; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (isSpawner(stack)) return true;
        }
        return false;
    }

    public static class_2338 findNearestEnderChest(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return null;
        class_2338 playerPos = client.field_1724.method_24515();
        for (int x = -2; x <= 2; x++) {
            for (int y = -1; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    class_2338 p = playerPos.method_10069(x, y, z);
                    if (client.field_1687.method_8320(p).method_27852(class_2246.field_10443)) {
                        return p;
                    }
                }
            }
        }
        return null;
    }

    public static void startDepositSpawners(class_310 client) {
        if (client.field_1724 == null) return;
        currentState = SellState.OPENING_ECHEST_FOR_SPAWNERS;
        stateDelayTicks = 4;
        Autotpa.sendFeedback("§e[EnderChest] Обнаружен спавнер! Открываю эндер-сундук...");

        class_2338 echestPos = findNearestEnderChest(client);
        if (echestPos != null && client.field_1761 != null) {
            class_3965 hit = new class_3965(class_243.method_24953(echestPos), class_2350.field_11036, echestPos, false);
            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hit);
            client.field_1724.method_6104(class_1268.field_5808);
        } else {
            CommandQueue.send("echest");
        }
    }

    public static void startAutoSell(class_310 client) {
        if (!Autotpa.isMasterBotEnabled || currentState != SellState.IDLE) return;
        if (globalCooldown > 0) return;
        if (CombatManager.isServerCombatActive()) return;

        if (hasSpawnersInInventory(client)) {
            startDepositSpawners(client);
            return;
        }

        currentState = SellState.PREPARING_SELL;
        stateDelayTicks = 2;
        pendingShopBuys.clear();
        sessionWatchdogTicks = 0;
        Autotpa.sendFeedback("§6[AutoSell] §eЗапуск быстрой продажи лута (/sell)...");
    }

    public static void forceStartAutoSell(class_310 client) {
        if (!Autotpa.isMasterBotEnabled || currentState != SellState.IDLE) return;
        if (CombatManager.isServerCombatActive()) return;

        if (hasSpawnersInInventory(client)) {
            startDepositSpawners(client);
            return;
        }

        globalCooldown = 0;
        startAutoSell(client);
    }

    public static void startInitialRegear(class_310 client) {
        currentState = SellState.DEATH_OPEN_SHOP;
        stateDelayTicks = 4;
        globalCooldown = 0;
        pendingShopBuys.clear();
        sessionWatchdogTicks = 0;
        sortSubState = 0;
        Autotpa.sendFeedback("§e[MasterBot] Запуск авто-закупки экипировки...");
    }

    public static void startDeathRecovery(class_310 client) {
        currentState = SellState.DEATH_OPEN_SHOP;
        stateDelayTicks = 15; 
        globalCooldown = 9999; 
        pendingShopBuys.clear();
        sessionWatchdogTicks = 0;
        sortSubState = 0;
        Autotpa.sendFeedback("§c[AutoRecover] Смерть зафиксирована! Закупка экипировки...");
    }

    public static void startRestock(class_310 client, String missingReason) {
        currentState = SellState.DEATH_OPEN_SHOP;
        stateDelayTicks = 4;
        globalCooldown = 60;
        pendingShopBuys.clear();
        sessionWatchdogTicks = 0;
        sortSubState = 0;
        Autotpa.sendFeedback("§e[AutoRestock] Не хватает: §c" + missingReason + "§e! Докупаю в /shop...");
    }

    public static void startSwordRestock(class_310 client) {
        currentState = SellState.BUYING_SWORD;
        CommandQueue.send("shop");
        stateDelayTicks = 10;
    }

    public static void abortAutoSell(class_310 client) {
        currentState = SellState.IDLE;
        sellSlotQueue.clear();
        ahItemQueue.clear();
        currentAhIndex = 0;
        stateDelayTicks = 0;
        sessionWatchdogTicks = 0;
        sortSubState = 0;
        pendingFromSlot = -1;
        pendingToSlot = -1;
        globalCooldown = 60;
        CommandQueue.clear();

        if (client != null && client.field_1724 != null) {
            if (client.field_1755 != null) {
                client.field_1724.method_7346();
                client.method_1507(null);
            }
            selectHotbarSlot(client, 0);
        }
    }

    public static boolean isDeathRecoveryState() {
        return (currentState == SellState.DEATH_OPEN_SHOP || currentState == SellState.DEATH_BUYING || currentState == SellState.DEATH_SORTING);
    }

    public static void tick(class_310 client) {
        if (!Autotpa.isMasterBotEnabled) {
            currentState = SellState.IDLE;
            return;
        }

        if (CombatManager.isCombatActive(client) || CombatManager.findTarget(client) != null) {
            if (currentState != SellState.IDLE || client.field_1755 != null) {
                Autotpa.sendFeedback("§4§l[ТРЕВОГА] ВРАГ В ЛОВУШКЕ! МГНОВЕННО ЗАКРЫВАЮ МЕНЮ И В БОЙ!");
                abortAutoSell(client);
            }
            return;
        }

        if (BlockInteractionHelper.isBreaking() || CombatManager.isPostKillProcessing()) {
            if (currentState == SellState.IDLE) {
                return;
            }
        }

        if (currentState != SellState.IDLE) {
            sessionWatchdogTicks++;
            if (sessionWatchdogTicks > 600) { 
                Autotpa.sendFeedback("§c[AutoSell] Торговля застряла. Сброс...");
                abortAutoSell(client);
                return;
            }
        } else {
            sessionWatchdogTicks = 0;
        }

        boolean isRegearing = (Autotpa.currentBotState == Autotpa.BotState.STARTING_REGEAR);

        if (TpaManager.isWaitingItzNatsuu || (Autotpa.currentBotState != Autotpa.BotState.IDLE_TRAPPING && !isRegearing)) {
            if (currentState != SellState.IDLE && !isDeathRecoveryState()) {
                currentState = SellState.IDLE;
                if (client.field_1755 != null) client.field_1724.method_7346();
            }
            return;
        }

        boolean isDeathRecovery = isDeathRecoveryState();
        if (globalCooldown > 0 && !isDeathRecovery) globalCooldown--;

        if (currentState == SellState.IDLE) {
            if (CombatManager.isRepairingTrap || BlockInteractionHelper.isBreaking()) {
                return;
            }

            checkBalanceAndAutoPay(client);
            ensureBowInSlot6(client);

            if (hasSpawnersInInventory(client)) {
                startDepositSpawners(client);
                return;
            }

            if (globalCooldown <= 0 && !CombatManager.isServerCombatActive()) {
                String missing = getRestockMissingReason(client);
                if (missing != null) {
                    startRestock(client, missing);
                } else if (hasSellableItems(client)) {
                    startAutoSell(client);
                }
            }
            return;
        }

        if (stateDelayTicks > 0) {
            stateDelayTicks--;
            return;
        }

        if (client.field_1724 == null || client.field_1761 == null) {
            currentState = SellState.IDLE;
            return;
        }

        switch (currentState) {
            case OPENING_ECHEST_FOR_SPAWNERS -> {
                if (client.field_1755 instanceof class_465<?>) {
                    currentState = SellState.STORING_SPAWNERS;
                    stateDelayTicks = 2;
                } else {
                    class_2338 echestPos = findNearestEnderChest(client);
                    if (echestPos != null) {
                        class_3965 hit = new class_3965(class_243.method_24953(echestPos), class_2350.field_11036, echestPos, false);
                        client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hit);
                        client.field_1724.method_6104(class_1268.field_5808);
                    } else {
                        CommandQueue.send("echest");
                    }
                    stateDelayTicks = 10;
                }
            }

            case STORING_SPAWNERS -> {
                if (client.field_1755 instanceof class_465<?> screen) {
                    int syncId = screen.method_17577().field_7763;
                    int totalSlots = screen.method_17577().field_7761.size();
                    int chestSlots = (totalSlots >= 90) ? 54 : 27;

                    boolean movedAny = false;
                    for (int i = chestSlots; i < totalSlots; i++) {
                        class_1799 stack = screen.method_17577().method_7611(i).method_7677();
                        if (isSpawner(stack)) {
                            client.field_1761.method_2906(syncId, i, 0, class_1713.field_7794, client.field_1724);
                            movedAny = true;
                        }
                    }

                    client.field_1724.method_7346();
                    if (movedAny) {
                        Autotpa.sendFeedback("§a[EnderChest] Спавнер(ы) успешно спрятаны в эндер-сундук!");
                    }
                }
                currentState = SellState.IDLE;
                globalCooldown = 20;
            }

            case BUYING_SWORD -> {
                if (client.field_1755 instanceof class_465<?> screen) {
                    int totalSlots = screen.method_17577().field_7761.size();
                    int chestSize = (totalSlots >= 90) ? 54 : (totalSlots >= 36 ? totalSlots - 36 : 27);
                    int maxShopItemSlot = Math.max(0, chestSize - 9);

                    for (int i = 0; i < maxShopItemSlot; i++) {
                        class_1799 stack = screen.method_17577().method_7611(i).method_7677();
                        if (isMaxedSword(client, stack)) {
                            client.field_1761.method_2906(screen.method_17577().field_7763, i, 0, class_1713.field_7790, client.field_1724);
                            client.field_1724.method_7346();
                            currentState = SellState.IDLE;
                            globalCooldown = 60;
                            Autotpa.sendFeedback("§a[Shop] Куплен топовый меч!");
                            return;
                        }
                    }
                    CommandQueue.send("shop");
                    stateDelayTicks = 15;
                } else {
                    CommandQueue.send("shop");
                    stateDelayTicks = 15;
                }
            }

            case DEATH_OPEN_SHOP -> {
                if (client.field_1724.method_29504() || client.field_1755 instanceof net.minecraft.class_418) {
                    client.field_1724.method_7331();
                    if (client.field_1755 != null) client.method_1507(null);
                    stateDelayTicks = 15;
                    return;
                }
                if (client.field_1755 != null) client.field_1724.method_7346();
                CommandQueue.send("shop");
                currentState = SellState.DEATH_BUYING;
                stateDelayTicks = 15;
            }

            case DEATH_BUYING -> {
                if (client.field_1755 instanceof class_465<?> screen) {
                    boolean boughtSomething = processDeathShopBuy(client, screen);
                    if (!boughtSomething) {
                        client.field_1724.method_7346();
                        pendingShopBuys.clear();
                        currentState = SellState.DEATH_SORTING;
                        sortSubState = 0;
                        stateDelayTicks = 8;
                    } else {
                        sessionWatchdogTicks = 0;
                        stateDelayTicks = 8; 
                    }
                } else {
                    CommandQueue.send("shop");
                    stateDelayTicks = 15;
                }
            }

            case DEATH_SORTING -> {
                if (client.field_1755 != null && !(client.field_1755 instanceof net.minecraft.class_490)) {
                    client.field_1724.method_7346();
                }
                boolean done = performOneSortStep(client);
                if (done) {
                    CombatManager.equipArmorFromInventory(client);
                    Autotpa.sendFeedback("§a[MasterBot] Закупка и экипировка завершены! Возвращаюсь к ловле.");
                    currentState = SellState.IDLE;
                    globalCooldown = 40;
                    Autotpa.currentBotState = Autotpa.BotState.IDLE_TRAPPING;
                    if (!CombatManager.isAtTrap(client)) {
                        CombatManager.sendHome1WithVerification(client);
                    }
                } else {
                    sessionWatchdogTicks = 0;
                }
            }

            case PREPARING_SELL -> {
                analyzeInventory(client);
                if (!sellSlotQueue.isEmpty()) {
                    CommandQueue.send("sell");
                    currentState = SellState.WAITING_SELL_OPEN;
                    guiOpenTimeout = 70; 
                    stateDelayTicks = 2;
                } else if (!ahItemQueue.isEmpty()) {
                    currentAhIndex = 0;
                    currentState = SellState.AH_START_ITEM;
                    stateDelayTicks = 3;
                } else {
                    currentState = SellState.IDLE;
                    globalCooldown = 60;
                    stateDelayTicks = 1;
                }
            }

            case WAITING_SELL_OPEN -> {
                if (client.field_1755 instanceof class_465<?>) {
                    consecutiveGuiFailures = 0;
                    currentState = SellState.FILLING_SELL_MENU;
                    stateDelayTicks = 3;
                } else if (guiOpenTimeout > 0) {
                    guiOpenTimeout--;
                    stateDelayTicks = 1;
                } else {
                    consecutiveGuiFailures++;
                    if (consecutiveGuiFailures >= 2) {
                        Autotpa.sendFeedback("§c[AutoSell] Меню /sell не ответило. Пропускаю.");
                        consecutiveGuiFailures = 0;
                        currentState = SellState.IDLE;
                        globalCooldown = 120;
                        return;
                    }
                    currentState = SellState.IDLE;
                    globalCooldown = 60; 
                }
            }

            case FILLING_SELL_MENU -> {
                if (!(client.field_1755 instanceof class_465<?> screen)) {
                    currentState = SellState.IDLE;
                    globalCooldown = 60;
                    return;
                }
                
                int totalSlots = screen.method_17577().field_7761.size();
                int chestSize = (totalSlots >= 90) ? 54 : (totalSlots >= 63 ? 27 : 0);

                if (chestSize > 0 && !sellSlotQueue.isEmpty()) {
                    int invSlot = sellSlotQueue.remove(0);
                    int containerSlot = chestSize + (invSlot - 9);
                    if (containerSlot < totalSlots) {
                        client.field_1761.method_2906(screen.method_17577().field_7763, containerSlot, 0, class_1713.field_7794, client.field_1724);
                        sessionWatchdogTicks = 0;
                    }
                }

                if (sellSlotQueue.isEmpty() || chestSize == 0) {
                    currentState = SellState.CLICKING_CONFIRM_SELL;
                    stateDelayTicks = 5;
                } else {
                    stateDelayTicks = 3; // 150ms между предметами (защита от FastClick античита)
                }
            }

            case CLICKING_CONFIRM_SELL -> {
                if (client.field_1755 instanceof class_465<?> screen) {
                    int totalSlots = screen.method_17577().field_7761.size();
                    int confirmSlot = (totalSlots >= 90) ? 53 : (totalSlots >= 63 ? 26 : -1);
                    if (confirmSlot != -1) {
                        client.field_1761.method_2906(screen.method_17577().field_7763, confirmSlot, 0, class_1713.field_7790, client.field_1724);
                    }
                    client.field_1724.method_7346();
                    Autotpa.sendFeedback("§a[AutoSell] Лут успешно продан через /sell!");
                }
                currentState = SellState.WAITING_AFTER_SELL;
                stateDelayTicks = 5;
            }

            case WAITING_AFTER_SELL -> {
                if (!ahItemQueue.isEmpty()) {
                    currentAhIndex = 0;
                    currentState = SellState.AH_START_ITEM;
                    stateDelayTicks = 3;
                } else {
                    currentState = SellState.IDLE;
                    globalCooldown = 60;
                    stateDelayTicks = 1;
                }
            }

            case AH_START_ITEM -> {
                if (currentAhIndex < ahItemQueue.size()) {
                    AhItemTarget target = ahItemQueue.get(currentAhIndex);
                    class_1799 invStack = client.field_1724.method_31548().method_5438(target.inventorySlotIndex);
                    
                    if (invStack.method_7960() || target.priceString == null || target.priceString.trim().isEmpty()) {
                        currentAhIndex++;
                        stateDelayTicks = 1;
                        return;
                    }

                    if (client.field_1755 != null) {
                        client.field_1724.method_7346();
                    }

                    currentState = SellState.AH_STEP1_SWAP_TO_HAND;
                    stateDelayTicks = 3;
                } else {
                    currentState = SellState.IDLE;
                    globalCooldown = 100;
                }
            }

            case AH_STEP1_SWAP_TO_HAND -> {
                if (currentAhIndex < ahItemQueue.size()) {
                    AhItemTarget target = ahItemQueue.get(currentAhIndex);
                    class_1799 invStack = client.field_1724.method_31548().method_5438(target.inventorySlotIndex);
                    if (invStack.method_7960()) {
                        currentAhIndex++;
                        currentState = SellState.AH_START_ITEM;
                        stateDelayTicks = 1;
                        return;
                    }

                    client.field_1690.field_1904.method_23481(false);
                    ahExpectedItem = invStack.method_7909();
                    selectHotbarSlot(client, 0);

                    client.field_1761.method_2906(client.field_1724.field_7498.field_7763, target.inventorySlotIndex, 0, class_1713.field_7791, client.field_1724);
                    stateDelayTicks = 5;
                    currentState = SellState.AH_STEP2_VERIFY_AND_SEND;
                } else {
                    currentState = SellState.IDLE;
                    globalCooldown = 100;
                }
            }
            case AH_STEP2_VERIFY_AND_SEND -> {
                if (currentAhIndex < ahItemQueue.size()) {
                    AhItemTarget target = ahItemQueue.get(currentAhIndex);
                    class_1799 inHand = client.field_1724.method_6047();

                    if (inHand.method_7960() || (ahExpectedItem != null && inHand.method_7909() != ahExpectedItem)) {
                        restoreWeapon(client, target.inventorySlotIndex);
                        currentAhIndex++;
                        currentState = SellState.AH_START_ITEM;
                        stateDelayTicks = 4;
                        return;
                    }

                    CommandQueue.send("ah sell " + target.priceString);
                    Autotpa.sendFeedback("§e[AH] Выставляю: §b" + inHand.method_7964().getString() + " §eза §a$" + target.priceString);

                    stateDelayTicks = 16;
                    currentState = SellState.AH_STEP3_RESTORE_WEAPON;
                } else {
                    currentState = SellState.IDLE;
                    globalCooldown = 100;
                }
            }
            case AH_STEP3_RESTORE_WEAPON -> {
                if (currentAhIndex < ahItemQueue.size()) {
                    AhItemTarget target = ahItemQueue.get(currentAhIndex);

                    restoreWeapon(client, target.inventorySlotIndex);
                    currentAhIndex++;

                    selectHotbarSlot(client, 0);
                    CombatManager.ensureSwordInHand(client);

                    currentState = SellState.AH_START_ITEM;
                    stateDelayTicks = 4;
                } else {
                    currentState = SellState.IDLE;
                    globalCooldown = 100;
                }
            }

            default -> currentState = SellState.IDLE;
        }
    }

    public static boolean isHarmingArrow(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!stack.method_31574(class_1802.field_8087)) return false;

        class_1844 contents = stack.method_58694(class_9334.field_49651);
        if (contents != null) {
            if (contents.comp_2378().isPresent()) {
                String id = contents.comp_2378().get().method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse("");
                if (id.contains("harming") || id.contains("damage")) return true;
            }
            for (net.minecraft.class_1293 effect : contents.comp_2380()) {
                String effectId = effect.method_5579().method_55840().toLowerCase();
                if (effectId.contains("harming") || effectId.contains("instant_damage")) return true;
            }
        }

        String name = Autotpa.cleanText(stack.method_7964().getString()).toLowerCase();
        if (name.contains("урон") || name.contains("harming") || name.contains("damage")) return true;

        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore != null) {
            for (class_2561 line : lore.comp_2400()) {
                String cleanLine = Autotpa.cleanText(line.getString()).toLowerCase();
                if (cleanLine.contains("урон") || cleanLine.contains("harming") || cleanLine.contains("damage")) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int countHarmingArrows(class_310 client) {
        if (client == null || client.field_1724 == null) return 0;
        int total = 0;
        for (int i = 0; i <= 35; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (isHarmingArrow(stack)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    public static String getRestockMissingReason(class_310 client) {
        if (client.field_1724 == null) return null;

        if (!CombatManager.hasSword(client)) return "Меч";
        if (!hasArmorPiece(client, "helmet")) return "Шлем";
        if (!hasArmorPiece(client, "chestplate")) return "Нагрудник";
        if (!hasArmorPiece(client, "leggings")) return "Поножи";
        if (!hasArmorPiece(client, "boots")) return "Ботинки";

        int bows = countItemInInventory(client, class_1802.field_8102);
        if (bows < 2) return "Лук (" + bows + "/2)";

        int arrows = countHarmingArrows(client);
        if (arrows < 128) return "Стрелы урона (" + arrows + "/192)";

        int echests = countItemInInventory(client, class_1802.field_8466);
        if (echests < 32) return "Эндер-сундуки (" + echests + "/64)";

        int gapples = countItemInInventory(client, class_1802.field_8463) + countItemInInventory(client, class_1802.field_8367);
        if (gapples < 32) return "Золотые яблоки (" + gapples + "/64)";

        int cobweb = countItemInInventory(client, class_1802.field_8786);
        if (cobweb < 32) return "Паутина (" + cobweb + "/64)";

        int pearls = countItemInInventory(client, class_1802.field_8634);
        if (pearls < 16) return "Эндер-жемчуг (" + pearls + "/16)";

        int totems = countItemInInventory(client, class_1802.field_8288);
        if (totems < 6) return "Тотемы (" + totems + "/8)";

        int strength = countStrengthPotions(client);
        if (strength < 4) return "Зелья силы (" + strength + "/4)";

        int xp = countItemInInventory(client, class_1802.field_8287);
        if (xp < 32) return "Пузырьки опыта (" + xp + "/64)";

        int axes = countItemInInventory(client, class_1802.field_8556) + countItemInInventory(client, class_1802.field_22025);
        if (axes < 1) return "Топор";

        int picks = countItemInInventory(client, class_1802.field_8377) + countItemInInventory(client, class_1802.field_22024);
        if (picks < 1) return "Кирка";

        return null;
    }

    public static boolean isRestockNeededBeforeTrap(class_310 client) {
        return getRestockMissingReason(client) != null;
    }

    public static boolean isStrengthPotion(class_1799 s) {
        if (s == null || s.method_7960()) return false;
        if (s.method_7909() != class_1802.field_8574 && s.method_7909() != class_1802.field_8436) return false;
        class_1844 contents = s.method_58694(class_9334.field_49651);
        if (contents != null) {
            if (contents.comp_2378().isPresent()) {
                String id = contents.comp_2378().get().method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse("");
                if (id.contains("strength")) return true;
            }
            for (var effect : contents.comp_2380()) {
                if (effect.method_5579().method_55840().toLowerCase().contains("strength")) return true;
            }
        }
        String name = Autotpa.cleanText(s.method_7964().getString()).toLowerCase();
        return name.contains("сил") || name.contains("strength");
    }

    public static int countStrengthPotions(class_310 client) {
        int c = 0;
        if (client.field_1724 == null) return 0;
        for (int i = 0; i <= 35; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (isStrengthPotion(s)) c++;
        }
        return c;
    }

    public static int countItemInInventory(class_310 client, class_1792 item) {
    if (client.field_1724 == null) return 0;
    int count = 0;
    
    // Считаем инвентарь и хотбар (0-35)
    for (int i = 0; i <= 35; i++) {
        class_1799 s = client.field_1724.method_31548().method_5438(i);
        if (s.method_31574(item)) count += s.method_7947();
    }
    // Считаем вторую руку (Offhand)
    if (client.field_1724.method_6079().method_31574(item)) {
        count += client.field_1724.method_6079().method_7947();
    }
    // ВАЖНО: Считаем надетую броню на теле!
    for (class_1304 slot : class_1304.values()) {
        if (slot.method_5925() == class_1304.class_1305.field_6178) {
            class_1799 equipped = client.field_1724.method_6118(slot);
            if (equipped.method_31574(item)) {
                count += equipped.method_7947();
            }
        }
    }
    return count;
}

    private static boolean processDeathShopBuy(class_310 client, class_465<?> screen) {
        if (!(screen instanceof class_476 containerScreen)) return false;

        if (clickConfirmIfPresent(client, containerScreen)) {
            return true;
        }
        int slotsCount = screen.method_17577().field_7761.size();
        
        int chestSize = (slotsCount >= 90) ? 54 : (slotsCount >= 36 ? slotsCount - 36 : 27);
        int maxShopItemSlot = Math.max(0, chestSize - 9); 

        for (int i = 0; i < maxShopItemSlot; i++) {
            class_1799 stack = screen.method_17577().method_7611(i).method_7677();
            if (stack.method_7960()) continue;
            double p = getItemPrice(client, stack);
            if (p > 0) {
                String nKey = getNormalizedEnchantKey(stack);
                dynamicShopPrices.put(new NormalizedGearKey(stack.method_7909(), nKey), formatPrice(p));
            }
        }

        int helms = countItemInInventory(client, class_1802.field_8805) + pendingShopBuys.getOrDefault(class_1802.field_8805, 0);
        int chests = countItemInInventory(client, class_1802.field_8058) + pendingShopBuys.getOrDefault(class_1802.field_8058, 0);
        int legs = countItemInInventory(client, class_1802.field_8348) + pendingShopBuys.getOrDefault(class_1802.field_8348, 0);
        int boots = countItemInInventory(client, class_1802.field_8285) + pendingShopBuys.getOrDefault(class_1802.field_8285, 0);
        int axes = countItemInInventory(client, class_1802.field_8556) + pendingShopBuys.getOrDefault(class_1802.field_8556, 0);
        int picks = countItemInInventory(client, class_1802.field_8377) + pendingShopBuys.getOrDefault(class_1802.field_8377, 0);
        
        int cobwebs = countItemInInventory(client, class_1802.field_8786) + pendingShopBuys.getOrDefault(class_1802.field_8786, 0);
        int pearls = countItemInInventory(client, class_1802.field_8634) + pendingShopBuys.getOrDefault(class_1802.field_8634, 0);
        int gapples = countItemInInventory(client, class_1802.field_8463) + countItemInInventory(client, class_1802.field_8367) + pendingShopBuys.getOrDefault(class_1802.field_8463, 0);
        int xp = countItemInInventory(client, class_1802.field_8287) + pendingShopBuys.getOrDefault(class_1802.field_8287, 0);
        int totems = countItemInInventory(client, class_1802.field_8288) + pendingShopBuys.getOrDefault(class_1802.field_8288, 0);
        
        boolean hasGoodSword = hasMaxedSwordInInventory(client) || pendingShopBuys.getOrDefault(class_1802.field_8802, 0) > 0;
        int potions = countStrengthPotions(client) + pendingShopBuys.getOrDefault(class_1802.field_8574, 0) + pendingShopBuys.getOrDefault(class_1802.field_8436, 0);

        int currentHarmingArrows = countHarmingArrows(client) + pendingShopBuys.getOrDefault(class_1802.field_8087, 0);
        int bows = countItemInInventory(client, class_1802.field_8102) + pendingShopBuys.getOrDefault(class_1802.field_8102, 0);
        int echests = countItemInInventory(client, class_1802.field_8466) + pendingShopBuys.getOrDefault(class_1802.field_8466, 0);

        for (int i = 0; i < maxShopItemSlot; i++) {
            class_1799 stack = screen.method_17577().method_7611(i).method_7677();
            if (stack.method_7960()) continue;
            class_1792 item = stack.method_7909();
            String name = Autotpa.cleanText(stack.method_7964().getString()).toLowerCase();

            if (name.contains("auction") || name.contains("аукцион") || name.contains("/ah") || name.contains("рынок") || name.contains("market")) {
                continue;
            }

            class_9290 lore = stack.method_58694(class_9334.field_49632);
            if (lore != null) {
                boolean isAuctionBtn = false;
                for (class_2561 line : lore.comp_2400()) {
                    String clean = Autotpa.cleanText(line.getString()).toLowerCase();
                    if (clean.contains("auction") || clean.contains("аукцион") || clean.contains("/ah") || clean.contains("рынок")) {
                        isAuctionBtn = true;
                        break;
                    }
                }
                if (isAuctionBtn) continue;
            }

            boolean buy = false;
            class_1792 buyItemKey = item;
            boolean buyStack = false;
            
            // Броня — покупаем ТОЛЬКО если ее 0 шт. (учитывая надетое на тело через hasArmorPiece)
if (item == class_1802.field_8805 && !hasArmorPiece(client, "helmet") && isMaxedArmor(client, stack)) {
    buy = true; buyItemKey = class_1802.field_8805;
}
else if (item == class_1802.field_8058 && !hasArmorPiece(client, "chestplate") && isMaxedArmor(client, stack)) {
    buy = true; buyItemKey = class_1802.field_8058;
}
else if (item == class_1802.field_8348 && !hasArmorPiece(client, "leggings") && isMaxedArmor(client, stack)) {
    buy = true; buyItemKey = class_1802.field_8348;
}
else if (item == class_1802.field_8285 && !hasArmorPiece(client, "boots") && isMaxedArmor(client, stack)) {
    buy = true; buyItemKey = class_1802.field_8285;
}
else if ((item == class_1802.field_8802 || item == class_1802.field_22022) && !CombatManager.hasSword(client) && isMaxedSword(client, stack)) {
    buy = true; buyItemKey = class_1802.field_8802;
}
else if (item == class_1802.field_8556 && axes < 1) buy = true;
else if (item == class_1802.field_8377 && picks < 1 && isEfficiency5Pickaxe(client, stack)) {
    buy = true; buyItemKey = class_1802.field_8377;
}
else if (isBowItem(stack) && bows < 2) { // 1 лука в инвентаре достаточно
    buy = true; buyItemKey = class_1802.field_8102;
}
// Расходники — покупаем стак, только если текущий запас просел
else if (item == class_1802.field_8466 && echests < 16) {
    buy = true; buyItemKey = class_1802.field_8466; buyStack = true;
}
else if (item == class_1802.field_8786 && cobwebs < 16) {
    buy = true; buyItemKey = class_1802.field_8786; buyStack = true;
}
else if (item == class_1802.field_8634 && pearls < 8) {
    buy = true; buyItemKey = class_1802.field_8634; buyStack = true;
}
else if ((item == class_1802.field_8463 || item == class_1802.field_8367) && gapples < 16) {
    buy = true; buyItemKey = class_1802.field_8463; buyStack = true;
}
else if (item == class_1802.field_8287 && xp < 64) {
    buy = true; buyItemKey = class_1802.field_8287; buyStack = true;
}
else if (item == class_1802.field_8288 && totems < 6) {
    buy = true; buyItemKey = class_1802.field_8288;
}
else if (isHarmingArrow(stack) && currentHarmingArrows < 64) { // 1 полный стак (64 шт.)
    buy = true; 
    buyItemKey = class_1802.field_8087;
    buyStack = true;
}
            else if ((item == class_1802.field_8574 || item == class_1802.field_8436) && potions < 4) {
                if (isStrengthPotion(stack)) {
                    double price = getItemPrice(client, stack);
                    if (item == class_1802.field_8574 && price > 100_000.0) continue;
                    buy = true;
                    buyItemKey = item;
                }
            }
            
            if (buy && hasFreeSlot(client)) {
                int amountToAdd = 1;
                if (buyStack) {
                    amountToAdd = (buyItemKey == class_1802.field_8634) ? 16 : 64;
                    client.field_1761.method_2906(screen.method_17577().field_7763, i, 0, class_1713.field_7794, client.field_1724);
                    Autotpa.sendFeedback("§a[Shop] Покупка стака: " + stack.method_7964().getString());
                } else {
                    client.field_1761.method_2906(screen.method_17577().field_7763, i, 0, class_1713.field_7790, client.field_1724);
                    Autotpa.sendFeedback("§a[Shop] Куплен предмет: §e" + stack.method_7964().getString());
                }
                pendingShopBuys.put(buyItemKey, pendingShopBuys.getOrDefault(buyItemKey, 0) + amountToAdd);
                return true;
            }
        }
        return false;
    }

    public static void ensureBowInSlot6(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        class_1799 slot6Stack = client.field_1724.method_31548().method_5438(6);
        if (isBowItem(slot6Stack)) return;

        int syncId = client.field_1724.field_7498.field_7763;

        for (int i = 0; i <= 35; i++) {
            if (i == 6) continue;
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (isBowItem(s)) {
                int containerSlot = (i < 9) ? (36 + i) : i;
                client.field_1761.method_2906(syncId, containerSlot, 6, class_1713.field_7791, client.field_1724);
                return;
            }
        }
    }

    // =========================================================================
    // АНТИЧИТ-БЕЗОПАСНАЯ ПОШАГОВАЯ СОРТИРОВКА (1 ДЕЙСТВИЕ В 200-250 МС)
    // =========================================================================
    private static boolean isAlreadyInCorrectSlot(int slot, class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();

        if (slot == 5 && matchesType(item, "helmet")) return true;
        if (slot == 6 && matchesType(item, "chestplate")) return true;
        if (slot == 7 && matchesType(item, "leggings")) return true;
        if (slot == 8 && matchesType(item, "boots")) return true;
        if (slot == 45 && stack.method_31574(class_1802.field_8288)) return true;

        if (slot == 36 && matchesType(item, "sword")) return true;
        if (slot == 37 && stack.method_31574(class_1802.field_8786)) return true;
        if (slot == 38 && matchesType(item, "axe")) return true;
        if (slot == 39 && stack.method_31574(class_1802.field_8634)) return true;
        if (slot == 40 && (stack.method_31574(class_1802.field_8463) || stack.method_31574(class_1802.field_8367))) return true;
        if (slot == 41 && stack.method_31574(class_1802.field_8466)) return true;
        if (slot == 42 && isBowItem(stack)) return true;
        if (slot == 43 && matchesType(item, "pickaxe")) return true;
        if (slot == 44 && stack.method_31574(class_1802.field_8288)) return true;

        if ((slot == 9 || slot == 10 || slot == 29) && isHarmingArrow(stack)) return true;
        if (slot == 11 && isBowItem(stack)) return true;
        if ((slot == 12 || slot == 13 || slot == 14 || slot == 21 || slot == 22 || slot == 23) && stack.method_31574(class_1802.field_8288)) return true;
        if ((slot == 15 || slot == 16 || slot == 20 || slot == 28) && isStrengthPotion(stack)) return true;
        if (slot == 17 && stack.method_31574(class_1802.field_8287)) return true;

        return false;
    }

    private interface SlotPredicate {
        boolean test(class_1799 stack);
    }

    private static boolean performOneSortStep(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return true;
        int syncId = client.field_1724.field_7498.field_7763;

        // 1. Фазы переноса предмета мышью в рюкзаке (с человеческими задержками)
        if (sortSubState == 1) {
            client.field_1761.method_2906(syncId, pendingToSlot, 0, class_1713.field_7790, client.field_1724);
            if (!client.field_1724.field_7498.method_34255().method_7960()) {
                sortSubState = 2; // Возвращаем вытесненный предмет назад
            } else {
                sortSubState = 0;
                pendingFromSlot = -1;
                pendingToSlot = -1;
            }
            stateDelayTicks = 4; // 200 мс
            return false;
        }

        if (sortSubState == 2) {
            client.field_1761.method_2906(syncId, pendingFromSlot, 0, class_1713.field_7790, client.field_1724);
            sortSubState = 0;
            pendingFromSlot = -1;
            pendingToSlot = -1;
            stateDelayTicks = 4; // 200 мс
            return false;
        }

        // Если курсор почему-то не пустой — сбрасываем предмет в первый свободный слот
        if (!client.field_1724.field_7498.method_34255().method_7960()) {
            for (int i = 9; i <= 44; i++) {
                if (client.field_1724.field_7498.method_7611(i).method_7677().method_7960()) {
                    client.field_1761.method_2906(syncId, i, 0, class_1713.field_7790, client.field_1724);
                    stateDelayTicks = 4;
                    return false;
                }
            }
        }

        // 2. Экипировка брони (слоты 5, 6, 7, 8) - Shift-клик (250 мс)
        if (equipArmorStep(client, "helmet", 5)) return false;
        if (equipArmorStep(client, "chestplate", 6)) return false;
        if (equipArmorStep(client, "leggings", 7)) return false;
        if (equipArmorStep(client, "boots", 8)) return false;

        // 3. Тотем в левую руку (эмуляция клавиши F) (250 мс)
        if (enforceOffhandTotemStep(client)) return false;

        // 4. ХОТБАР (слоты 36..44) - Эмуляция клавиш 1-9 (1 пакет SWAP, 250 мс)
        if (enforceHotbarSlot(client, 36, s -> matchesType(s.method_7909(), "sword"))) return false;
        if (enforceHotbarSlot(client, 37, s -> s.method_31574(class_1802.field_8786))) return false;
        if (enforceHotbarSlot(client, 38, s -> matchesType(s.method_7909(), "axe"))) return false;
        if (enforceHotbarSlot(client, 39, s -> s.method_31574(class_1802.field_8634))) return false;
        if (enforceHotbarSlot(client, 40, s -> s.method_31574(class_1802.field_8463) || s.method_31574(class_1802.field_8367))) return false;
        if (enforceHotbarSlot(client, 41, s -> s.method_31574(class_1802.field_8466))) return false;
        if (enforceHotbarSlot(client, 42, s -> isBowItem(s))) return false;
        if (enforceHotbarSlot(client, 43, s -> matchesType(s.method_7909(), "pickaxe"))) return false;
        if (enforceHotbarSlot(client, 44, s -> s.method_31574(class_1802.field_8288))) return false;

        // 5. ОСНОВНОЙ РЮКЗАК (слоты 9..35) - Пошаговый перенос курсором (200 мс)
        if (enforceBackpackSlot(client, 9, s -> isHarmingArrow(s))) return false;
        if (enforceBackpackSlot(client, 10, s -> isHarmingArrow(s))) return false;
        if (enforceBackpackSlot(client, 11, s -> isBowItem(s))) return false;
        if (enforceBackpackSlot(client, 12, s -> s.method_31574(class_1802.field_8288))) return false;
        if (enforceBackpackSlot(client, 13, s -> s.method_31574(class_1802.field_8288))) return false;
        if (enforceBackpackSlot(client, 14, s -> s.method_31574(class_1802.field_8288))) return false;
        if (enforceBackpackSlot(client, 15, s -> isStrengthPotion(s))) return false;
        if (enforceBackpackSlot(client, 16, s -> isStrengthPotion(s))) return false;
        if (enforceBackpackSlot(client, 17, s -> s.method_31574(class_1802.field_8287))) return false;

        if (enforceBackpackSlot(client, 20, s -> isStrengthPotion(s))) return false;
        if (enforceBackpackSlot(client, 21, s -> s.method_31574(class_1802.field_8288))) return false;
        if (enforceBackpackSlot(client, 22, s -> s.method_31574(class_1802.field_8288))) return false;
        if (enforceBackpackSlot(client, 23, s -> s.method_31574(class_1802.field_8288))) return false;

        if (enforceBackpackSlot(client, 28, s -> isStrengthPotion(s))) return false;
        if (enforceBackpackSlot(client, 29, s -> isHarmingArrow(s))) return false;

        return true; 
    }

    private static boolean enforceHotbarSlot(class_310 client, int targetSyncSlot, SlotPredicate predicate) {
        class_1799 current = client.field_1724.field_7498.method_7611(targetSyncSlot).method_7677();
        if (predicate.test(current)) return false;

        int hotbarIndex = targetSyncSlot - 36;
        for (int i = 9; i <= 44; i++) {
            if (i == targetSyncSlot) continue;
            class_1799 candidate = client.field_1724.field_7498.method_7611(i).method_7677();
            if (candidate.method_7960()) continue;

            if (predicate.test(candidate) && !isAlreadyInCorrectSlot(i, candidate)) {
                client.field_1761.method_2906(client.field_1724.field_7498.field_7763, i, hotbarIndex, class_1713.field_7791, client.field_1724);
                stateDelayTicks = 5; // 250 мс задержка
                return true;
            }
        }
        return false;
    }

    private static boolean enforceBackpackSlot(class_310 client, int targetSyncSlot, SlotPredicate predicate) {
        class_1799 current = client.field_1724.field_7498.method_7611(targetSyncSlot).method_7677();
        if (predicate.test(current)) return false;

        for (int i = 9; i <= 44; i++) {
            if (i == targetSyncSlot) continue;
            class_1799 candidate = client.field_1724.field_7498.method_7611(i).method_7677();
            if (candidate.method_7960()) continue;

            if (predicate.test(candidate) && !isAlreadyInCorrectSlot(i, candidate)) {
                pendingFromSlot = i;
                pendingToSlot = targetSyncSlot;
                sortSubState = 1;
                client.field_1761.method_2906(client.field_1724.field_7498.field_7763, pendingFromSlot, 0, class_1713.field_7790, client.field_1724);
                stateDelayTicks = 4; // 200 мс задержка
                return true;
            }
        }
        return false;
    }

    private static boolean enforceOffhandTotemStep(class_310 client) {
        if (client.field_1724 == null) return false;
        if (client.field_1724.method_6079().method_31574(class_1802.field_8288)) return false;
        for (int i = 9; i <= 44; i++) {
            class_1799 s = client.field_1724.field_7498.method_7611(i).method_7677();
            if (s.method_31574(class_1802.field_8288) && !isAlreadyInCorrectSlot(i, s)) {
                // Эмуляция клавиши F (кнопка 40)
                client.field_1761.method_2906(client.field_1724.field_7498.field_7763, i, 40, class_1713.field_7791, client.field_1724);
                stateDelayTicks = 5; // 250 мс задержка
                return true;
            }
        }
        return false;
    }

    private static boolean equipArmorStep(class_310 client, String type, int syncId) {
        class_1799 current = client.field_1724.field_7498.method_7611(syncId).method_7677();
        if (matchesType(current.method_7909(), type)) return false;
        for (int i = 9; i <= 44; i++) {
            if (matchesType(client.field_1724.field_7498.method_7611(i).method_7677().method_7909(), type)) {
                client.field_1761.method_2906(client.field_1724.field_7498.field_7763, i, 0, class_1713.field_7794, client.field_1724);
                stateDelayTicks = 5; // 250 мс задержка
                return true; 
            }
        }
        return false;
    }

    private static void analyzeInventory(class_310 client) {
        if (client.field_1724 == null) return;
        sellSlotQueue.clear();
        ahItemQueue.clear();
        int strength = 0;

        int keptBows = 0;
        for (int i = 0; i < 9; i++) {
            if (isBowItem(client.field_1724.method_31548().method_5438(i))) keptBows++;
        }

        int keptHarmingArrows = 0;
        for (int i = 0; i < 9; i++) {
            class_1799 hotbarStack = client.field_1724.method_31548().method_5438(i);
            if (isHarmingArrow(hotbarStack)) {
                keptHarmingArrows += hotbarStack.method_7947();
            }
        }
        if (isHarmingArrow(client.field_1724.method_6079())) {
            keptHarmingArrows += client.field_1724.method_6079().method_7947();
        }

        int keptGapples = 0, keptCobweb = 0, keptPearls = 0, keptXp = 0, keptEchests = 0;
        for (int i = 0; i < 9; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (s.method_31574(class_1802.field_8463) || s.method_31574(class_1802.field_8367)) keptGapples += s.method_7947();
            if (s.method_31574(class_1802.field_8786)) keptCobweb += s.method_7947();
            if (s.method_31574(class_1802.field_8634)) keptPearls += s.method_7947();
            if (s.method_31574(class_1802.field_8287)) keptXp += s.method_7947();
            if (s.method_31574(class_1802.field_8466)) keptEchests += s.method_7947();
        }

        int protectedSwordSlot = -1, protectedPickaxeSlot = -1, protectedAxeSlot = -1;
        int protectedHelmetSlot = -1, protectedChestplateSlot = -1, protectedLeggingsSlot = -1, protectedBootsSlot = -1;

        for (int slot = 0; slot <= 35; slot++) {
            class_1799 s = client.field_1724.method_31548().method_5438(slot);
            if (s.method_7960()) continue;
            class_1792 item = s.method_7909();

            if (protectedSwordSlot == -1 && (isMaxedSword(client, s) || matchesType(item, "sword"))) protectedSwordSlot = slot;
            if (protectedPickaxeSlot == -1 && matchesType(item, "pickaxe")) protectedPickaxeSlot = slot;
            if (protectedAxeSlot == -1 && matchesType(item, "axe")) protectedAxeSlot = slot;

            if (protectedHelmetSlot == -1 && matchesType(item, "helmet")) protectedHelmetSlot = slot;
            if (protectedChestplateSlot == -1 && matchesType(item, "chestplate")) protectedChestplateSlot = slot;
            if (protectedLeggingsSlot == -1 && matchesType(item, "leggings")) protectedLeggingsSlot = slot;
            if (protectedBootsSlot == -1 && matchesType(item, "boots")) protectedBootsSlot = slot;
        }

        int equippedTotems = 0;
        if (client.field_1724.method_6079().method_31574(class_1802.field_8288)) equippedTotems++;
        if (client.field_1724.method_31548().method_5438(8).method_31574(class_1802.field_8288)) equippedTotems++;
        int maxBackpackTotems = 8;
        int keptTotems = equippedTotems;

        for (int slot = 9; slot <= 35; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) continue;
            class_1792 item = stack.method_7909();

            if (slot == protectedSwordSlot || slot == protectedPickaxeSlot || slot == protectedAxeSlot
                    || slot == protectedHelmetSlot || slot == protectedChestplateSlot
                    || slot == protectedLeggingsSlot || slot == protectedBootsSlot) {
                continue;
            }

            if (isMaxedArmor(client, stack)) {
                continue;
            }

            if (isSpawner(stack)) {
                continue;
            }

            if (item == class_1802.field_8469 || item == class_1802.field_8281) {
                sellSlotQueue.add(slot);
                continue;
            }

            if (item == class_1802.field_8466) {
                if (keptEchests < 64) {
                    keptEchests += stack.method_7947();
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }

            if (isBowItem(stack)) {
                if (keptBows < 2) {
                    keptBows++;
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }

            if (item == class_1802.field_8288) {
                if (keptTotems < maxBackpackTotems) {
                    keptTotems++;
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }

            if (matchesType(item, "helmet") || matchesType(item, "chestplate") || matchesType(item, "leggings") || matchesType(item, "boots")) {
                String armorAhPrice = getArmorAhPrice(client, stack);
                if (armorAhPrice != null) {
                    ahItemQueue.add(new AhItemTarget(slot, item, armorAhPrice, null));
                }
                continue;
            }

            if (matchesType(item, "sword") || matchesType(item, "pickaxe") || matchesType(item, "axe") || matchesType(item, "shovel") || matchesType(item, "hoe")) {
                String toolAhPrice = getToolAhPrice(client, stack);
                if (toolAhPrice != null) {
                    ahItemQueue.add(new AhItemTarget(slot, item, toolAhPrice, null));
                }
                continue;
            }

            if (item == class_1802.field_8107 || item == class_1802.field_8236) {
                sellSlotQueue.add(slot);
                continue;
            }

            if (item == class_1802.field_8087) {
                if (!isHarmingArrow(stack)) {
                    sellSlotQueue.add(slot);
                    continue;
                }
                if (keptHarmingArrows < 192) {
                    keptHarmingArrows += stack.method_7947();
                    continue;
                } else {
                    sellSlotQueue.add(slot);
                    continue;
                }
            }

            if (item == class_1802.field_8463 || item == class_1802.field_8367) {
                if (keptGapples < 64) {
                    keptGapples += stack.method_7947();
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }
            if (item == class_1802.field_8786) {
                if (keptCobweb < 64) {
                    keptCobweb += stack.method_7947();
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }
            if (item == class_1802.field_8634) {
                if (keptPearls < 16) {
                    keptPearls += stack.method_7947();
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }
            if (item == class_1802.field_8287) {
                if (keptXp < 64) {
                    keptXp += stack.method_7947();
                    continue;
                }
                sellSlotQueue.add(slot);
                continue;
            }
            if (isStrengthPotion(stack)) {
                if (strength < 4) { strength++; continue; } 
            }

            sellSlotQueue.add(slot);
        }
    }

    public static boolean hasSellableItems(class_310 client) {
        if (client.field_1724 == null) return false;

        int protectedSword = -1, protectedPick = -1, protectedAxe = -1;
        int protectedHelm = -1, protectedChest = -1, protectedLegs = -1, protectedBoots = -1;

        for (int i = 0; i <= 35; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (s.method_7960()) continue;
            class_1792 item = s.method_7909();

            if (isMaxedSword(client, s) && protectedSword == -1) protectedSword = i;
            if (matchesType(item, "pickaxe") && protectedPick == -1) protectedPick = i;
            if (matchesType(item, "axe") && protectedAxe == -1) protectedAxe = i;

            if (matchesType(item, "helmet") && protectedHelm == -1) protectedHelm = i;
            if (matchesType(item, "chestplate") && protectedChest == -1) protectedChest = i;
            if (matchesType(item, "leggings") && protectedLegs == -1) protectedLegs = i;
            if (matchesType(item, "boots") && protectedBoots == -1) protectedBoots = i;
        }

        int equippedTotems = (client.field_1724.method_6079().method_31574(class_1802.field_8288) ? 1 : 0)
                + (client.field_1724.method_31548().method_5438(8).method_31574(class_1802.field_8288) ? 1 : 0);
        int maxBackpackTotems = 8;

        int keptTotems = equippedTotems;
        int keptHarmingArrows = 0;
        int keptGapples = 0, keptCobweb = 0, keptPearls = 0, keptXp = 0, keptStrength = 0, keptEchests = 0;

        int keptBows = 0;
        for (int i = 0; i < 9; i++) {
            if (isBowItem(client.field_1724.method_31548().method_5438(i))) keptBows++;
        }

        for (int slot = 9; slot <= 35; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) continue;
            class_1792 item = stack.method_7909();

            if (slot == protectedSword || slot == protectedPick || slot == protectedAxe
                    || slot == protectedHelm || slot == protectedChest || slot == protectedLegs || slot == protectedBoots) {
                continue;
            }

            if (isMaxedArmor(client, stack)) continue;
            if (isSpawner(stack)) continue;

            if (item == class_1802.field_8469 || item == class_1802.field_8281) return true;

            if (item == class_1802.field_8466) {
                if (keptEchests < 64) {
                    keptEchests += stack.method_7947();
                    continue;
                }
                return true;
            }

            if (isBowItem(stack)) {
                if (keptBows < 2) {
                    keptBows++;
                    continue;
                }
                return true;
            }

            if (item == class_1802.field_8288) {
                if (keptTotems < maxBackpackTotems) { keptTotems++; continue; }
                return true;
            }

            if (matchesType(item, "helmet") || matchesType(item, "chestplate") || matchesType(item, "leggings") || matchesType(item, "boots")) {
                if (getArmorAhPrice(client, stack) != null) return true;
                continue;
            }
            if (matchesType(item, "sword") || matchesType(item, "pickaxe") || matchesType(item, "axe") || matchesType(item, "shovel") || matchesType(item, "hoe")) {
                if (getToolAhPrice(client, stack) != null) return true;
                continue;
            }

            if (item == class_1802.field_8107 || item == class_1802.field_8236) return true;
            if (item == class_1802.field_8087) {
                if (!isHarmingArrow(stack)) return true;
                if (keptHarmingArrows < 192) { keptHarmingArrows += stack.method_7947(); continue; }
                return true;
            }

            if (item == class_1802.field_8463 || item == class_1802.field_8367) {
                if (keptGapples < 64) { keptGapples += stack.method_7947(); continue; }
                return true;
            }
            if (item == class_1802.field_8786) {
                if (keptCobweb < 64) { keptCobweb += stack.method_7947(); continue; }
                return true;
            }
            if (item == class_1802.field_8634) {
                if (keptPearls < 16) { keptPearls += stack.method_7947(); continue; }
                return true;
            }
            if (item == class_1802.field_8287) {
                if (keptXp < 64) { keptXp += stack.method_7947(); continue; }
                return true;
            }
            if (isStrengthPotion(stack)) {
                if (keptStrength < 4) { keptStrength++; continue; }
            }

            return true;
        }
        return false;
    }

    public static boolean isCombatReady(class_310 client) {
        if (client.field_1724 == null) return false;
        boolean hasArmor = !client.field_1724.method_6118(net.minecraft.class_1304.field_6174).method_7960();
        boolean hasWeapon = CombatManager.hasSword(client);
        return hasArmor && hasWeapon;
    }

    public static String getMasterName(class_310 client) {
        if (client == null || client.field_1724 == null) return "itzNatsuu";
        
        String pName = client.field_1724.method_5477().getString().toLowerCase();
        String sbName = "";

        if (client.field_1687 != null) {
            net.minecraft.class_269 scoreboard = client.field_1687.method_8428();
            if (scoreboard != null) {
                net.minecraft.class_266 obj = scoreboard.method_1189(net.minecraft.class_8646.field_45157);
                if (obj != null) {
                    sbName = Autotpa.cleanText(obj.method_1114().getString()).toLowerCase();
                }
            }
        }

        if (pName.contains("llamaposh") || sbName.contains("llamaposh")) {
            return "miles_1dk";
        }

        if (pName.contains("mile") || sbName.contains("mile")) {
            return "obo_pro15";
        }

        return "itzNatsuu";
    }

    private static boolean clickConfirmIfPresent(class_310 client, class_476 screen) {
        if (screen == null || client.field_1761 == null || client.field_1724 == null) return false;
        int syncId = screen.method_17577().field_7763;
        int totalSlots = screen.method_17577().field_7761.size();

        for (int i = 0; i < Math.min(totalSlots, 54); i++) {
            class_1799 stack = screen.method_17577().method_7611(i).method_7677();
            if (stack.method_7960()) continue;
            String name = Autotpa.cleanText(stack.method_7964().getString()).toLowerCase();

            if (name.contains("auction") || name.contains("аукцион") || name.contains("/ah")) continue;

            if (name.contains("стак") || name.contains("stack") || name.contains("64")) {
                client.field_1761.method_2906(syncId, i, 0, class_1713.field_7790, client.field_1724);
                Autotpa.sendFeedback("§a[Shop] Выбран стак: " + stack.method_7964().getString());
                return true;
            }
        }

        for (int i = 0; i < Math.min(totalSlots, 54); i++) {
            class_1799 stack = screen.method_17577().method_7611(i).method_7677();
            if (stack.method_7960()) continue;
            String name = Autotpa.cleanText(stack.method_7964().getString()).toLowerCase();

            if (name.contains("auction") || name.contains("аукцион") || name.contains("/ah")) continue;

            if (name.contains("подтверд") || name.contains("confirm") || name.contains("купить") 
                    || name.contains("buy") || name.contains("принять") || name.equals("да") 
                    || name.equals("yes") || name.contains("соглас")) {
                
                client.field_1761.method_2906(syncId, i, 0, class_1713.field_7790, client.field_1724);
                Autotpa.sendFeedback("§a[Shop] Подтверждение покупки: " + stack.method_7964().getString());
                return true;
            }
        }
        return false;
    }

    public static void checkBalanceAndAutoPay(class_310 client) {
        if (payCooldownTicks > 0) {
            payCooldownTicks--;
            return;
        }

        if (client.field_1687 == null || client.field_1724 == null) return;
        if (CombatManager.isCombatActive(client)) return;

        net.minecraft.class_269 scoreboard = client.field_1687.method_8428();
        if (scoreboard == null) return;

        net.minecraft.class_266 objective = scoreboard.method_1189(net.minecraft.class_8646.field_45157);
        if (objective == null) return;

        double currentBalance = 0;

        for (net.minecraft.class_9011 entry : scoreboard.method_1184(objective)) {
            String owner = entry.comp_2127();
            net.minecraft.class_268 team = scoreboard.method_1164(owner);
            String line = net.minecraft.class_268.method_1142(team, class_2561.method_43470(owner)).getString();
            String clean = Autotpa.cleanText(line);

            if (clean.contains("$")) {
                Matcher m = Pattern.compile("(?i)\\$\\s*([0-9.,]+(?:[kmb])?)").matcher(clean);
                if (m.find()) {
                    currentBalance = parsePriceValue(m.group(1));
                    break;
                }
            }
        }

        if (currentBalance >= 30_000_000.0) {
            String recipient = getMasterName(client);
            CommandQueue.send("pay " + recipient + " 20m");
            Autotpa.sendFeedback("§a[AutoPay] Баланс: §e$" + String.format(Locale.US, "%.1fM", currentBalance / 1_000_000.0) + " §a(>=30M)! Отправил §b/pay " + recipient + " 20m");
            payCooldownTicks = 600;
        } else {
            payCooldownTicks = 100;
        }
    }

    private static boolean hasFreeSlot(class_310 client) {
        if (client.field_1724 == null) return false;
        for (int i = 0; i <= 35; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7960()) return true;
        }
        return false;
    }

    public static double getItemPrice(class_310 client, class_1799 stack) {
        String pStr = extractPrice(client, stack);
        return parsePriceValue(pStr);
    }

    public static double parsePriceValue(String priceStr) {
        if (priceStr == null || priceStr.isEmpty()) return 0;
        priceStr = priceStr.toLowerCase().replaceAll("[\\s$~]", "");
        double multiplier = 1.0;
        if (priceStr.endsWith("k")) {
            multiplier = 1_000.0;
            priceStr = priceStr.substring(0, priceStr.length() - 1);
        } else if (priceStr.endsWith("m")) {
            multiplier = 1_000_000.0;
            priceStr = priceStr.substring(0, priceStr.length() - 1);
        } else if (priceStr.endsWith("b")) {
            multiplier = 1_000_000_000.0;
            priceStr = priceStr.substring(0, priceStr.length() - 1);
        }
        try {
            return Double.parseDouble(priceStr) * multiplier;
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static String extractPrice(class_310 client, class_1799 stack) {
        try {
            if (client.field_1724 == null || stack == null || stack.method_7960()) return null;

            net.minecraft.class_9290 lore = stack.method_58694(class_9334.field_49632);
            if (lore != null) {
                for (class_2561 line : lore.comp_2400()) {
                    String cleanLine = Autotpa.cleanText(line.getString());
                    Matcher m = PRICE_PATTERN.matcher(cleanLine);
                    if (m.find()) {
                        String p = m.group(1).replaceAll("[\\s,]", "").toLowerCase();
                        if (!p.isEmpty() && Character.isDigit(p.charAt(0))) {
                            return p;
                        }
                    }
                }
            }

            List<class_2561> tooltip = stack.method_7950(class_1792.class_9635.field_51353, client.field_1724, class_1836.class_1837.field_41071);
            for (class_2561 line : tooltip) {
                String cleanLine = Autotpa.cleanText(line.getString());
                Matcher m = PRICE_PATTERN.matcher(cleanLine);
                if (m.find()) {
                    String p = m.group(1).replaceAll("[\\s,]", "").toLowerCase();
                    if (!p.isEmpty() && Character.isDigit(p.charAt(0))) {
                        return p;
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static void selectHotbarSlot(class_310 client, int slotIndex) {
        if (client.field_1724 == null) return;
        if (client.field_1724.method_31548().method_67532() != slotIndex) {
            client.field_1724.method_31548().method_61496(slotIndex);
            if (client.method_1562() != null) {
                client.method_1562().method_52787(new net.minecraft.class_2868(slotIndex));
            }
        }
    }

    private static void restoreWeapon(class_310 client, int slot) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        client.field_1761.method_2906(client.field_1724.field_7498.field_7763, slot, 0, class_1713.field_7791, client.field_1724);
    }

    public static String buildAhSearchQuery(class_1799 stack) {
        if (stack == null || stack.method_7960()) return "";
        class_1792 item = stack.method_7909();
        String name = item.toString().toLowerCase();

        StringBuilder query = new StringBuilder();

        if (name.contains("netherite_chestplate")) query.append("neth chestplate");
        else if (name.contains("netherite_helmet")) query.append("neth helmet");
        else if (name.contains("netherite_leggings")) query.append("neth leggings");
        else if (name.contains("netherite_boots")) query.append("neth boots");
        else if (name.contains("netherite_sword")) query.append("neth sword");
        else if (name.contains("netherite_pickaxe")) query.append("neth pickaxe");
        else if (name.contains("netherite_axe")) query.append("neth axe");
        else if (name.contains("netherite_shovel")) query.append("neth shovel");
        else if (name.contains("netherite_hoe")) query.append("neth hoe");
        else if (item == class_1802.field_49814 || name.contains("mace")) query.append("mace");
        else {
            query.append(name.replace("minecraft:", "").replace("_", " "));
        }

        class_9304 component = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        for (class_6880<class_1887> entry : component.method_57534()) {
            String rawKey = entry.method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse(entry.toString().toLowerCase());
            int lvl = component.method_57536(entry);

            String cleanEnchantName = rawKey.replace("_", " ");
            query.append(" ").append(cleanEnchantName);

            if (lvl > 1 || (!cleanEnchantName.equals("mending") && !cleanEnchantName.equals("silk touch") && !cleanEnchantName.equals("aqua affinity"))) {
                query.append(" ").append(lvl);
            }
        }

        return query.toString().trim();
    }

    public static boolean isPower5Bow(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (stack.method_7909() != class_1802.field_8102) return false;

        class_9304 component = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        for (class_6880<class_1887> entry : component.method_57534()) {
            String key = entry.method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse(entry.toString().toLowerCase());
            int lvl = component.method_57536(entry);
            if (key.contains("power") && lvl >= 5) return true;
        }
        return false;
    }

    public static String formatPrice(double price) {
        if (price >= 1_000_000.0) {
            double inM = price / 1_000_000.0;
            if (inM == (long) inM) {
                return String.format(Locale.US, "%dm", (long) inM);
            } else {
                return String.format(Locale.US, "%.1fm", inM);
            }
        } else if (price >= 1_000.0) {
            double inK = price / 1_000.0;
            if (inK == (long) inK) {
                return String.format(Locale.US, "%dk", (long) inK);
            } else {
                return String.format(Locale.US, "%.0fk", inK);
            }
        } else {
            return String.valueOf((long) Math.max(1000, price));
        }
    }

    public static boolean isMaxedArmor(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        boolean isArmor = (item == class_1802.field_8805 || item == class_1802.field_8058 
                        || item == class_1802.field_8348 || item == class_1802.field_8285
                        || item == class_1802.field_22027 || item == class_1802.field_22028 
                        || item == class_1802.field_22029 || item == class_1802.field_22030);
        if (!isArmor) return false;

        class_9304 component = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        boolean hasProt = false;
        boolean hasMending = false;
        boolean hasUnb = false;
        boolean hasThorns = false;

        for (class_6880<class_1887> entry : component.method_57534()) {
            String key = entry.method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse(entry.toString().toLowerCase());
            int lvl = component.method_57536(entry);
            if (key.equals("protection") && lvl >= 4) hasProt = true;
            if (key.contains("mending") && lvl >= 1) hasMending = true;
            if (key.contains("unbreaking") && lvl >= 3) hasUnb = true;
            if (key.contains("thorns") && lvl >= 3) hasThorns = true;
        }

        boolean isTorso = (item == class_1802.field_8058 || item == class_1802.field_22028
                        || item == class_1802.field_8348 || item == class_1802.field_22029);

        if (isTorso) {
            return hasProt && hasMending && hasUnb && hasThorns;
        }

        return hasProt && hasMending && hasUnb;
    }

    public static boolean isEfficiency5Pickaxe(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        if (item != class_1802.field_8377 && item != class_1802.field_22024) return false;

        class_9304 component = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        boolean hasEff5 = false;

        for (class_6880<class_1887> entry : component.method_57534()) {
            String key = entry.method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse(entry.toString().toLowerCase());
            int lvl = component.method_57536(entry);
            if (key.contains("efficiency") && lvl >= 5) hasEff5 = true;
        }

        return hasEff5;
    }

    public static String getArmorAhPrice(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;
        class_1792 item = stack.method_7909();
        
        boolean isArmor = (item == class_1802.field_8805 || item == class_1802.field_8058 
                        || item == class_1802.field_8348 || item == class_1802.field_8285
                        || item == class_1802.field_22027 || item == class_1802.field_22028 
                        || item == class_1802.field_22029 || item == class_1802.field_22030);
        if (!isArmor) return null;

        double hoverPrice = getItemPrice(client, stack);
        if (hoverPrice > 0) {
            double priceToUse = Math.max(1000.0, hoverPrice - 1000.0);
            return formatPrice(priceToUse);
        }

        String normKey = getNormalizedEnchantKey(stack);
        if (dynamicShopPrices.containsKey(new NormalizedGearKey(item, normKey))) {
            return dynamicShopPrices.get(new NormalizedGearKey(item, normKey));
        }

        return null;
    }

    public static boolean isMaxedSword(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        if (item != class_1802.field_8802 && item != class_1802.field_22022) return false;

        class_9304 component = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        boolean hasSharp = false;
        boolean hasMending = false;
        boolean hasUnb = false;

        for (class_6880<class_1887> entry : component.method_57534()) {
            String key = entry.method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse(entry.toString().toLowerCase());
            int lvl = component.method_57536(entry);
            if (key.contains("sharpness") && lvl >= 5) hasSharp = true;
            if (key.contains("mending") && lvl >= 1) hasMending = true;
            if (key.contains("unbreaking") && lvl >= 3) hasUnb = true;
        }

        return hasSharp && hasMending && hasUnb;
    }

    public static boolean isBowItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (stack.method_7909() == class_1802.field_8102) return true;
        String name = stack.method_7964().getString().toLowerCase();
        return (name.contains("лук") || name.contains("bow")) && !name.contains("cross") && !name.contains("арбалет");
    }

    public static boolean hasMaxedSwordInInventory(class_310 client) {
        if (client.field_1724 == null) return false;
        for (int i = 0; i <= 35; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (isMaxedSword(client, s)) return true;
        }
        return false;
    }

    public static boolean hasArmorPiece(class_310 client, String type) {
        if (client.field_1724 == null) return false;
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_5925() == class_1304.class_1305.field_6178) {
                class_1799 s = client.field_1724.method_6118(slot);
                if (matchesType(s.method_7909(), type)) return true;
            }
        }
        for (int i = 0; i <= 35; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (matchesType(s.method_7909(), type)) return true;
        }
        return false;
    }

    private static boolean matchesType(class_1792 item, String type) {
        if (item == null) return false;
        String name = item.toString().toLowerCase();
        return switch (type) {
            case "sword" -> name.contains("sword");
            case "axe" -> (name.contains("_axe") || name.endsWith("axe")) && !name.contains("pickaxe"); 
            case "pickaxe" -> name.contains("pickaxe");
            case "shovel" -> name.contains("shovel");
            case "hoe" -> name.contains("hoe");
            case "bow" -> item == class_1802.field_8102 || (name.contains("bow") && !name.contains("cross"));
            case "cobweb" -> item == class_1802.field_8786;
            case "pearl" -> item == class_1802.field_8634;
            case "obsidian" -> item == class_1802.field_8281;
            case "totem" -> item == class_1802.field_8288;
            case "mace" -> item == class_1802.field_49814 || name.contains("mace");
            case "helmet" -> name.contains("helmet") || name.contains("cap");
            case "chestplate" -> name.contains("chestplate") || name.contains("tunic");
            case "leggings" -> name.contains("leggings") || name.contains("pants");
            case "boots" -> name.contains("boots");
            default -> false;
        };
    }

    private static String getNormalizedEnchantKey(class_1799 stack) {
        class_9304 component = stack.method_58695(class_9334.field_49633, class_9304.field_49385);
        List<String> list = new ArrayList<>();
        for (class_6880<class_1887> entry : component.method_57534()) {
            String key = entry.method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse(entry.toString().toLowerCase());
            list.add(key + "=" + component.method_57536(entry));
        }
        Collections.sort(list);
        return String.join(";", list);
    }

    public static String getToolAhPrice(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;
        class_1792 item = stack.method_7909();
        
        boolean isDiamondTool = (item == class_1802.field_8802 || item == class_1802.field_8377 || item == class_1802.field_8556);
        if (!isDiamondTool) return null;

        double hoverPrice = getItemPrice(client, stack);
        if (hoverPrice > 0) {
            double priceToUse = Math.max(1000.0, hoverPrice - 1000.0);
            return formatPrice(priceToUse);
        }

        String normKey = getNormalizedEnchantKey(stack);
        if (dynamicShopPrices.containsKey(new NormalizedGearKey(item, normKey))) {
            return dynamicShopPrices.get(new NormalizedGearKey(item, normKey));
        }

        return null;
    }
}
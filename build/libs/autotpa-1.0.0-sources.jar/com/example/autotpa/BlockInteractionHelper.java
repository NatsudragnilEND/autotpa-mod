package com.example.autotpa;

import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2478;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class BlockInteractionHelper {

    public static final int SLOT_SWORD = 0;
    public static final int SLOT_COBWEB = 1;
    public static final int SLOT_AXE = 2;
    public static final int SLOT_PEARL = 3;
    public static final int SLOT_GAPPLE = 4;
    public static final int SLOT_OBSIDIAN = 5;
    public static final int SLOT_BOW = 6;
    public static final int SLOT_PICKAXE = 7;
    public static final int SLOT_POTION = 8;

    private static class_2338 currentBreakingBlock = null;
    private static class_2248 initialBreakingBlockType = null;
    private static class_2350 lockedBreakingSide = null;

    private static int breakingTicks = 0;
    private static int toolSwitchCooldown = 0;
    private static int postBreakTicks = 0;

    // СИСТЕМА УМНОЙ ПАУЗЫ ПРИ СБОЕ (BACKOFF)
    private static int breakRetryCooldown = 0;
    private static int consecutiveFailures = 0;

    public static boolean isBreaking() {
        return currentBreakingBlock != null || breakRetryCooldown > 0;
    }

    // =========================================================================
    // BARITONE-НАВОДКА: СМЕЩЕНИЕ ОТ ЦЕНТРА (0.30 - 0.70) + ОБХОД АНТИЧИТА
    // =========================================================================
    public static class_243 getNaturalAimPoint(class_310 client, class_2338 pos, boolean isCobweb) {
        // Уникальное смещение для каждого блока (никогда не 0.500 ровно)
        long hash = pos.method_10063();
        double offX = 0.30 + (((hash & 0xFF) % 40) / 100.0);         // 0.30 - 0.70
        double offY = isCobweb ? (0.25 + ((((hash >> 4) & 0xFF) % 20) / 100.0))
                               : (0.35 + ((((hash >> 8) & 0xFF) % 30) / 100.0));
        double offZ = 0.30 + ((((hash >> 16) & 0xFF) % 40) / 100.0); // 0.30 - 0.70

        // Органическое микро-движение руки
        double driftX = Math.sin(breakingTicks * 0.15) * 0.02;
        double driftY = Math.cos(breakingTicks * 0.15) * 0.02;
        double driftZ = Math.sin((breakingTicks + 3) * 0.15) * 0.02;

        class_243 eye = (client.field_1724 != null) ? client.field_1724.method_33571() : class_243.method_24953(pos);
        class_243 raw = new class_243(pos.method_10263() + offX + driftX, pos.method_10264() + offY + driftY, pos.method_10260() + offZ + driftZ);

        // Если голова внутри паутины — выносим прицел чуть вперед, чтобы рейкаст шел сквозь блок
        if (eye.method_1025(raw) < 0.75) {
            float yawRad = (float) Math.toRadians(client.field_1724 != null ? client.field_1724.method_36454() : 0);
            double fwdX = -Math.sin(yawRad) * 0.30;
            double fwdZ = Math.cos(yawRad) * 0.30;
            return new class_243(pos.method_10263() + 0.5 + fwdX, pos.method_10264() + offY, pos.method_10260() + 0.5 + fwdZ);
        }

        return raw;
    }

    public static boolean aimAtBlock(class_310 client, class_2338 pos, boolean isCobweb) {
        if (client.field_1724 == null || client.field_1690 == null) return false;

        class_243 eye = client.field_1724.method_33571();
        class_243 target = getNaturalAimPoint(client, pos, isCobweb);

        double dx = target.field_1352 - eye.field_1352;
        double dy = target.field_1351 - eye.field_1351;
        double dz = target.field_1350 - eye.field_1350;
        double hDist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (hDist > 0.005)
                ? (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0)
                : client.field_1724.method_36454();

        float targetPitch = (float) class_3532.method_15338(-Math.toDegrees(Math.atan2(dy, hDist)));
        targetPitch = class_3532.method_15363(targetPitch, -89.5f, 89.5f);

        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();

        float deltaYaw = class_3532.method_15393(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;

        float speed = Math.min(50.0f, Math.max(10.0f, (float) Math.hypot(deltaYaw, deltaPitch) * 0.7f));
        float stepYaw = class_3532.method_15363(deltaYaw, -speed, speed);
        float stepPitch = class_3532.method_15363(deltaPitch, -speed, speed);

        // Расчет шага сенсора мыши (GCD)
        double sensitivity = client.field_1690.method_42495().method_41753();
        double f = sensitivity * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;

        if (gcd > 0.0001) {
            stepYaw = (float) (Math.round(stepYaw / gcd) * gcd);
            stepPitch = (float) (Math.round(stepPitch / gcd) * gcd);
        }

        client.field_1724.method_36456(currentYaw + stepYaw);
        client.field_1724.method_36457(class_3532.method_15363(currentPitch + stepPitch, -89.5f, 89.5f));

        return Math.abs(deltaPitch) < 25.0f && Math.abs(deltaYaw) < 25.0f;
    }

    // =========================================================================
    // БЕЗУПРЕЧНОЕ ЛОМАНИЕ С СИСТЕМОЙ ПРОГРЕССИВНОГО ПЕРЕРЫВА
    // =========================================================================
    public static boolean breakBlockLegit(class_310 client, class_2338 pos) {
        if (client.field_1687 == null || client.field_1724 == null || client.field_1761 == null) {
            stopBreaking(client);
            return false;
        }

        // Защита от переключения между разными координатами паутины
        if (currentBreakingBlock != null && !currentBreakingBlock.equals(pos)) {
            class_2680 activeState = client.field_1687.method_8320(currentBreakingBlock);
            if (activeState.method_27852(class_2246.field_10343) && client.field_1687.method_8320(pos).method_27852(class_2246.field_10343)
                    && currentBreakingBlock.method_19769(client.field_1724.method_33571(), 3.5)) {
                pos = currentBreakingBlock;
            }
        }

        class_2680 currentState = client.field_1687.method_8320(pos);

        // 1. Успех: блок сломан
        if (currentState.method_26215() || (initialBreakingBlockType != null && !currentState.method_27852(initialBreakingBlockType))) {
            postBreakTicks++;
            if (postBreakTicks < 2) return true;
            stopBreaking(client);
            consecutiveFailures = 0;
            breakRetryCooldown = 0;
            return false;
        }

        postBreakTicks = 0;
        if (currentState.method_26214(client.field_1687, pos) < 0.0f) {
            stopBreaking(client);
            consecutiveFailures = 0;
            breakRetryCooldown = 0;
            return false;
        }

        boolean isCobweb = currentState.method_27852(class_2246.field_10343);

        // 2. СИСТЕМА ПАУЗЫ: если был сбой — выжидаем время и НЕ шлем пакеты
        if (breakRetryCooldown > 0) {
            breakRetryCooldown--;
            aimAtBlock(client, pos, isCobweb);
            if (client.field_1690 != null) {
                client.field_1690.field_1886.method_23481(false);
            }
            return true;
        }

        // 3. Подготовка меча
        if (isCobweb) {
            if (!ensureSwordInHand(client)) {
                return true;
            }
        } else {
            selectOptimalTool(client, currentState);
            if (toolSwitchCooldown > 0) {
                toolSwitchCooldown--;
                return true;
            }
        }

        // 4. Поворот головы (не в центр, а под естественным углом)
        boolean onTarget = aimAtBlock(client, pos, isCobweb);

        // 5. Инициализация цели
        if (currentBreakingBlock == null || !currentBreakingBlock.equals(pos)) {
            stopBreaking(client);
            currentBreakingBlock = pos;
            initialBreakingBlockType = currentState.method_26204();
            breakingTicks = 0;
            postBreakTicks = 0;
            lockedBreakingSide = null;
        }

        // 6. Определение честной грани через рейкаст
        if (lockedBreakingSide == null) {
            class_243 targetPoint = getNaturalAimPoint(client, pos, isCobweb);
            class_243 eye = client.field_1724.method_33571();
            class_3965 bhr = client.field_1687.method_17742(new class_3959(
                    eye, targetPoint, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, client.field_1724
            ));

            if (bhr.method_17783() == class_239.class_240.field_1332 && bhr.method_17777().equals(pos)) {
                lockedBreakingSide = bhr.method_17780();
            } else {
                lockedBreakingSide = (eye.field_1351 >= pos.method_10264() + 0.5) ? class_2350.field_11036 : class_2350.field_11033;
            }
        }

        // 7. РАСЧЕТ ВРЕМЕНИ И ОБНАРУЖЕНИЕ СБОЯ
        float delta = currentState.method_26165(client.field_1724, client.field_1687, pos);
        int expectedTicks = (delta > 0.0f) ? (int) Math.ceil(1.0f / delta) : (isCobweb ? 40 : 100);
        int maxAllowedTicks = expectedTicks + 25; // запас на пинг

        // ЕСЛИ СЛУЧИЛСЯ СБОЙ: делаем ощутимый перерыв перед повторной попыткой!
        if (breakingTicks > maxAllowedTicks) {
            stopBreaking(client);
            consecutiveFailures++;

            // 1-й сбой: пауза 15 тиков (0.75 сек)
            // 2-й сбой подряд: пауза 30 тиков (1.5 сек)
            // 3-й сбой: пауза 50 тиков (2.5 сек)
            if (consecutiveFailures == 1) {
                breakRetryCooldown = 15;
            } else if (consecutiveFailures == 2) {
                breakRetryCooldown = 30;
            } else {
                breakRetryCooldown = 50;
                consecutiveFailures = 0;
            }
            return true;
        }

        if (breakingTicks == 0 && !onTarget) {
            return true;
        }

        // 8. СИНХРОНИЗАЦИЯ С ДВИЖКОМ MINECRAFT (ЧЕСТНАЯ 1X СКОРОСТЬ)
        // Фиксируем прицел на блоке и зажимаем клавишу атаки
        class_243 aimP = getNaturalAimPoint(client, pos, isCobweb);
        client.field_1765 = new class_3965(aimP, lockedBreakingSide, pos, false);

        if (client.field_1690 != null) {
            client.field_1690.field_1886.method_23481(true);
        }

        breakingTicks++;
        return true;
    }

    public static void stopBreaking(class_310 client) {
        if (client != null) {
            if (client.field_1690 != null) {
                client.field_1690.field_1886.method_23481(false);
            }
            if (client.field_1761 != null && currentBreakingBlock != null && client.field_1687 != null) {
                class_2680 state = client.field_1687.method_8320(currentBreakingBlock);
                if (initialBreakingBlockType != null && state.method_27852(initialBreakingBlockType)) {
                    client.field_1761.method_2925();
                }
            }
        }
        currentBreakingBlock = null;
        initialBreakingBlockType = null;
        lockedBreakingSide = null;
        breakingTicks = 0;
        postBreakTicks = 0;
    }

    public static void cancelBreaking(class_310 client) {
        stopBreaking(client);
        breakRetryCooldown = 0;
        consecutiveFailures = 0;
    }

    // =========================================================================
    // УСТАНОВКА БЛОКОВ
    // =========================================================================
    // =========================================================================
    // УСТАНОВКА БЛОКОВ (ПАУТИНА В НОГИ + ЭНДЕР-СУНДУКИ В СТЕНЫ 1x1, БЕЗ КРЫШИ)
    // =========================================================================
    public static boolean placeBlockLegit(class_310 client, class_2338 targetPos, class_1792 itemToPlace) {
        if (client.field_1687 == null || client.field_1724 == null || client.field_1761 == null) return false;

        if (client.field_1690 != null) {
            client.field_1690.field_1886.method_23481(false);
        }

        // Стены (эндер-сундуки / обсидиан) берем в слот 5 (SLOT_OBSIDIAN), паутину — в слот 1 (SLOT_COBWEB)
        int targetHotbarSlot = (itemToPlace == class_1802.field_8281 || itemToPlace == class_1802.field_8466) ? SLOT_OBSIDIAN : SLOT_COBWEB;

        // Если нужного блока нет в хотбаре — достаем из рюкзака (слоты 9-35)
        if (!client.field_1724.method_31548().method_5438(targetHotbarSlot).method_31574(itemToPlace)) {
            for (int i = 9; i <= 35; i++) {
                if (client.field_1724.method_31548().method_5438(i).method_31574(itemToPlace)) {
                    int syncId = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(syncId, i, targetHotbarSlot, class_1713.field_7791, client.field_1724);
                    break;
                }
            }
        }

        if (!client.field_1724.method_31548().method_5438(targetHotbarSlot).method_31574(itemToPlace)) return false;

        class_243 eye = client.field_1724.method_33571();
        class_2338 trapFeet = CombatManager.getTrapFeetPos(client);

        // 1. УСТАНОВКА ЕДИНСТВЕННОЙ ПАУТИНЫ В НОГИ (на верхнюю грань блока под ногами)
        if (trapFeet != null && targetPos.equals(trapFeet)) {
            aimAtBlock(client, targetPos, true);
            if (client.field_1724.method_36455() < 65.0f) return false;

            selectSlot(client, targetHotbarSlot);
            class_243 straightDown = new class_243(eye.field_1352, targetPos.method_10264(), eye.field_1350);
            class_3965 hitResult = new class_3965(straightDown, class_2350.field_11036, targetPos.method_10074(), false);
            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
            client.field_1724.method_6104(class_1268.field_5808);
            return true;
        }

        // 2. УСТАНОВКА СТЕН (ЭНДЕР-СУНДУКОВ) ИЛИ СУШКА ИСТОЧНИКОВ ЖИДКОСТИ
        // Ищем соседний твёрдый блок, на грань которого можно поставить блок
        class_2338 bestNeighbor = null;
        class_2350 bestSide = null;
        class_243 bestHitVec = null;
        double bestDist = Double.MAX_VALUE;

        class_2350[] checkDirs = { class_2350.field_11033, class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039 };

        for (class_2350 dir : checkDirs) {
            class_2338 neighbor = targetPos.method_10093(dir);
            class_2680 nState = client.field_1687.method_8320(neighbor);

            if (nState.method_26215() || nState.method_27852(class_2246.field_10343) || nState.method_27852(class_2246.field_10382) || nState.method_27852(class_2246.field_10164)
                    || !nState.method_26227().method_15769() || !nState.method_26212(client.field_1687, neighbor)) {
                continue;
            }

            class_2350 side = dir.method_10153();
            class_243 hitP = class_243.method_24953(neighbor).method_1031(side.method_10148() * 0.45, side.method_10164() * 0.45, side.method_10165() * 0.45);

            class_3965 ray = client.field_1687.method_17742(new class_3959(
                    eye, hitP, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, client.field_1724
            ));

            if (ray.method_17783() == class_239.class_240.field_1332 && ray.method_17777().equals(neighbor)) {
                double d = eye.method_1025(hitP);
                if (d < bestDist) {
                    bestDist = d;
                    bestNeighbor = neighbor;
                    bestSide = side;
                    bestHitVec = hitP;
                }
            }
        }

        // Резервный поиск, если рейкаст слегка скользит по краю
        if (bestNeighbor == null) {
            for (class_2350 dir : checkDirs) {
                class_2338 neighbor = targetPos.method_10093(dir);
                class_2680 nState = client.field_1687.method_8320(neighbor);
                if (!nState.method_26215() && !nState.method_27852(class_2246.field_10382) && !nState.method_27852(class_2246.field_10164)
                        && nState.method_26227().method_15769() && nState.method_26212(client.field_1687, neighbor)) {
                    bestNeighbor = neighbor;
                    bestSide = dir.method_10153();
                    bestHitVec = class_243.method_24953(neighbor).method_1031(bestSide.method_10148() * 0.45, bestSide.method_10164() * 0.45, bestSide.method_10165() * 0.45);
                    break;
                }
            }
        }

        if (bestNeighbor == null || bestSide == null || bestHitVec == null) return false;

        // Поворот камеры на блок-опору (естественный аим)
        aimAtBlock(client, bestNeighbor, false);

        selectSlot(client, targetHotbarSlot);
        class_3965 hitResult = new class_3965(bestHitVec, bestSide, bestNeighbor, false);
        client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
        client.field_1724.method_6104(class_1268.field_5808);

        return true;
    }
    // =========================================================================
    // УСТАНОВКА ПАУТИНЫ ПОВЕРХ ДРУГОЙ ПАУТИНЫ (ДЛЯ СУШКИ ЛАВЫ И ВОДЫ СВЕРХУ)
    // =========================================================================
    public static boolean placeCobwebOnTopOf(class_310 client, class_2338 basePos) {
        if (client.field_1687 == null || client.field_1724 == null || client.field_1761 == null) return false;

        // Достаем паутину в слот 1 (SLOT_COBWEB), если ее там нет
        if (!client.field_1724.method_31548().method_5438(SLOT_COBWEB).method_31574(class_1802.field_8786)) {
            for (int i = 9; i <= 35; i++) {
                if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8786)) {
                    int syncId = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(syncId, i, SLOT_COBWEB, class_1713.field_7791, client.field_1724);
                    break;
                }
            }
        }
        if (!client.field_1724.method_31548().method_5438(SLOT_COBWEB).method_31574(class_1802.field_8786)) return false;

        selectSlot(client, SLOT_COBWEB);

        // Смотрим строго вниз на верхнюю грань базовой паутины
        class_243 hitVec = new class_243(basePos.method_10263() + 0.5, basePos.method_10264() + 0.98, basePos.method_10260() + 0.5);
        aimAtBlock(client, basePos, true);

        // Кликаем по верхней грани (Direction.UP)
        class_3965 hitResult = new class_3965(hitVec, class_2350.field_11036, basePos, false);
        client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
        client.field_1724.method_6104(class_1268.field_5808);
        return true;
    }
    public static void selectOptimalTool(class_310 client, class_2680 state) {
        if (client.field_1724 == null) return;

        if (state.method_27852(class_2246.field_10343)) {
            ensureSwordInHand(client);
            return;
        }

        class_1799 axeStack = client.field_1724.method_31548().method_5438(SLOT_AXE);
        class_1799 pickaxeStack = client.field_1724.method_31548().method_5438(SLOT_PICKAXE);

        float axeSpeed = isAxeItem(axeStack) ? axeStack.method_7924(state) : 1.0f;
        float pickaxeSpeed = isPickaxeItem(pickaxeStack) ? pickaxeStack.method_7924(state) : 1.0f;

        if (axeSpeed > pickaxeSpeed && axeSpeed > 1.0f) {
            ensureAxeInHand(client);
        } else if (pickaxeSpeed > 1.0f) {
            ensurePickaxeInHand(client);
        } else if (isAxeBlock(state)) {
            ensureAxeInHand(client);
        } else {
            ensurePickaxeInHand(client);
        }
    }

    public static boolean isAxeBlock(class_2680 state) {
        if (state.method_26204() instanceof class_2478) return true;
        String name = state.method_26204().toString().toLowerCase();
        return name.contains("sign") || name.contains("banner") || name.contains("wood") 
                || name.contains("log") || name.contains("plank") || name.contains("door") 
                || name.contains("fence") || name.contains("gate") || name.contains("barrel")
                || name.contains("chest") || name.contains("bookshelf") || name.contains("crafting")
                || name.contains("pumpkin") || name.contains("melon");
    }

    private static boolean selectSlot(class_310 client, int slot) {
        if (client.field_1724 != null && client.field_1724.method_31548().method_67532() != slot) {
            client.field_1724.method_31548().method_61496(slot);
            if (client.method_1562() != null) {
                client.method_1562().method_52787(new class_2868(slot));
            }
            toolSwitchCooldown = 1;
            return true;
        }
        return false;
    }

    public static boolean ensureSwordInHand(class_310 client) {
        if (client.field_1724 == null) return false;
        if (isSwordItem(client.field_1724.method_6047())) return true;

        class_1799 slotStack = client.field_1724.method_31548().method_5438(SLOT_SWORD);
        if (isSwordItem(slotStack)) {
            selectSlot(client, SLOT_SWORD);
            return false;
        }

        for (int i = 0; i < 9; i++) {
            if (isSwordItem(client.field_1724.method_31548().method_5438(i))) {
                selectSlot(client, i);
                return false;
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (isSwordItem(stack)) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, SLOT_SWORD, class_1713.field_7791, client.field_1724);
                toolSwitchCooldown = 2;
                selectSlot(client, SLOT_SWORD);
                return false;
            }
        }
        return false;
    }

    public static boolean ensurePickaxeInHand(class_310 client) {
        if (client.field_1724 == null) return false;
        if (isPickaxeItem(client.field_1724.method_6047())) return true;

        class_1799 slotStack = client.field_1724.method_31548().method_5438(SLOT_PICKAXE);
        if (isPickaxeItem(slotStack)) return selectSlot(client, SLOT_PICKAXE);

        for (int i = 0; i <= 35; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (isPickaxeItem(stack)) {
                if (i < 9) {
                    return selectSlot(client, i);
                } else {
                    int syncId = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(syncId, i, SLOT_PICKAXE, class_1713.field_7791, client.field_1724);
                    toolSwitchCooldown = 2;
                    return selectSlot(client, SLOT_PICKAXE);
                }
            }
        }
        return false;
    }

    public static boolean ensureAxeInHand(class_310 client) {
        if (client.field_1724 == null) return false;
        if (isAxeItem(client.field_1724.method_6047())) return true;

        class_1799 slotStack = client.field_1724.method_31548().method_5438(SLOT_AXE);
        if (isAxeItem(slotStack)) return selectSlot(client, SLOT_AXE);

        for (int i = 0; i <= 35; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (isAxeItem(stack)) {
                if (i < 9) {
                    return selectSlot(client, i);
                } else {
                    int syncId = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(syncId, i, SLOT_AXE, class_1713.field_7791, client.field_1724);
                    toolSwitchCooldown = 2;
                    return selectSlot(client, SLOT_AXE);
                }
            }
        }
        return false;
    }

    public static boolean isPickaxeItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return stack.method_7909().toString().toLowerCase().contains("pickaxe");
    }

    public static boolean isAxeItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        String name = stack.method_7909().toString().toLowerCase();
        return (name.contains("_axe") || name.endsWith("axe")) && !name.contains("pickaxe");
    }

    public static boolean isSwordItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return stack.method_7909().toString().toLowerCase().contains("sword");
    }
}
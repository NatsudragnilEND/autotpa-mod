package com.example.autotpa;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_418;
import net.minecraft.class_419;
import org.lwjgl.glfw.GLFW;
import java.io.File;
import java.util.regex.Pattern;

public class Autotpa implements ClientModInitializer {

    public enum BotState {
        IDLE_TRAPPING,
        DISCONNECTED_WAITING,
        RECONNECTED_SETUP,
        ESCAPE_EATING_CHORUS,
        ESCAPE_RUNNING,
        STARTING_REGEAR, 
        ESCAPE_HOME3_WAIT,
        TRAP_BUILDING,
        STARTING_SETUP_HOME1 // Безопасный запуск: сначала /home 1, затем ловля
    }

    public static BotState currentBotState = BotState.IDLE_TRAPPING;
    public static boolean isMasterBotEnabled = false;

    private static final Pattern COLOR_PATTERN = Pattern.compile("(?i)[§&][0-9A-FK-OR]");
    public static class_304 menuKey;

    @Override
    public void onInitializeClient() {
        class_310 client = class_310.method_1551();
        File configDir = new File(client.field_1697, "config");
        if (!configDir.exists()) configDir.mkdirs();
        FriendManager.init(configDir);
        TpaManager.init(configDir);
        CombatManager.init(configDir);
        TrapBuilder.init(configDir);

        menuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.autotpa.menu", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, class_304.class_11900.field_62556));

        // 1. Перехват сообщений обычного чата игроков
        ClientReceiveMessageEvents.CHAT.register((msg, signed, sender, params, time) -> {
            String text = msg.getString();
            TpaManager.onChatMessage(text);
            CombatManager.onGameMessage(text);
        });

        // 2. Перехват системных сообщений сервера (ошибки /home 1, обслуживание, очереди)
        ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
            String text = msg.getString();
            TpaManager.tickGameMessage(text, overlay);
            CombatManager.onGameMessage(text);
        });

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (menuKey.method_1436()) {
                openMenu(c);
            }

            // 1. ВЫЗЫВАЕМ NatsuuManager ПЕРВЫМ (чтобы он работал во время экрана смерти и вылета!)
            NatsuuManager.tick(c);
             
            // 2. Авто-респавн при смерти (для основного бота)
            if (c.field_1755 instanceof class_418) {
                if (isMasterBotEnabled && !AutoSellManager.isDeathRecoveryState()) {
                    c.field_1724.method_7331();
                    AutoSellManager.startDeathRecovery(c);
                    CombatManager.resetSession(c);
                    TpaManager.resetSession();
                    TrapBuilder.reset();
                    CommandQueue.clear();
                }
                return;
            }

            // 3. АВТО-ПЕРЕХВАТ ЛЮБОГО КИКА С СЕРВЕРА (для основного бота)
            if (isMasterBotEnabled && (c.field_1755 instanceof class_419 || (c.field_1724 == null && c.field_1687 == null))) {
                if (currentBotState != BotState.DISCONNECTED_WAITING && currentBotState != BotState.RECONNECTED_SETUP) {
                    currentBotState = BotState.DISCONNECTED_WAITING;
                }
                CombatManager.handleAutoReconnect(c);
                return;
            }

            if (c.field_1724 == null || c.field_1687 == null) return;
            
            CommandQueue.tick(c);
            CombatManager.tick(c);
            AutoSellManager.tick(c);
             AhSniperManager.tick(c);
            TrapBuilder.tick(c);
            HomeSequence.tick(c);
            TpaManager.tick(c);
        });
    }

    public static void openMenu(class_310 client) {
        isMasterBotEnabled = false;
        currentBotState = BotState.IDLE_TRAPPING;
        AutoSellManager.currentState = AutoSellManager.SellState.IDLE;
        CombatManager.resetSession(client);
        TpaManager.resetSession();
        TrapBuilder.reset();
        HomeSequence.reset();
        CommandQueue.clear();
        
        client.method_1507(new BotMenuScreen(class_2561.method_43470("AutoTPA Control Panel")));
    }

    public static String cleanText(String text) {
        if (text == null) return "";
        String stripped = net.minecraft.class_124.method_539(text);
        if (stripped == null) stripped = text;
        return stripped.replaceAll("(?i)[§&][a-z0-9]", "").replaceAll("[\\u00A0\\s]+", " ").trim();
    }

    public static void sendFeedback(String message) {
        class_310 client = class_310.method_1551();
        if (client.field_1705 != null && client.field_1705.method_1743() != null) {
            client.field_1705.method_1743().method_1812(class_2561.method_43470("§6[AutoTPA] §f" + message));
        }
    }
}
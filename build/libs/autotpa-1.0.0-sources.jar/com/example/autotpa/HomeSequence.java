package com.example.autotpa;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class HomeSequence {
    private enum State {
        IDLE,
        OPEN_MAIN_MENU,
        CLICK_DOM_1,
        CLICK_DELETE_BUTTON,
        CLICK_CONFIRM_DELETE,
        REOPEN_FOR_NEW_HOME,
        CLICK_NEW_HOME_BUTTON,
        FINISH
    }

    private static State currentState = State.IDLE;
    private static int ticks = 0;

    public static void startSequence(class_310 client) {
        CommandQueue.send("home");
        currentState = State.CLICK_DOM_1;
        ticks = 20; // 1 сек на открытие /home
        Autotpa.sendFeedback("§e[HomeGUI] Открываю меню /home для сброса Дома 1...");
    }

    public static boolean isIdle() {
        return currentState == State.IDLE;
    }

    public static void tick(class_310 client) {
        if (currentState == State.IDLE || client.field_1724 == null) return;

        if (ticks > 0) {
            ticks--;
            return;
        }

        class_437 screen = client.field_1755;

        switch (currentState) {
            // ШАГ 1: В главном меню /home нажимаем "Дом 1" (Скриншот 3)
            // (Либо если Дома 1 не было, сразу жмем "Новый дом")
            case CLICK_DOM_1 -> {
                if (screen != null) {
                    if (clickButton(screen, "Новый дом", "новый дом", "new home")) {
                        // Дома 1 не было, сразу создался новый!
                        currentState = State.FINISH;
                        ticks = 15;
                    } else if (clickButton(screen, "Дом 1", "дом 1", "home 1")) {
                        currentState = State.CLICK_DELETE_BUTTON;
                        ticks = 15;
                    }
                } else {
                    CommandQueue.send("home");
                    ticks = 20;
                }
            }

            // ШАГ 2: В меню Дома 1 нажимаем красную кнопку "Удалить" (Скриншот 1)
            case CLICK_DELETE_BUTTON -> {
                if (screen != null) {
                    if (clickButton(screen, "Удалить", "удалить", "delete")) {
                        currentState = State.CLICK_CONFIRM_DELETE;
                        ticks = 15;
                    }
                }
            }

            // ШАГ 3: В окне подтверждения "Удалить Дом 1?" нажимаем "Удалить" (Скриншот 2)
            case CLICK_CONFIRM_DELETE -> {
                if (screen != null) {
                    if (clickButton(screen, "Удалить", "удалить", "delete")) {
                        currentState = State.REOPEN_FOR_NEW_HOME;
                        ticks = 20;
                    }
                }
            }

            // ШАГ 4: Снова открываем /home, где теперь появилась кнопка "Новый дом"
            case REOPEN_FOR_NEW_HOME -> {
                CommandQueue.send("home");
                currentState = State.CLICK_NEW_HOME_BUTTON;
                ticks = 20;
            }

            // ШАГ 5: Нажимаем кнопку "Новый дом" (Скриншот 4)
            case CLICK_NEW_HOME_BUTTON -> {
                if (screen != null) {
                    if (clickButton(screen, "Новый дом", "новый дом", "new home", "установить")) {
                        currentState = State.FINISH;
                        ticks = 15;
                    }
                } else {
                    CommandQueue.send("home");
                    ticks = 20;
                }
            }

            // ШАГ 6: Закрываем меню и завершаем
            case FINISH -> {
                if (client.field_1755 != null) {
                    client.method_1507(null);
                }
                currentState = State.IDLE;
                Autotpa.sendFeedback("§a[HomeGUI] Новый Дом 1 успешно сохранен через меню!");
            }
        }
    }

    // Поиск и нажатие нужной кнопки на экране
    private static boolean clickButton(class_437 screen, String... matchTexts) {
        List<class_339> widgets = new ArrayList<>();
        collectWidgets(screen, widgets, new HashSet<>());

        for (class_339 w : widgets) {
            if (w instanceof class_4185 btn) {
                String cleanBtnText = Autotpa.cleanText(btn.method_25369().getString()).toLowerCase();
                for (String match : matchTexts) {
                    String cleanMatch = match.toLowerCase();
                    if (cleanBtnText.equals(cleanMatch) || cleanBtnText.contains(cleanMatch)) {
                        btn.method_25306(null);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void collectWidgets(class_364 element, List<class_339> list, Set<class_364> visited) {
        if (element == null || visited.contains(element)) return;
        visited.add(element);

        if (element instanceof class_339 widget) {
            list.add(widget);
        }
        if (element instanceof class_4069 parent) {
            for (class_364 child : parent.method_25396()) {
                collectWidgets(child, list, visited);
            }
        }
    }

    public static void reset() {
        currentState = State.IDLE;
        ticks = 0;
    }
}
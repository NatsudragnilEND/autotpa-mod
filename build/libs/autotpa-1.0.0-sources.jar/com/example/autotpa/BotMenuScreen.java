package com.example.autotpa;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class BotMenuScreen extends class_437 {

    public BotMenuScreen(class_2561 title) {
        super(title);
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int startY = this.field_22790 / 4 - 25; // Слегка приподняли, чтобы все кнопки поместились
        int btnWidth = 220;
        int btnHeight = 20;
        int gap = 24;
        // 1. ВКЛЮЧЕНИЕ / ВЫКЛЮЧЕНИЕ ОСНОВНОГО БОТА
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(Autotpa.isMasterBotEnabled ? "§cTurn OFF Master Bot" : "§aTurn ON Master Bot"),
                btn -> {
                    Autotpa.isMasterBotEnabled = !Autotpa.isMasterBotEnabled;
                    if (Autotpa.isMasterBotEnabled && this.field_22787 != null) {
                        CombatManager.startBotSession(this.field_22787);
                    }
                    btn.method_25355(class_2561.method_43470(Autotpa.isMasterBotEnabled ? "§cTurn OFF Master Bot" : "§aTurn ON Master Bot"));
                }).method_46434(centerX - btnWidth / 2, startY, btnWidth, btnHeight).method_46431());

        // 2. РУЧНОЙ ЗАПУСК ТОРГОВЛИ И ЗАКУПКИ
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Start AutoSell / Buy"),
                btn -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(null);
                        Autotpa.isMasterBotEnabled = true;
                        AutoSellManager.startAutoSell(this.field_22787);
                    }
                }).method_46434(centerX - btnWidth / 2, startY + gap, btnWidth, btnHeight).method_46431());

        // 3. СОХРАНЕНИЕ ТЕКУЩЕЙ ЛОВУШКИ
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Save Current Trap Area"),
                btn -> {
                    if (this.field_22787 != null) {
                        CombatManager.saveTrap(this.field_22787);
                        this.field_22787.method_1507(null);
                    }
                }).method_46434(centerX - btnWidth / 2, startY + gap * 2, btnWidth, btnHeight).method_46431());
                
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(AhSniperManager.isSniperEnabled ? "§cStop AH Sniper" : "§aStart AH Sniper"),
                btn -> {
                    if (AhSniperManager.isSniperEnabled) {
                        AhSniperManager.stopSniper();
                    } else {
                        if (this.field_22787 != null) this.field_22787.method_1507(null);
                        AhSniperManager.startSniper();
                    }
                    btn.method_25355(class_2561.method_43470(AhSniperManager.isSniperEnabled ? "§cStop AH Sniper" : "§aStart AH Sniper"));
                }).method_46434(centerX - btnWidth / 2, startY + gap * 7, btnWidth, btnHeight).method_46431());
        // 4. ТЕСТ ПОБЕГА (ХОРУС + ПЕРЛЫ + ТПА)
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Test Escape (Run & Pearl)"),
                btn -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(null);
                        Autotpa.isMasterBotEnabled = true;
                        CombatManager.setCombatExpiration(System.currentTimeMillis() + 10000L);
                        CombatManager.startEscape(this.field_22787);
                    }
                }).method_46434(centerX - btnWidth / 2, startY + gap * 3, btnWidth, btnHeight).method_46431());

        // 5. ТЕСТ ПОСТРОЙКИ ЛОВУШКИ ЧЕРЕЗ RTP
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("§d[TEST] Auto Trap Builder (/rtp)"),
                btn -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(null);
                        Autotpa.isMasterBotEnabled = true;
                        TrapBuilder.start(this.field_22787);
                    }
                }).method_46434(centerX - btnWidth / 2, startY + gap * 4, btnWidth, btnHeight).method_46431());

        // 6. ПЕРЕКЛЮЧАТЕЛЬ РЕЖИМА ДЛЯ АККАУНТА itzNatsuu
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(NatsuuManager.isNatsuuModeEnabled ? "§cTurn OFF itzNatsuu Mode" : "§aTurn ON itzNatsuu Mode"),
                btn -> {
                    NatsuuManager.toggleNatsuuMode();
                    btn.method_25355(class_2561.method_43470(NatsuuManager.isNatsuuModeEnabled ? "§cTurn OFF itzNatsuu Mode" : "§aTurn ON itzNatsuu Mode"));
                }).method_46434(centerX - btnWidth / 2, startY + gap * 5, btnWidth, btnHeight).method_46431());

        // 7. ДЕБАГ: СТАТУС БОЯ (PVP)
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("§6[DEBUG] Проверить статус боя (PVP)"),
                btn -> {
                    if (this.field_22787 != null) {
                        Autotpa.sendFeedback(CombatManager.getDebugCombatStatus(this.field_22787));
                    }
                }).method_46434(centerX - btnWidth / 2, startY + gap * 6, btnWidth, btnHeight).method_46431());
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
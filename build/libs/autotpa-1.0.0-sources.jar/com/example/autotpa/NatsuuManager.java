package com.example.autotpa;

import net.minecraft.class_2799;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_418;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class NatsuuManager {

    public static boolean isNatsuuModeEnabled = false;
    private static boolean autoDetected = false;

    private static int respawnCooldownTicks = 0;
    private static boolean pendingTpAuto = false;
    private static int tpAutoDelayTicks = 0;
    
    // Таймеры авто-реконнекта
    private static int reconnectTimerSeconds = 60;
    private static int reconnectTickCounter = 20;

    // --- ПЕРЕМЕННЫЕ ПРОВЕРКИ /TPAUTO РАЗ В 10 МИНУТ ---
    private static int tpAutoCheckIntervalTicks = 12000; // 10 минут (10 * 60 * 20 тиков)
    private static boolean isCheckingTpAuto = false;
    private static int checkTimeoutTicks = 0;
    private static int reEnableDelayTicks = 0;

    public static void tick(class_310 client) {
        if (client == null) return;

        // 1. АВТО-ОПРЕДЕЛЕНИЕ ПО НИКУ
        if (!autoDetected && client.field_1724 != null) {
            String nick = client.field_1724.method_5477().getString();
            if (nick.equalsIgnoreCase("itzNatsuu")) {
                isNatsuuModeEnabled = true;
                autoDetected = true;
                Autotpa.sendFeedback("§a[NatsuuManager] Аккаунт itzNatsuu распознан! Режим включен.");
            }
        }

        if (!isNatsuuModeEnabled) return;

        // 2. АВТО-РЕКОННЕКТ ПРИ ВЫЛЕТЕ (РАЗ В 60 СЕКУНД)
        if (client.field_1687 == null || client.field_1724 == null || client.field_1755 instanceof class_419) {
            handleReconnect(client);
            return;
        }

        // 3. АВТО-ВОЗРОЖДЕНИЕ ПРИ СМЕРТИ
        boolean isDead = client.field_1724.method_29504() 
                || client.field_1724.method_6032() <= 0.0f 
                || client.field_1755 instanceof class_418;

        if (isDead) {
            if (respawnCooldownTicks > 0) {
                respawnCooldownTicks--;
            } else {
                if (client.method_1562() != null) {
                    client.method_1562().method_52787(new class_2799(class_2799.class_2800.field_12774));
                }
                if (client.field_1724 != null) {
                    client.field_1724.method_7331();
                }
                if (client.field_1755 instanceof class_418) {
                    client.method_1507(null);
                }

                pendingTpAuto = true;
                tpAutoDelayTicks = 25; // 1.25 сек паузы после респавна
                respawnCooldownTicks = 30;
                Autotpa.sendFeedback("§c[NatsuuManager] Смерть зафиксирована! Мгновенное возрождение...");
            }
            return;
        } else {
            respawnCooldownTicks = 0;
        }

        // 4. ОТПРАВКА /tpauto ПОСЛЕ СМЕРТИ
        if (pendingTpAuto) {
            if (tpAutoDelayTicks > 0) {
                tpAutoDelayTicks--;
            } else {
                sendDirectCommand(client, "tpauto");
                Autotpa.sendFeedback("§a[NatsuuManager] Команда /tpauto отправлена после респавна!");
                pendingTpAuto = false;
                tpAutoCheckIntervalTicks = 12000; // Сбрасываем 10-минутный таймер
            }
        }

        // 5. ПРОВЕРКА /tpauto КАЖДЫЕ 10 МИНУТ
        if (tpAutoCheckIntervalTicks > 0) {
            tpAutoCheckIntervalTicks--;
        } else {
            // 10 минут прошло -> пишем /tpauto для проверки
            isCheckingTpAuto = true;
            checkTimeoutTicks = 60; // Ждем ответ сервера 3 секунды
            tpAutoCheckIntervalTicks = 12000; // Снова ставим 10 минут
            sendDirectCommand(client, "tpauto");
            Autotpa.sendFeedback("§e[NatsuuManager] 10 минут прошло. Проверяю статус /tpauto...");
        }

        // Таймаут ожидания ответа
        if (isCheckingTpAuto) {
            if (checkTimeoutTicks > 0) {
                checkTimeoutTicks--;
            } else {
                isCheckingTpAuto = false;
            }
        }

        // Включение обратно, если мы случайно выключили активный tpauto
        if (reEnableDelayTicks > 0) {
            reEnableDelayTicks--;
            if (reEnableDelayTicks == 0) {
                sendDirectCommand(client, "tpauto");
                Autotpa.sendFeedback("§a[NatsuuManager] tpauto успешно включён обратно!");
            }
        }
    }

    // --- ПАРСИНГ ОТВЕТА СЕРВЕРА НА /tpauto ---
    public static void onGameMessage(String rawText, boolean overlay) {
        if (!isNatsuuModeEnabled || !isCheckingTpAuto) return;

        String clean = Autotpa.cleanText(rawText).toLowerCase();

        // 1. ЕСЛИ СЕРВЕР ОТВЕТИЛ "ВЫКЛЮЧИЛИ" -> ЗНАЧИТ ОН БЫЛ ВКЛЮЧЕН, ВКЛЮЧАЕМ ОБРАТНО!
        if (clean.contains("вы выключили tpauto") || clean.contains("выключили tpauto") || clean.contains("disabled tpauto")) {
            isCheckingTpAuto = false;
            reEnableDelayTicks = 10; // Через 0.5 сек шлем /tpauto второй раз для включения
            Autotpa.sendFeedback("§e[NatsuuManager] tpauto был активен (выключился) -> включаю обратно...");
        }
        // 2. ЕСЛИ СЕРВЕР ОТВЕТИЛ "ВКЛЮЧИЛИ" -> ЗНАЧИТ ОН БЫЛ ВЫКЛЮЧЕН, ТЕПЕРЬ ОН ВКЛЮЧЕН!
        else if (clean.contains("вы включили tpauto") || clean.contains("у вас включён tpauto") || clean.contains("включили tpauto") || clean.contains("enabled tpauto")) {
            isCheckingTpAuto = false;
            Autotpa.sendFeedback("§a[NatsuuManager] tpauto был выключен -> теперь успешно ВКЛЮЧЁН!");
        }
    }

    public static void toggleNatsuuMode() {
        isNatsuuModeEnabled = !isNatsuuModeEnabled;
        if (isNatsuuModeEnabled) {
            Autotpa.sendFeedback("§a[NatsuuManager] Режим itzNatsuu: §2ВКЛЮЧЕН §a(Авто-респавн + проверка /tpauto раз в 10м)");
        } else {
            Autotpa.sendFeedback("§c[NatsuuManager] Режим itzNatsuu: §4ВЫКЛЮЧЕН");
        }
    }

    private static void sendDirectCommand(class_310 client, String command) {
        String cleanCmd = command.startsWith("/") ? command.substring(1) : command;
        if (client.method_1562() != null) {
            client.method_1562().method_45730(cleanCmd);
        } else {
            CommandQueue.send(cleanCmd);
        }
    }

    private static void handleReconnect(class_310 client) {
        if (reconnectTickCounter > 0) {
            reconnectTickCounter--;
        } else {
            reconnectTickCounter = 20;
            reconnectTimerSeconds--;

            if (reconnectTimerSeconds % 15 == 0 || reconnectTimerSeconds <= 5) {
                Autotpa.sendFeedback("§e[Natsuu Reconnect] Переподключение через " + reconnectTimerSeconds + "с...");
            }

            if (reconnectTimerSeconds <= 0) {
                reconnectTimerSeconds = 60;
                Autotpa.sendFeedback("§a[Natsuu Reconnect] 1 минута прошла! Подключаюсь к donutsmp.net...");
                class_642 info = new class_642("DonutSMP", "donutsmp.net", class_642.class_8678.field_45611);
                class_412.method_36877(new class_442(), client, class_639.method_2950("donutsmp.net"), info, false, null);
            }
        }
    }
}
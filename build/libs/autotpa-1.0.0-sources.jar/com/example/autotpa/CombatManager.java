package com.example.autotpa;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1559;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_742;
import net.minecraft.class_9334;

public class CombatManager {

    public static boolean isRepairingTrap = false;
    public static boolean isVerifyingHome1 = false;
    private static int home1VerifyTimer = 0;
    private static int home1RetryCount = 0;
    private static int home1RetryCooldown = 0;
    private static double home1StartX = 0, home1StartY = 0, home1StartZ = 0;

    private static int lootRushTicks = 0;
    private static int postKillLootTimer = 0;
    private static boolean needsAutoSellAfterKill = false;

    private static class_742 currentEnemy = null;
    private static class_742 lastCombatEnemy = null;
    private static int swordCombatTimerTicks = 0;

    // --- ПЕРЕМЕННЫЕ АИМА И ЛУКА ---
    private static double aimDriftX = 0;
    private static double aimDriftY = 0;
    private static double aimDriftZ = 0;
    private static int aimDriftTimer = 0;
    private static int bowChargeTicks = 0;
    private static int bowShotsFired = 0;
    private static boolean isFinishingWithBow = false;
    private static float lastEnemyAbsorption = 0f;
    private static int arrowShotCheckTimer = 0;
    private static int lastArrowCountBeforeShot = -1;
    private static int consecutiveBowFailures = 0;

    // --- КУЛДАУНЫ И СОСТОЯНИЯ ---
    private static int combatRepairCooldown = 0;
    private static int combatRepairLockTicks = 0;
    private static int mendingCooldown = 0;
    private static int combatMendingCooldown = 0;
    private static int potionBuffCooldown = 0;
    private static int gappleUseTimer = 0;
    private static int gappleCooldown = 0;
    private static boolean isEatingGapple = false;
    private static boolean isDrinkingPotion = false;
    private static int potionDrinkTimer = 0;
    private static int activePotionHotbarSlot = 0;
    private static int potionOriginalInventorySlot = -1;
    public static boolean isMending = false;
    public static boolean isMendingToFull = false;

    // --- ЭНДЕРМИТЫ ---
    private static boolean wasCleaningEndermite = false;
    private static class_2338 endermiteCobwebPos = null;

    // --- ПОБЕГ ---
    private static class_243 chorusStartPos = null;
    private static class_243 preHome3Pos = null;
    private static int escapeTpaSendTimer = 0;
    private static class_243 escapeTpaCheckPos = null;
    private static int chorusInitialCount = 0;
    private static int initialPearlsThrown = 0;
    private static int escapePearlTimer = 0;
    private static int stateTimerTicks = 0;
    private static int reconnectSecondsLeft = 0;

    // --- СТРУКТУРА ЛОВУШКИ: 1 ПАУТИНА В НОГАХ + СТЕНЫ ИЗ ЭНДЕР-СУНДУКОВ (БЕЗ КРЫШИ) ---
    private static final Set<class_2338> savedWalls = new HashSet<>();
    private static final Set<class_2338> savedCobweb = new HashSet<>();
    private static File trapFile;
    private static final Random random = new Random();

    // --- ОВЕРЛЕЙ БОЯ ---
    private static final Pattern COMBAT_PATTERN = Pattern.compile("(?iu)(?:бой|combat|pvp|в\\s*бою)[^0-9]*(\\d+)");
    private static String lastParsedString = "";
    private static String lastActionbarText = "Нет данных";
    private static long combatExpiration = 0;
    private static long lastCombatOverlayTime = 0;
    private static int serverCombatSeconds = 0;
    private static java.lang.reflect.Field overlayMessageField = null;
    private static java.lang.reflect.Field overlayRemainingField = null;

    public static void init(File configDir) {
        trapFile = new File(configDir, "trap_structure.txt");
        loadTrap();
    }

    public static class_2338 getTrapFeetPos(class_310 client) {
        if (!savedCobweb.isEmpty()) {
            return savedCobweb.iterator().next();
        }
        return client.field_1724 != null ? client.field_1724.method_24515() : null;
    }

    public static class_2338 getTrapHeadPos(class_310 client) {
        class_2338 feet = getTrapFeetPos(client);
        return feet != null ? feet.method_10084() : (client.field_1724 != null ? client.field_1724.method_24515().method_10084() : null);
    }

    public static boolean isAtTrap(class_310 client) {
        if (client.field_1724 == null) return false;
        class_2338 feet = getTrapFeetPos(client);
        if (feet == null) return false;
        return client.field_1724.method_5707(class_243.method_24953(feet)) <= 4.0;
    }

    public static boolean isTrapReady(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;
        class_2338 feet = getTrapFeetPos(client);
        class_2338 head = getTrapHeadPos(client);
        if (feet == null || head == null) return false;

        // 1. В ногах строго паутина
        if (!client.field_1687.method_8320(feet).method_27852(class_2246.field_10343)) return false;

        // 2. На голове НЕТ крыши (чистый воздух)
        if (!client.field_1687.method_8320(head).method_26215()) return false;

        return isAtTrap(client);
    }

    // Совместимость для TpaManager
    public static boolean isTrapReadyWithCobwebs(class_310 client) {
        return isTrapReady(client);
    }

    public static boolean isPostKillProcessing() {
        return postKillLootTimer > 0 || needsAutoSellAfterKill;
    }

    public static void startBotSession(class_310 client) {
        if (client == null || client.field_1724 == null) return;
        equipArmorFromInventory(client);
        Autotpa.sendFeedback("§a[MasterBot] Экипировка проверена. Телепортация в /home 1...");
        Autotpa.currentBotState = Autotpa.BotState.STARTING_SETUP_HOME1;
        sendHome1WithVerification(client);
    }

    public static void checkInGameHudOverlay(class_310 client) {
        if (client == null || client.field_1705 == null) return;
        try {
            if (overlayMessageField == null || overlayRemainingField == null) {
                for (java.lang.reflect.Field f : client.field_1705.getClass().getDeclaredFields()) {
                    if (f.getName().equals("overlayMessage") || f.getName().equals("field_2018")) {
                        f.setAccessible(true);
                        overlayMessageField = f;
                    }
                    if (f.getName().equals("overlayRemaining") || f.getName().equals("field_2019")) {
                        f.setAccessible(true);
                        overlayRemainingField = f;
                    }
                }
            }

            if (overlayRemainingField != null && overlayMessageField != null) {
                int remainingTicks = overlayRemainingField.getInt(client.field_1705);
                if (remainingTicks <= 0) {
                    serverCombatSeconds = 0;
                    combatExpiration = 0;
                    lastActionbarText = "Нет";
                    return;
                }

                class_2561 t = (class_2561) overlayMessageField.get(client.field_1705);
                if (t != null) {
                    String str = t.getString();
                    if (str != null && !str.trim().isEmpty()) {
                        parseCombatOverlay(str, true);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    public static void parseCombatOverlay(String text, boolean overlay) {
        if (text == null || text.trim().isEmpty()) return;
        String clean = text.replaceAll("(?i)[§&][0-9a-z]", "").trim();
        String lower = clean.toLowerCase();

        if (lower.contains("restart queue") || lower.contains("очередь перезапуска")) {
            Autotpa.sendFeedback("§c[AutoTPA] Сервер уходит на перезапуск! Безопасный выход...");
            class_310.method_1551().method_73360(class_2561.method_43470("Restart Queue"));
            Autotpa.currentBotState = Autotpa.BotState.DISCONNECTED_WAITING;
            reconnectSecondsLeft = 60;
            return;
        }

        if (overlay || lower.contains("бой") || lower.contains("combat") || lower.contains("pvp")) {
            Matcher m = COMBAT_PATTERN.matcher(lower);
            if (m.find()) {
                try {
                    int sec = Integer.parseInt(m.group(1));
                    if (sec > 0 && sec <= 60) {
                        if (!clean.equals(lastParsedString)) {
                            lastActionbarText = clean;
                            lastCombatOverlayTime = System.currentTimeMillis();
                            serverCombatSeconds = sec;
                            lastParsedString = clean;
                            long duration = (sec == 1) ? 1500L : (sec * 1000L + 1200L);
                            combatExpiration = System.currentTimeMillis() + duration;
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
    }

    public static boolean isServerCombatActive() {
        if (serverCombatSeconds <= 0) return false;
        if (lastCombatOverlayTime == 0 || (System.currentTimeMillis() - lastCombatOverlayTime > 2000L)) {
            serverCombatSeconds = 0;
            combatExpiration = 0;
            lastParsedString = "";
            return false;
        }
        return true;
    }

    public static boolean isCombatActive(class_310 client) {
        if (currentEnemy != null && currentEnemy.method_5805() && client.field_1724 != null && client.field_1724.method_5739(currentEnemy) < 10.0) {
            return true;
        }
        return isServerCombatActive();
    }

    public static void setCombatExpiration(long timestamp) {
        combatExpiration = timestamp;
        serverCombatSeconds = (int) Math.max(1, (timestamp - System.currentTimeMillis()) / 1000L);
        lastCombatOverlayTime = System.currentTimeMillis();
    }

    public static String getDebugCombatStatus(class_310 client) {
        checkInGameHudOverlay(client);

        long remainingMs = Math.max(0, combatExpiration - System.currentTimeMillis());
        double remainingSec = remainingMs / 1000.0;
        long timeSinceLastPacket = System.currentTimeMillis() - lastCombatOverlayTime;
        boolean inCombat = isCombatActive(client);

        String enemyInfo = (currentEnemy != null && currentEnemy.method_5805())
                ? currentEnemy.method_5477().getString() + " (" + String.format("%.1f", client.field_1724.method_5739(currentEnemy)) + "m)"
                : "Нет";

        return "§6[DEBUG-PVP] §fВ бою: " + (inCombat ? "§cДА" : "§aНЕТ") +
               " §f| Оверлей: §e" + String.format("%.1f", remainingSec) + "с (Сервер: " + (inCombat ? serverCombatSeconds : 0) + "с)" +
               " §f| Пакет: §b" + (lastCombatOverlayTime == 0 ? "Никогда" : timeSinceLastPacket + "мс назад") +
               " §f| Экшенбар: '§e" + lastActionbarText + "§f'" +
               " §f| Враг: §b" + enemyInfo;
    }
    // =========================================================================
    // БЕЗОПАСНЫЙ СНОС ВРЕМЕННОЙ ПАУТИНЫ (СВЕРХУ ВНИЗ) ПОСЛЕ СУШКИ ЛАВЫ/ВОДЫ
    // Паутину в ногах НЕ ТРОГАЕМ НИКОГДА!
    // =========================================================================
    public static boolean handleCleanupTemporaryCobwebs(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;
        class_2338 feetPos = getTrapFeetPos(client);
        if (feetPos == null) return false;

        // Проверяем блоки над ногами: от Y+3 вниз до уровня головы Y+1
        for (int y = 3; y >= 1; y--) {
            class_2338 checkPos = feetPos.method_10086(y);
            class_2680 state = client.field_1687.method_8320(checkPos);

            if (state.method_27852(class_2246.field_10343)) {
                class_2338 above = checkPos.method_10084();
                
                // ЗАЩИТА: если прямо над этой паутиной всё еще осталась вода или лава —
                // пока НЕ ломаем, чтобы жидкость не хлынула обратно в лицо!
                if (hasFluid(client, above) || hasFluid(client, checkPos)) {
                    continue; 
                }

                // Жидкость высушена! Безопасно срубаем временную паутину мечом
                ensureSwordInHand(client);
                if (BlockInteractionHelper.breakBlockLegit(client, checkPos)) {
                    return true; // Ломаем блок до конца, соблюдая все ванильные задержки
                }
            }
        }
        return false;
    }
    // =========================================================================
    // ГЛАВНЫЙ ТИК БОЕВОГО МЕНЕДЖЕРА
    // =========================================================================
    public static void tick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        // 1. ЭКСТРЕННАЯ СУШКА ЛАВЫ И ВОДЫ СВЕРХУ ПАУТИНОЙ (снизу вверх)
        if (handleTrapFluidDefense(client)) {
            return;
        }

        // 2. БЕЗОПАСНЫЙ СНОС ПАУТИНЫ МЕЧОМ (сверху вниз, только когда жидкость исчезла)
        if (handleCleanupTemporaryCobwebs(client)) {
            return;
        }

        checkInGameHudOverlay(client);
        if (!Autotpa.isMasterBotEnabled) return;

        checkHome1Verification(client);

        if (Autotpa.currentBotState == Autotpa.BotState.ESCAPE_EATING_CHORUS
                || Autotpa.currentBotState == Autotpa.BotState.ESCAPE_RUNNING) {
            if (!checkCancelEscapeIfEnemyInTrap(client)) {
                if (Autotpa.currentBotState == Autotpa.BotState.ESCAPE_EATING_CHORUS) {
                    handleChorusEating(client);
                    return;
                }
                if (Autotpa.currentBotState == Autotpa.BotState.ESCAPE_RUNNING) {
                    handleEscapeRunning(client);
                    return;
                }
            }
        }

        switch (Autotpa.currentBotState) {
            case STARTING_SETUP_HOME1 -> { return; }
            case ESCAPE_HOME3_WAIT -> { handleHome3AndLeave(client); return; }
            case RECONNECTED_SETUP -> { handleReconnectedSetup(client); return; }
            case TRAP_BUILDING -> { return; }
        }

        ensureTotem(client);

        // Поиск источника воды/лавы в ловушке
        class_2338 fluidSource = findFluidSourceInTrap(client);
        if (fluidSource != null) {
            BlockInteractionHelper.stopBreaking(client);
            if (BlockInteractionHelper.placeBlockLegit(client, fluidSource, class_1802.field_8786)) {
                Autotpa.sendFeedback("§b[Trap] Вода/лава высушена паутиной!");
                return;
            }
        }

        // БЕЗ КРЫШИ: Если кто-то поставил блок на уровне головы — сносим!
        class_2338 headPos = getTrapHeadPos(client);
        if (headPos != null) {
            class_2680 headState = client.field_1687.method_8320(headPos);
            if (!headState.method_26215() && headState.method_26227().method_15769() && !headState.method_27852(class_2246.field_9987)) {
                if (BlockInteractionHelper.breakBlockLegit(client, headPos)) {
                    return;
                }
            }
        }

        class_742 foundEnemy = findTarget(client);
        currentEnemy = foundEnemy;

        if (currentEnemy != null) {
            if (AutoSellManager.currentState != AutoSellManager.SellState.IDLE || client.field_1755 != null) {
                Autotpa.sendFeedback("§4§l[ТРЕВОГА] ВРАГ В ЛОВУШКЕ! ОТМЕНА ПРОДАЖИ, В БОЙ!");
                AutoSellManager.abortAutoSell(client);
                ensureSwordInHand(client);
            }
        }

        // Экстренный побег, если мы голые
        if (currentEnemy != null && !AutoSellManager.isCombatReady(client)) {
            Autotpa.sendFeedback("§4§l[ВНИМАНИЕ] ВРАГ РЯДОМ, А МЫ БЕЗ ОРУЖИЯ! ПОБЕГ!");
            startEscape(client);
            return;
        }

        // Зелья и яблоки
        if (handleDrinkingPotionProcess(client)) return;
        if (handleGappleEatingProcess(client)) {
            if (currentEnemy != null && currentEnemy.method_5805()) {
                aimAt(client, getDynamicBodyAimPos(currentEnemy));
                client.field_1690.field_1894.method_23481(true);
            }
            return;
        }

        if (!client.field_1724.method_6059(class_1294.field_5910)) {
            if (applyStrengthPotion(client)) return;
        }

        if (!isDrinkingPotion) {
            checkAndEatGoldenApple(client);
            if (isEatingGapple) return;
        }

        // =========================================================================
        // 1. БОЙ С ПРОТИВНИКОМ В 1x1
        // =========================================================================
        if (currentEnemy != null) {
            isRepairingTrap = false;
            BlockInteractionHelper.stopBreaking(client);

            // Починка стен и 1 паутины в ногах прямо во время боя
            if (handleCombatTrapRepair(client)) return;

            // Проверка смены противника
            if (currentEnemy != lastCombatEnemy) {
                lastCombatEnemy = currentEnemy;
                swordCombatTimerTicks = 0;
                bowShotsFired = 0;
                isFinishingWithBow = false;
                lastEnemyAbsorption = currentEnemy.method_6067();
            }

            // --- ТРИГГЕРЫ ПЕРЕКЛЮЧЕНИЯ НА ЛУК ---
            float currentAbsorption = currentEnemy.method_6067();
            boolean poppedTotem = currentAbsorption > (lastEnemyAbsorption + 2.0f);
            boolean hasResistance = currentEnemy.method_6059(class_1294.field_5907);
            boolean enemyHoldingBow = isHoldingBow(currentEnemy);

            // Если лопнул тотем, съел гэппл, взял лук или бой мечом длится >30 сек -> ЛУК!
            if (poppedTotem || hasResistance || enemyHoldingBow || swordCombatTimerTicks >= 600) {
                if (!isFinishingWithBow) {
                    isFinishingWithBow = true;
                    bowShotsFired = 0;
                    consecutiveBowFailures = 0;
                    if (poppedTotem) Autotpa.sendFeedback("§6[TrapBot] Враг лопнул тотем! Переключаюсь на лук!");
                    else if (hasResistance) Autotpa.sendFeedback("§e[TrapBot] Эффект Сопротивления у врага! Добиваю луком!");
                    else if (enemyHoldingBow) Autotpa.sendFeedback("§c[TrapBot] Враг достал лук! Достаю лук в ответ!");
                    else Autotpa.sendFeedback("§e[TrapBot] Долгий бой мечом! Перехожу на лук!");
                }
            }
            lastEnemyAbsorption = currentAbsorption;

            // Проверка щита врага
            boolean isEnemyShielding = currentEnemy.method_6039() || (currentEnemy.method_6115() &&
                    (currentEnemy.method_6047().method_31574(class_1802.field_8255) || currentEnemy.method_6079().method_31574(class_1802.field_8255)));

            // Если враг поднял щит -> СБИВАЕМ ТОПОРОМ!
            if (isEnemyShielding) {
                client.field_1690.field_1904.method_23481(false);
                bowChargeTicks = 0;
                ensureAxeInHand(client);
                aimAt(client, getDynamicBodyAimPos(currentEnemy));
                client.field_1690.field_1894.method_23481(true);

                if (client.field_1724.method_7261(0.0f) >= 0.90f) {
                    client.field_1761.method_2918(client.field_1724, currentEnemy);
                    client.field_1724.method_6104(class_1268.field_5808);
                    Autotpa.sendFeedback("§6[TrapBot] Щит врага сбит топором!");
                }
                return;
            }

            // --- РЕЖИМ ЛУКА ---
            if (isFinishingWithBow) {
                int arrowCount = countItem(client, class_1802.field_8107) + countItem(client, class_1802.field_8087) + countItem(client, class_1802.field_8236);
                int bowCount = countItem(client, class_1802.field_8102);

                if (arrowCount <= 0 || bowCount <= 0) {
                    isFinishingWithBow = false;
                    Autotpa.sendFeedback("§c[TrapBot] Стрелы/луки закончились! Возвращаюсь к мечу!");
                    ensureSwordInHand(client);
                } else {
                    if (!AutoSellManager.isBowItem(client.field_1724.method_31548().method_5438(6))) {
                        AutoSellManager.ensureBowInSlot6(client);
                    }

                    selectHotbarSlot(client, 6);
                    bowChargeTicks++;

                    updateBowSpacing(client, currentEnemy);
                    class_243 ballisticAim = calculateBowAimPoint(client, currentEnemy, Math.max(bowChargeTicks, 4));
                    aimAt(client, ballisticAim);

                    if (bowChargeTicks == 1 || !client.field_1724.method_6115()) {
                        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                    }
                    client.field_1690.field_1904.method_23481(true);

                    int requiredTicks = (bowShotsFired < 2) ? 7 : 4;
                    if (consecutiveBowFailures >= 1) requiredTicks = 8;

                    if (bowChargeTicks >= requiredTicks) {
                        client.field_1690.field_1904.method_23481(false);
                        bowChargeTicks = 0;
                        bowShotsFired++;
                        lastArrowCountBeforeShot = arrowCount;
                        arrowShotCheckTimer = 8;
                    }
                    return;
                }
            }

            // --- РЕЖИМ МЕЧА ---
            ensureSwordInHand(client);
            client.field_1690.field_1904.method_23481(false);
            bowChargeTicks = 0;

            aimAt(client, getDynamicBodyAimPos(currentEnemy));
            client.field_1690.field_1894.method_23481(true);

            swordCombatTimerTicks++;

            float progress = client.field_1724.method_7261(0.0f);
            boolean readyToAttack = (progress >= 1.0f);

            if (readyToAttack && client.field_1724.method_5739(currentEnemy) <= 3.5) {
                client.field_1761.method_2918(client.field_1724, currentEnemy);
                client.field_1724.method_6104(class_1268.field_5808);
            }
            return;
        }

        // =========================================================================
        // 2. ВРАГ УНИЧТОЖЕН (СМЕРТЬ ВРАГА)
        // =========================================================================
        if (currentEnemy == null && lastCombatEnemy != null) {
            Autotpa.sendFeedback("§a[TrapBot] Враг уничтожен!");
            lastCombatEnemy = null;
            isFinishingWithBow = false;
            swordCombatTimerTicks = 0;
            bowChargeTicks = 0;
            bowShotsFired = 0;
            serverCombatSeconds = 0;
            combatExpiration = 0;
            releaseControls(client);
            ensureSwordInHand(client);

            if (hasGroundLootInTrap(client)) {
                postKillLootTimer = 40;
                needsAutoSellAfterKill = true;
            } else {
                postKillLootTimer = 0;
                needsAutoSellAfterKill = false;
                Autotpa.sendFeedback("§a[TrapBot] Лута нет, сразу готов к следующему игроку!");
            }
        }

        // =========================================================================
        // 3. ПОДБОР ЛУТА ПОСЛЕ КИЛЛА
        // =========================================================================
        if (postKillLootTimer > 0) {
            postKillLootTimer--;
            handleGroundLootRush(client);

            if (!hasGroundLootInTrap(client) || postKillLootTimer == 0) {
                postKillLootTimer = 0;
                boolean shouldSell = needsAutoSellAfterKill && AutoSellManager.hasSellableItems(client);
                needsAutoSellAfterKill = false;

                if (shouldSell && AutoSellManager.currentState == AutoSellManager.SellState.IDLE) {
                    Autotpa.sendFeedback("§6[TrapBot] Весь лут собран! Продажа (/sell)...");
                    AutoSellManager.forceStartAutoSell(client);
                    return;
                }
            }
            return;
        }

        // =========================================================================
        // 4. РЕЖИМ ОЖИДАНИЯ В 1x1 (ВНЕ БОЯ)
        // =========================================================================
        if (currentEnemy == null) {
            if (handleEndermiteProtocol(client)) return;

            if (handleTrapRepair(client)) {
                isRepairingTrap = true;
                return;
            }
            isRepairingTrap = false;

            if (handleMending(client)) return;

            if (getEmptySlotCount(client) > 1 && handleGroundLootRush(client)) {
                return;
            }
        }
    }

    private static boolean isHoldingBow(class_742 player) {
        if (player == null) return false;
        class_1792 main = player.method_6047().method_7909();
        class_1792 off = player.method_6079().method_7909();
        return main == class_1802.field_8102 || main == class_1802.field_8399 || off == class_1802.field_8102 || off == class_1802.field_8399;
    }

    // --- ПОЧИНКА ЛОВУШКИ ВНЕ БОЯ (1 ПАУТИНА В НОГАХ + ЭНДЕР-СУНДУКИ) ---
    public static boolean handleTrapRepair(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;

        // 1. Паутина в ногах (строго одна)
        class_2338 feetPos = getTrapFeetPos(client);
        if (feetPos != null) {
            class_2680 feetState = client.field_1687.method_8320(feetPos);
            if (!feetState.method_27852(class_2246.field_10343) && !feetState.method_27852(class_2246.field_9987)) {
                if (isFluidOrReplaceable(feetState)) {
                    BlockInteractionHelper.stopBreaking(client);
                    if (BlockInteractionHelper.placeBlockLegit(client, feetPos, class_1802.field_8786)) return true;
                } else {
                    if (BlockInteractionHelper.breakBlockLegit(client, feetPos)) return true;
                }
            }
        }

        // 2. Стены из эндер-сундуков
        for (class_2338 pos : savedWalls) {
            if (client.field_1724.method_5707(class_243.method_24953(pos)) > 25.0) continue;

            class_2680 state = client.field_1687.method_8320(pos);
            if (state.method_27852(class_2246.field_10443) || state.method_27852(class_2246.field_9987)) continue;

            if (isFluidOrReplaceable(state)) {
                BlockInteractionHelper.stopBreaking(client);
                if (BlockInteractionHelper.placeBlockLegit(client, pos, class_1802.field_8466)) {
                    return true;
                }
            } else {
                BlockInteractionHelper.breakBlockLegit(client, pos);
                return true;
            }
        }

        BlockInteractionHelper.stopBreaking(client);
        return false;
    }

    // --- ПОЧИНКА В БОЮ ---
    private static boolean handleCombatTrapRepair(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;

        if (combatRepairLockTicks > 0) {
            combatRepairLockTicks--;
            return true;
        }

        // 1. Паутина в ногах
        class_2338 feetPos = getTrapFeetPos(client);
        if (feetPos != null) {
            class_2680 state = client.field_1687.method_8320(feetPos);
            if (!state.method_27852(class_2246.field_10343) && isFluidOrReplaceable(state)) {
                if (BlockInteractionHelper.placeBlockLegit(client, feetPos, class_1802.field_8786)) {
                    combatRepairLockTicks = 3;
                    combatRepairCooldown = 5;
                    return true;
                }
            }
        }

        // 2. Стены из эндер-сундуков
        for (class_2338 pos : savedWalls) {
            if (client.field_1724.method_5707(class_243.method_24953(pos)) > 25.0) continue;
            class_2680 state = client.field_1687.method_8320(pos);
            if (state.method_27852(class_2246.field_10443) || state.method_27852(class_2246.field_9987)) continue;

            if (isFluidOrReplaceable(state)) {
                if (BlockInteractionHelper.placeBlockLegit(client, pos, class_1802.field_8466)) {
                    combatRepairCooldown = 5;
                    return true;
                }
            }
        }

        return false;
    }

    private static void updateBowSpacing(class_310 client, class_742 enemy) {
        if (client.field_1724 == null || enemy == null || client.field_1690 == null) return;
        class_2338 feetPos = getTrapFeetPos(client);
        if (feetPos == null) return;

        double targetX = (enemy.method_23317() > feetPos.method_10263() + 0.5) ? (feetPos.method_10263() + 0.22) : (feetPos.method_10263() + 0.78);
        double targetZ = (enemy.method_23321() > feetPos.method_10260() + 0.5) ? (feetPos.method_10260() + 0.22) : (feetPos.method_10260() + 0.78);

        double dx = targetX - client.field_1724.method_23317();
        double dz = targetZ - client.field_1724.method_23321();
        double distToCorner = Math.sqrt(dx * dx + dz * dz);

        if (distToCorner < 0.05) {
            releaseMovementKeys(client);
            return;
        }

        float moveYaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float delta = (float) class_3532.method_15393(moveYaw - client.field_1724.method_36454());

        client.field_1690.field_1894.method_23481(delta > -67.5f && delta < 67.5f);
        client.field_1690.field_1881.method_23481(delta > 112.5f || delta < -112.5f);
        client.field_1690.field_1913.method_23481(delta < -22.5f && delta > -157.5f);
        client.field_1690.field_1849.method_23481(delta > 22.5f && delta < 157.5f);
    }

    private static void releaseMovementKeys(class_310 client) {
        if (client.field_1690 != null) {
            client.field_1690.field_1894.method_23481(false);
            client.field_1690.field_1881.method_23481(false);
            client.field_1690.field_1913.method_23481(false);
            client.field_1690.field_1849.method_23481(false);
        }
    }

    public static void sendHome1WithVerification(class_310 client) {
        if (client.field_1724 == null) return;

        if (isAtTrap(client)) {
            isVerifyingHome1 = false;
            home1VerifyTimer = 0;
            Autotpa.sendFeedback("§a[AutoTPA] Бот уже в ловушке. Готов к ловле!");
            Autotpa.currentBotState = Autotpa.BotState.IDLE_TRAPPING;
            return;
        }

        home1StartX = client.field_1724.method_23317();
        home1StartY = client.field_1724.method_23318();
        home1StartZ = client.field_1724.method_23321();
        isVerifyingHome1 = true;
        home1VerifyTimer = 40;
        home1RetryCount = 0;
        CommandQueue.send("home 1");
    }

    private static void checkHome1Verification(class_310 client) {
        if (!isVerifyingHome1 || client.field_1724 == null) return;

        if (isAtTrap(client)) {
            isVerifyingHome1 = false;
            home1VerifyTimer = 0;
            home1RetryCount = 0;
            Autotpa.sendFeedback("§a[AutoTPA] Успешно прибыл в ловушку!");
            Autotpa.currentBotState = Autotpa.BotState.IDLE_TRAPPING;
            return;
        }

        if (home1VerifyTimer > 0) {
            home1VerifyTimer--;
        } else {
            home1RetryCount++;
            if (home1RetryCount >= 1 || isAtTrap(client)) {
                isVerifyingHome1 = false;
                home1VerifyTimer = 0;
                home1RetryCount = 0;
                Autotpa.currentBotState = Autotpa.BotState.IDLE_TRAPPING;
                Autotpa.sendFeedback("§a[AutoTPA] Ловушка готова. Ловля начата!");
                return;
            }
            sendHome1WithVerification(client);
        }
    }

    public static void onGameMessage(String text) {
        String lower = text.toLowerCase();
        if (lower.contains("обслуживании") || lower.contains("maintenance") || lower.contains("недоступна")) {
            if (isVerifyingHome1) {
                Autotpa.sendFeedback("§c[AutoTPA] Область на обслуживании. Жду 2 минуты...");
                home1RetryCooldown = 2400;
                home1VerifyTimer = 0;
            }
        }
    }

    private static boolean isFluidOrReplaceable(class_2680 state) {
        if (state == null) return false;
        return state.method_26215() || state.method_27852(class_2246.field_10382) || state.method_27852(class_2246.field_10164) 
                || !state.method_26227().method_15769() || state.method_45474();
    }

    public static void handleAutoReconnect(class_310 client) {
        Autotpa.isMasterBotEnabled = true;

        if (client.field_1687 != null && client.field_1724 != null) {
            Autotpa.currentBotState = Autotpa.BotState.RECONNECTED_SETUP;
            stateTimerTicks = 40;
            return;
        }

        if (client.field_1755 instanceof class_419 discScreen) {
            for (class_364 element : discScreen.method_25396()) {
                if (element instanceof class_4185 btn) {
                    btn.method_25306(null);
                    break;
                }
            }
        }

        if (reconnectSecondsLeft <= 0) {
            reconnectSecondsLeft = 60;
            stateTimerTicks = 20;
        }

        if (stateTimerTicks > 0) {
            stateTimerTicks--;
        } else {
            stateTimerTicks = 20;
            reconnectSecondsLeft--;

            if (reconnectSecondsLeft % 15 == 0 || reconnectSecondsLeft <= 5) {
                Autotpa.sendFeedback("§e[Reconnect] Переподключение к donutsmp.net через " + reconnectSecondsLeft + "с...");
            }

            if (reconnectSecondsLeft <= 0) {
                Autotpa.sendFeedback("§a[Reconnect] 1 минута прошла! Подключаюсь к donutsmp.net...");
                class_642 donutInfo = new class_642("DonutSMP", "donutsmp.net", class_642.class_8678.field_45611);
                class_412.method_36877(new class_442(), client, class_639.method_2950("donutsmp.net"), donutInfo, false, null);

                reconnectSecondsLeft = 60;
                stateTimerTicks = 200;
                Autotpa.currentBotState = Autotpa.BotState.RECONNECTED_SETUP;
            }
        }
    }

    private static boolean ensureAxeInHand(class_310 client) {
        if (client.field_1724 == null) return false;
        class_1799 slot2 = client.field_1724.method_31548().method_5438(2);
        String s2Name = slot2.method_7909().toString().toLowerCase();
        if ((s2Name.contains("_axe") || s2Name.endsWith("axe")) && !s2Name.contains("pickaxe")) {
            selectHotbarSlot(client, 2);
            return true;
        }

        for (int i = 0; i < 9; i++) {
            String name = client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase();
            if ((name.contains("_axe") || name.endsWith("axe")) && !name.contains("pickaxe")) {
                selectHotbarSlot(client, i);
                return true;
            }
        }

        for (int i = 9; i <= 35; i++) {
            String name = client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase();
            if ((name.contains("_axe") || name.endsWith("axe")) && !name.contains("pickaxe")) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, 2, class_1713.field_7791, client.field_1724);
                selectHotbarSlot(client, 2);
                return true;
            }
        }
        return false;
    }

    private static void handleReconnectedSetup(class_310 client) {
        if (client.field_1724 == null) return;
        if (stateTimerTicks > 0) {
            stateTimerTicks--;
            releaseControls(client);
        } else {
            releaseControls(client);
            resetSession(client);
            Autotpa.sendFeedback("§a[AutoTPA] Перезаход успешен! Возвращаюсь в /home 1...");
            sendHome1WithVerification(client);
            serverCombatSeconds = 0;
            combatExpiration = 0;
        }
    }

    public static boolean handleMending(class_310 client) {
        if (mendingCooldown > 0) mendingCooldown--;

        if (currentEnemy != null || AutoSellManager.currentState != AutoSellManager.SellState.IDLE) {
            if (isMending) {
                client.field_1690.field_1904.method_23481(false);
                isMending = false;
                isMendingToFull = false;
            }
            return false;
        }

        if (isArmorNeedsMending(client)) {
            isMendingToFull = true;
        }

        if (isMendingToFull) {
            if (!isArmorNotFullyRepaired(client)) {
                isMendingToFull = false;
                isMending = false;
                client.field_1690.field_1904.method_23481(false);
                ensureSwordInHand(client);
                Autotpa.sendFeedback("§a[Mending] Вся броня восстановлена до 100%!");
                return false;
            }

            isMending = true;
            int xpSlot = -1;

            for (int i = 0; i < 9; i++) {
                if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8287)) {
                    xpSlot = i;
                    break;
                }
            }

            if (xpSlot == -1) {
                for (int i = 9; i <= 35; i++) {
                    if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8287)) {
                        int syncId = client.field_1724.field_7498.field_7763;
                        client.field_1761.method_2906(syncId, i, 2, class_1713.field_7791, client.field_1724);
                        xpSlot = 2;
                        break;
                    }
                }
            }

            if (xpSlot != -1) {
                client.field_1724.method_31548().method_61496(xpSlot);
                client.field_1724.method_36457(89.0f);
                client.field_1690.field_1904.method_23481(true);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                client.field_1724.method_6104(class_1268.field_5808);
                return true;
            } else {
                client.field_1690.field_1904.method_23481(false);
                isMending = false;
                isMendingToFull = false;
                if (mendingCooldown <= 0) {
                    Autotpa.sendFeedback("§c[Mending] Нет опыта! Запускаю авто-закупку...");
                    AutoSellManager.startAutoSell(client);
                    mendingCooldown = 100;
                }
                return false;
            }
        }
        return false;
    }

    public static boolean isItemInsideTrap(class_310 client, class_1542 itemEntity) {
        if (client.field_1687 == null || client.field_1724 == null || itemEntity == null || !itemEntity.method_5805()) return false;
        double dist = client.field_1724.method_5739(itemEntity);
        if (dist > 2.5) return false;

        class_2338 feet = getTrapFeetPos(client);
        if (feet == null) return false;

        class_243 itemPos = new class_243(itemEntity.method_23317(), itemEntity.method_23318(), itemEntity.method_23321());
        double dx = itemPos.field_1352 - (feet.method_10263() + 0.5);
        double dz = itemPos.field_1350 - (feet.method_10260() + 0.5);
        double hDist = Math.sqrt(dx * dx + dz * dz);

        return hDist <= 1.2 && itemPos.field_1351 >= feet.method_10264() - 0.5 && itemPos.field_1351 <= feet.method_10264() + 2.5;
    }

    public static boolean hasGroundLootInTrap(class_310 client) {
        if (client == null || client.field_1687 == null || client.field_1724 == null) return false;
        for (class_1542 entity : client.field_1687.method_8390(class_1542.class, client.field_1724.method_5829().method_1014(3.0), e -> e.method_5805())) {
            if (isItemInsideTrap(client, entity)) {
                return true;
            }
        }
        return false;
    }

    private static boolean handleGroundLootRush(class_310 client) {
        if (currentEnemy != null || AutoSellManager.currentState != AutoSellManager.SellState.IDLE) {
            lootRushTicks = 0;
            return false;
        }
        if (client.field_1687 == null || client.field_1724 == null) return false;

        for (class_1542 entity : client.field_1687.method_8390(class_1542.class, client.field_1724.method_5829().method_1014(2.5), e -> e.method_5805())) {
            if (!isItemInsideTrap(client, entity)) continue;

            class_1792 item = entity.method_6983().method_7909();
            String name = item.toString().toLowerCase();

            boolean isValuable = name.contains("helmet") || name.contains("chestplate") 
                    || name.contains("leggings") || name.contains("boots") 
                    || name.contains("sword") || name.contains("axe") 
                    || name.contains("pickaxe") || item == class_1802.field_49814 || item == class_1802.field_8288;

            if (isValuable) {
                lootRushTicks++;
                client.field_1690.field_1894.method_23481(true);

                if (lootRushTicks > 30) {
                    client.field_1690.field_1894.method_23481(false);
                    lootRushTicks = 0;
                    return false;
                }
                return true;
            }
        }

        if (lootRushTicks > 0) {
            client.field_1690.field_1894.method_23481(false);
            lootRushTicks = 0;
        }
        return false;
    }

    public static void startEscape(class_310 client) {
        currentEnemy = null; lastCombatEnemy = null;
        swordCombatTimerTicks = 0; bowShotsFired = 0;

        Autotpa.currentBotState = Autotpa.BotState.ESCAPE_EATING_CHORUS;
        stateTimerTicks = 45;
        chorusStartPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
        preHome3Pos = null;
        initialPearlsThrown = 0;
        escapePearlTimer = 0;
        escapeTpaSendTimer = 0;
        escapeTpaCheckPos = null;

        releaseControls(client);

        int chorusSlot = ensureChorusInHotbar(client);
        chorusInitialCount = countItem(client, class_1802.field_8233);

        if (chorusSlot != -1) {
            client.field_1724.method_31548().method_61496(chorusSlot);
            client.field_1690.field_1904.method_23481(true);
        } else {
            client.field_1690.field_1904.method_23481(false);
            Autotpa.currentBotState = Autotpa.BotState.ESCAPE_RUNNING;
        }
    }

    private static void handleChorusEating(class_310 client) {
        if (client.field_1724 == null) return;
        client.field_1690.field_1832.method_23481(true);
        ensureTotem(client);

        int currentChorus = countItem(client, class_1802.field_8233);
        boolean hasTeleported = chorusStartPos != null && client.field_1724.method_5707(chorusStartPos) > 16.0;
        boolean hasEaten = currentChorus < chorusInitialCount;

        if (hasTeleported || hasEaten || stateTimerTicks <= 0) {
            client.field_1690.field_1904.method_23481(false);
            ensureSwordInHand(client);
            Autotpa.currentBotState = Autotpa.BotState.ESCAPE_RUNNING;
            restoreGappleToSlot4(client);
            initialPearlsThrown = 0;
            escapePearlTimer = 0;
            Autotpa.sendFeedback("§b[Escape] Хорус съеден! 2 броска перла...");
        } else {
            stateTimerTicks--;
            client.field_1690.field_1904.method_23481(true);
        }
    }

    private static void handleEscapeRunning(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        client.field_1690.field_1832.method_23481(true);
        ensureTotem(client);

        String master = AutoSellManager.getMasterName(client);

        if (escapeTpaCheckPos != null && client.field_1724.method_5707(escapeTpaCheckPos) > 1000000.0) {
            Autotpa.sendFeedback("§a[Escape] Успешный ТП к " + master + "! Выход на 1 мин...");
            escapeTpaCheckPos = null;
            escapeTpaSendTimer = 0;
            Autotpa.currentBotState = Autotpa.BotState.DISCONNECTED_WAITING;
            client.method_73360(class_2561.method_43470("Safe Exit (TPA Escape)"));
            reconnectSecondsLeft = 60;
            stateTimerTicks = 20;
            return;
        }

        boolean inWater = client.field_1724.method_5799() || client.field_1724.method_5869()
                || client.field_1687.method_8320(client.field_1724.method_24515()).method_27852(class_2246.field_10382);

        if (inWater) {
            client.field_1690.field_1832.method_23481(false); 
            client.field_1690.field_1903.method_23481(true);
            client.field_1690.field_1894.method_23481(true);
            client.field_1724.method_36457(-89.0f);
        } else {
            client.field_1690.field_1903.method_23481(false);
            client.field_1690.field_1894.method_23481(false);
            client.field_1690.field_1832.method_23481(true);
        }

        if (escapeTpaSendTimer > 0) {
            escapeTpaSendTimer--;
        } else {
            escapeTpaCheckPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
            CommandQueue.send("tpa " + master);
            escapeTpaSendTimer = 20;
        }

        boolean enemyNearby = false;
        for (class_742 p : client.field_1687.method_18456()) {
            if (p != client.field_1724 && p.method_5805() && !p.method_7325() && !FriendManager.isPlayerFriend(p)) {
                if (client.field_1724.method_5739(p) <= 10.0) {
                    enemyNearby = true;
                    break;
                }
            }
        }

        if (escapePearlTimer > 0) {
            escapePearlTimer--;
        } else {
            boolean canThrow = !client.field_1724.method_7357().method_7904(new class_1799(class_1802.field_8634));
            if (canThrow) {
                if (initialPearlsThrown < 2) {
                    if (throwEnderPearl(client)) {
                        initialPearlsThrown++;
                        escapePearlTimer = 35; 
                    }
                } else if (enemyNearby) {
                    if (throwEnderPearl(client)) {
                        escapePearlTimer = 35;
                    }
                }
            }
        }
    }

    private static void handleHome3AndLeave(class_310 client) {
        if (client.field_1724 == null) return;
        if (stateTimerTicks > 0) {
            stateTimerTicks--;
            if (preHome3Pos != null && client.field_1724.method_5707(preHome3Pos) > 225.0) {
                Autotpa.currentBotState = Autotpa.BotState.DISCONNECTED_WAITING;
                client.method_73360(class_2561.method_43470("Safe Exit (/home 3)"));
                reconnectSecondsLeft = 60;
                stateTimerTicks = 20;
            }
        } else {
            setCombatExpiration(System.currentTimeMillis() + 10000L);
            initialPearlsThrown = 0; 
            Autotpa.currentBotState = Autotpa.BotState.ESCAPE_RUNNING;
        }
    }

    public static class_742 findTarget(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return null;
        class_742 target = null;
        double min = 10.0;
        String master = AutoSellManager.getMasterName(client);

        for (class_742 p : client.field_1687.method_18456()) {
            if (p == client.field_1724 || !p.method_5805() || p.method_7325()) continue;
            String pName = p.method_5477().getString();
            if (pName.equalsIgnoreCase(master) || pName.equalsIgnoreCase("itzNatsuu") || pName.equalsIgnoreCase("obo_pro15")) continue;
            if (FriendManager.isPlayerFriend(p)) continue;

            double d = client.field_1724.method_5739(p);
            if (d <= 10.0 && d < min) {
                min = d;
                target = p;
            }
        }
        return target;
    }

    private static boolean handleEndermiteProtocol(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;
        if (currentEnemy != null || isCombatActive(client)) {
            wasCleaningEndermite = false;
            endermiteCobwebPos = null;
            return false;
        }

        class_1559 endermite = null;
        double minDist = 4.5;

        for (class_1559 e : client.field_1687.method_8390(class_1559.class, client.field_1724.method_5829().method_1014(4.0), e -> e.method_5805())) {
            double d = client.field_1724.method_5739(e);
            if (d < minDist) {
                minDist = d;
                endermite = e;
            }
        }

        if (endermite != null) {
            wasCleaningEndermite = true;
            class_2338 feetPos = getTrapFeetPos(client);

            if (feetPos != null && client.field_1687.method_8320(feetPos).method_27852(class_2246.field_10343)) {
                endermiteCobwebPos = feetPos;
                BlockInteractionHelper.breakBlockLegit(client, feetPos);
                return true;
            }

            ensureSwordInHand(client);
            aimAt(client, new class_243(endermite.method_23317(), endermite.method_23318() + 0.15, endermite.method_23321()));

            if (client.field_1724.method_7261(0.0f) >= 0.90f) {
                client.field_1761.method_2918(client.field_1724, endermite);
                client.field_1724.method_6104(class_1268.field_5808);
            }
            return true;
        }

        if (wasCleaningEndermite) {
            class_2338 targetWeb = (endermiteCobwebPos != null) ? endermiteCobwebPos : getTrapFeetPos(client);
            if (targetWeb != null && (client.field_1687.method_8320(targetWeb).method_26215() || client.field_1687.method_8320(targetWeb).method_45474())) {
                BlockInteractionHelper.placeBlockLegit(client, targetWeb, class_1802.field_8786);
            }
            wasCleaningEndermite = false;
            endermiteCobwebPos = null;
        }
        return false;
    }

    private static boolean aimAt(class_310 client, class_243 target) {
        if (client.field_1724 == null || client.field_1690 == null) return false;

        class_243 eye = client.field_1724.method_33571();
        double dx = target.field_1352 - eye.field_1352;
        double dy = target.field_1351 - eye.field_1351;
        double dz = target.field_1350 - eye.field_1350;
        double hDist = Math.sqrt(dx * dx + dz * dz);

        if (hDist < 0.15) return true;

        float targetYaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) class_3532.method_15338(-Math.toDegrees(Math.atan2(dy, hDist)));

        float currentYaw = client.field_1724.method_36454();
        float currentPitch = client.field_1724.method_36455();

        float deltaYaw = class_3532.method_15393(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;
        float angleDist = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);

        float speed = Math.min(32.0f, Math.max(6.0f, angleDist * 0.45f)) + (random.nextFloat() * 2.0f - 1.0f);
        float stepYaw = class_3532.method_15363(deltaYaw, -speed, speed);
        float stepPitch = class_3532.method_15363(deltaPitch, -speed, speed);

        double sensitivity = client.field_1690.method_42495().method_41753();
        double f = sensitivity * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;

        stepYaw = (float) (Math.round(stepYaw / gcd) * gcd);
        stepPitch = (float) (Math.round(stepPitch / gcd) * gcd);

        client.field_1724.method_36456(currentYaw + stepYaw);
        client.field_1724.method_36457(class_3532.method_15363(currentPitch + stepPitch, -90.0f, 90.0f));

        return Math.abs(deltaYaw) < 15.0f && Math.abs(deltaPitch) < 15.0f;
    }

    private static void ensureTotem(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        if (client.field_1724.method_6079().method_7909() != class_1802.field_8288) {
            for (int i = 9; i <= 35; i++) {
                if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8288)) {
                    int id = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(id, i, 0, class_1713.field_7790, client.field_1724);
                    client.field_1761.method_2906(id, 45, 0, class_1713.field_7790, client.field_1724);
                    break;
                }
            }
        }
    }

    public static boolean equipArmorFromInventory(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return false;

        boolean equippedAny = false;
        class_1304[] slots = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

        for (class_1304 slot : slots) {
            if (client.field_1724.method_6118(slot).method_7960()) {
                for (int i = 0; i <= 35; i++) {
                    class_1799 stack = client.field_1724.method_31548().method_5438(i);
                    if (stack.method_7960()) continue;

                    if (isArmorForSlot(stack, slot)) {
                        int syncId = client.field_1724.field_7498.field_7763;
                        int containerSlot = (i < 9) ? (36 + i) : i;
                        client.field_1761.method_2906(syncId, containerSlot, 0, class_1713.field_7794, client.field_1724);
                        equippedAny = true;
                        break;
                    }
                }
            }
        }
        return equippedAny;
    }

    private static boolean isArmorForSlot(class_1799 stack, class_1304 slot) {
        if (stack == null || stack.method_7960()) return false;
        String name = stack.method_7909().toString().toLowerCase();
        switch (slot) {
            case field_6169: return name.contains("helmet") || name.contains("cap");
            case field_6174: return name.contains("chestplate") || name.contains("tunic");
            case field_6172: return name.contains("leggings") || name.contains("pants");
            case field_6166: return name.contains("boots");
            default: return false;
        }
    }

    public static boolean isFullyArmored(class_310 client) {
        if (client.field_1724 == null) return false;
        class_1304[] slots = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
        for (class_1304 slot : slots) {
            if (client.field_1724.method_6118(slot).method_7960()) {
                return false;
            }
        }
        return true;
    }

    private static boolean handleGappleEatingProcess(class_310 client) {
        if (isEatingGapple) {
            gappleUseTimer++;
            selectHotbarSlot(client, 4);
            client.field_1690.field_1904.method_23481(true);

            boolean finishedNaturally = (gappleUseTimer > 10 && !client.field_1724.method_6115());
            if (gappleUseTimer >= 42 || finishedNaturally) {
                client.field_1690.field_1904.method_23481(false);
                isEatingGapple = false;
                gappleUseTimer = 0;
                gappleCooldown = 40; 
                selectHotbarSlot(client, 0);
                if (!isFinishingWithBow) ensureSwordInHand(client);
            }
            return true;
        }
        return false;
    }

    private static void checkAndEatGoldenApple(class_310 client) {
        if (client.field_1724 == null || isEatingGapple || isDrinkingPotion || isFinishingWithBow) return;
        restoreGappleToSlot4(client);
        if (gappleCooldown > 0) {
            gappleCooldown--;
            return;
        }

        float health = client.field_1724.method_6032();
        int food = client.field_1724.method_7344().method_7586();

        if (health <= 14.0f || food <= 12) {
            class_1799 slot4Stack = client.field_1724.method_31548().method_5438(4);
            if (slot4Stack.method_7909() == class_1802.field_8463 || slot4Stack.method_7909() == class_1802.field_8367) {
                isEatingGapple = true;
                gappleUseTimer = 0;
                selectHotbarSlot(client, 4);
                client.field_1690.field_1904.method_23481(true);
            }
        }
    }

    public static boolean isArmorNeedsMending(class_310 client) {
        if (client.field_1724 == null) return false;
        class_1304[] slots = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
        for (class_1304 slot : slots) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (!stack.method_7960() && stack.method_7963() && stack.method_7919() > (stack.method_7936() / 2)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isArmorNotFullyRepaired(class_310 client) {
        if (client.field_1724 == null) return false;
        class_1304[] slots = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
        for (class_1304 slot : slots) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (!stack.method_7960() && stack.method_7963() && stack.method_7919() > 0) {
                return true;
            }
        }
        return false;
    }

    public static final int SLOT_SWORD = 0;
    public static final int SLOT_COBWEB = 1;
    public static final int SLOT_AXE = 2;
    public static final int SLOT_PEARL = 3;
    public static final int SLOT_GAPPLE = 4;
    public static final int SLOT_WALL = 5;
    public static final int SLOT_BOW = 6;
    public static final int SLOT_PICKAXE = 7;
    public static final int SLOT_POTION = 8;

    private static boolean applyStrengthPotion(class_310 client) {
        if (potionBuffCooldown > 0 || isDrinkingPotion || isFinishingWithBow) {
            if (potionBuffCooldown > 0) potionBuffCooldown--;
            return false;
        }

        if (client.field_1724.method_6059(class_1294.field_5910)) return false;
        if (findFluidSourceInTrap(client) != null) return false;

        for (int i = 0; i <= 35; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (s.method_7960()) continue;

            if (isStrengthPotion(client, s)) {
                if (isEatingGapple) {
                    isEatingGapple = false;
                    gappleUseTimer = 0;
                    client.field_1690.field_1904.method_23481(false);
                }

                if (s.method_7909() == class_1802.field_8436) {
                    int prevSlot = client.field_1724.method_31548().method_67532();
                    if (i < 9) {
                        selectHotbarSlot(client, i);
                        client.field_1724.method_36457(89.0f);
                        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                        client.field_1724.method_6104(class_1268.field_5808);
                        selectHotbarSlot(client, prevSlot);
                    } else {
                        int syncId = client.field_1724.field_7498.field_7763;
                        client.field_1761.method_2906(syncId, i, SLOT_POTION, class_1713.field_7791, client.field_1724);
                        selectHotbarSlot(client, SLOT_POTION);
                        client.field_1724.method_36457(89.0f);
                        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                        client.field_1724.method_6104(class_1268.field_5808);
                        client.field_1761.method_2906(syncId, i, SLOT_POTION, class_1713.field_7791, client.field_1724);
                        selectHotbarSlot(client, prevSlot);
                    }
                    ensureSwordInHand(client);
                    potionBuffCooldown = 400;
                    return true;
                }

                if (i == SLOT_POTION) {
                    activePotionHotbarSlot = SLOT_POTION;
                    selectHotbarSlot(client, SLOT_POTION);
                    potionOriginalInventorySlot = -1;
                } else if (i < 9) {
                    activePotionHotbarSlot = i;
                    selectHotbarSlot(client, i);
                    potionOriginalInventorySlot = -1;
                } else {
                    int syncId = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(syncId, i, SLOT_POTION, class_1713.field_7791, client.field_1724);
                    activePotionHotbarSlot = SLOT_POTION;
                    selectHotbarSlot(client, SLOT_POTION);
                    potionOriginalInventorySlot = i;
                }

                client.field_1724.method_36457(-89.0f);
                isDrinkingPotion = true;
                potionDrinkTimer = 0;
                client.field_1690.field_1904.method_23481(true);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                return true;
            }
        }
        potionBuffCooldown = 40;
        return false;
    }
    // =========================================================================
    // АВТО-СУШКА ВОДЫ И ЛАВЫ СВЕРХУ: СТАВИМ ПАУТИНУ НА ПАУТИНУ
    // =========================================================================
    public static boolean handleTrapFluidDefense(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;
        class_2338 feetPos = getTrapFeetPos(client);
        if (feetPos == null) return false;

        class_2338 headPos = feetPos.method_10084();
        class_2338 aboveHeadPos = headPos.method_10084();

        boolean headHasFluid = hasFluid(client, headPos);
        boolean aboveHasFluid = hasFluid(client, aboveHeadPos);

        if (!headHasFluid && !aboveHasFluid) {
            return false;
        }

        // 1. Если жидкость на уровне головы — ставим паутину на паутину в ногах:
        if (headHasFluid || (aboveHasFluid && client.field_1687.method_8320(headPos).method_26215())) {
            if (BlockInteractionHelper.placeCobwebOnTopOf(client, feetPos)) {
                Autotpa.sendFeedback("§c[Trap] Лава/вода обнаружена! Сушу паутиной на голове...");
                return true;
            }
        }

        // 2. Если жидкость выше головы, а на голове уже есть паутина — ставим паутину на паутину головы:
        if (aboveHasFluid && client.field_1687.method_8320(headPos).method_27852(class_2246.field_10343)) {
            if (BlockInteractionHelper.placeCobwebOnTopOf(client, headPos)) {
                Autotpa.sendFeedback("§c[Trap] Сушу источник лавы/воды над головой!");
                return true;
            }
        }

        return false;
    }

    private static boolean hasFluid(class_310 client, class_2338 pos) {
        class_2680 state = client.field_1687.method_8320(pos);
        return state.method_27852(class_2246.field_10382) || state.method_27852(class_2246.field_10164) || !state.method_26227().method_15769();
    }
    private static boolean handleDrinkingPotionProcess(class_310 client) {
        if (isDrinkingPotion) {
            potionDrinkTimer++;
            selectHotbarSlot(client, activePotionHotbarSlot);
            client.field_1724.method_36457(-89.0f);
            client.field_1690.field_1904.method_23481(true);

            if (potionDrinkTimer == 1 || (potionDrinkTimer > 3 && !client.field_1724.method_6115())) {
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            }

            boolean hasStrength = client.field_1724.method_6059(class_1294.field_5910);
            boolean bottleAppeared = client.field_1724.method_31548().method_5438(activePotionHotbarSlot).method_31574(class_1802.field_8469);

            if (potionDrinkTimer >= 36 || (potionDrinkTimer >= 24 && (hasStrength || bottleAppeared))) {
                client.field_1690.field_1904.method_23481(false);
                isDrinkingPotion = false;
                potionDrinkTimer = 0;
                potionBuffCooldown = 400;

                if (potionOriginalInventorySlot != -1) {
                    int syncId = client.field_1724.field_7498.field_7763;
                    client.field_1761.method_2906(syncId, potionOriginalInventorySlot, SLOT_POTION, class_1713.field_7791, client.field_1724);
                    potionOriginalInventorySlot = -1;
                }

                selectHotbarSlot(client, SLOT_SWORD);
                ensureSwordInHand(client);
            }
            return true;
        }
        return false;
    }

    public static void restoreGappleToSlot4(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;
        class_1799 slot4Stack = client.field_1724.method_31548().method_5438(4);
        if (slot4Stack.method_31574(class_1802.field_8463) || slot4Stack.method_31574(class_1802.field_8367)) return;

        int syncId = client.field_1724.field_7498.field_7763;
        for (int i = 0; i <= 35; i++) {
            if (i == 4) continue;
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (s.method_31574(class_1802.field_8463) || s.method_31574(class_1802.field_8367)) {
                int containerSlot = (i < 9) ? (36 + i) : i;
                client.field_1761.method_2906(syncId, containerSlot, 4, class_1713.field_7791, client.field_1724);
                return;
            }
        }
    }

    private static boolean isStrengthPotion(class_310 client, class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        if (item != class_1802.field_8574 && item != class_1802.field_8436) return false;

        class_1844 contents = stack.method_58694(class_9334.field_49651);
        if (contents != null) {
            if (contents.comp_2378().isPresent()) {
                String id = contents.comp_2378().get().method_40230().map(k -> k.method_29177().method_12832().toLowerCase()).orElse("");
                if (id.contains("strength")) return true;
            }
            for (net.minecraft.class_1293 effect : contents.comp_2380()) {
                String effectId = effect.method_5579().method_55840().toLowerCase();
                if (effectId.contains("strength")) return true;
            }
        }
        String name = Autotpa.cleanText(stack.method_7964().getString()).toLowerCase();
        return name.contains("сил") || name.contains("strength");
    }

    private static class_243 getDynamicBodyAimPos(class_742 enemy) {
        float currentHeight = enemy.method_17682();
        aimDriftTimer--;
        if (aimDriftTimer <= 0) {
            aimDriftX = (random.nextDouble() - 0.5) * 0.25;
            aimDriftY = (random.nextDouble() - 0.5) * 0.20;
            aimDriftZ = (random.nextDouble() - 0.5) * 0.25;
            aimDriftTimer = 8 + random.nextInt(8);
        }
        double targetOffsetY = Math.max(0.25, currentHeight * 0.5) + aimDriftY;
        return new class_243(enemy.method_23317() + aimDriftX, enemy.method_23318() + targetOffsetY, enemy.method_23321() + aimDriftZ);
    }

    private static class_243 calculateBowAimPoint(class_310 client, class_742 enemy, int chargeTicks) {
        class_243 enemyCenter = getDynamicBodyAimPos(enemy);
        class_243 playerEyes = client.field_1724.method_33571();

        double dx = enemyCenter.field_1352 - playerEyes.field_1352;
        double dz = enemyCenter.field_1350 - playerEyes.field_1350;
        double hDist = Math.sqrt(dx * dx + dz * dz);

        float pull = Math.min((float) chargeTicks / 20.0f, 1.0f);
        float velocity = pull * 3.0f;
        if (velocity < 0.35f) velocity = 0.35f;

        double timeInAir = hDist / velocity;
        double drop = 0.5 * 0.05 * (timeInAir * timeInAir);

        return enemyCenter.method_1031(0, drop, 0);
    }

    private static class_2338 findFluidSourceInTrap(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return null;
        class_2338 playerPos = client.field_1724.method_24515();
        for (int y = 0; y <= 2; y++) {
            for (int x = -1; x <= 1; x++) {
                for (int z = -1; z <= 1; z++) {
                    class_2338 checkPos = playerPos.method_10069(x, y, z);
                    net.minecraft.class_3610 fluid = client.field_1687.method_8316(checkPos);
                    if (!fluid.method_15769() && fluid.method_15771()) return checkPos;
                }
            }
        }
        return null;
    }

    private static void selectHotbarSlot(class_310 client, int slotIndex) {
        if (client.field_1724 == null) return;
        if (client.field_1724.method_31548().method_67532() != slotIndex) {
            client.field_1724.method_31548().method_61496(slotIndex);
            if (client.method_1562() != null) {
                client.method_1562().method_52787(new net.minecraft.class_2868(slotIndex));
            }
        }
    }

    public static void releaseControls(class_310 client) {
        if (client.field_1690 != null) {
            client.field_1690.field_1894.method_23481(false);
            client.field_1690.field_1881.method_23481(false);
            client.field_1690.field_1913.method_23481(false);
            client.field_1690.field_1849.method_23481(false);
            client.field_1690.field_1904.method_23481(false);
            client.field_1690.field_1903.method_23481(false);
            client.field_1690.field_1832.method_23481(false);
            client.field_1690.field_1886.method_23481(false);
        }
    }

    private static int ensureChorusInHotbar(class_310 client) {
        if (client.field_1724 == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8233)) return i;
        }
        for (int i = 9; i <= 35; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8233)) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, 4, class_1713.field_7791, client.field_1724);
                return 4;
            }
        }
        return -1;
    }

    private static int ensurePearlsInHotbar(class_310 client) {
        if (client.field_1724 == null) return -1;
        if (client.field_1724.method_31548().method_5438(3).method_31574(class_1802.field_8634)) return 3;
        for (int i = 0; i < 9; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8634)) return i;
        }
        for (int i = 9; i <= 35; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8634)) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, 3, class_1713.field_7791, client.field_1724);
                return 3;
            }
        }
        return -1;
    }

    private static boolean throwEnderPearl(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return false;
        int pearlSlot = ensurePearlsInHotbar(client);
        if (pearlSlot == -1) return false;

        client.field_1724.method_31548().method_61496(pearlSlot);
        client.method_1562().method_52787(new class_2868(pearlSlot));

        float randomYaw = random.nextFloat() * 360.0f;
        float randomPitch = -(46.0f + random.nextFloat() * 14.0f);
        client.field_1724.method_36456(randomYaw);
        client.field_1724.method_36457(randomPitch);

        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
        client.field_1724.method_6104(class_1268.field_5808);
        return true;
    }

    // Сделан PUBLIC для AutoSellManager
    public static boolean ensureSwordInHand(class_310 client) {
        if (client.field_1724 == null) return false;
        class_1799 inHand = client.field_1724.method_6047();
        if (AutoSellManager.isMaxedSword(client, inHand)) return true;

        class_1799 slot0 = client.field_1724.method_31548().method_5438(0);
        if (AutoSellManager.isMaxedSword(client, slot0)) {
            selectHotbarSlot(client, 0);
            return true;
        }

        for (int i = 0; i < 9; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (AutoSellManager.isMaxedSword(client, s)) {
                selectHotbarSlot(client, i);
                return true;
            }
        }

        for (int i = 9; i <= 35; i++) {
            class_1799 s = client.field_1724.method_31548().method_5438(i);
            if (AutoSellManager.isMaxedSword(client, s)) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, 0, class_1713.field_7791, client.field_1724);
                selectHotbarSlot(client, 0);
                return true;
            }
        }

        if (inHand.method_7909().toString().toLowerCase().contains("sword")) return true;
        for (int i = 0; i < 9; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase().contains("sword")) {
                selectHotbarSlot(client, i);
                return true;
            }
        }
        for (int i = 9; i <= 35; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase().contains("sword")) {
                int syncId = client.field_1724.field_7498.field_7763;
                client.field_1761.method_2906(syncId, i, 0, class_1713.field_7791, client.field_1724);
                selectHotbarSlot(client, 0);
                return true;
            }
        }
        return false;
    }

    public static boolean isPlayerInsideTrap(class_742 player) {
        if (player == null || savedCobweb.isEmpty()) return false;
        for (class_2338 webPos : savedCobweb) {
            double dx = player.method_23317() - (webPos.method_10263() + 0.5);
            double dz = player.method_23321() - (webPos.method_10260() + 0.5);
            double hDist = Math.sqrt(dx * dx + dz * dz);
            double dy = player.method_23318() - webPos.method_10264();
            if (hDist <= 1.25 && dy >= -0.5 && dy <= 2.5) return true;
        }
        return false;
    }

    private static boolean checkCancelEscapeIfEnemyInTrap(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return false;
        class_742 enemyInside = null;
        boolean enemyOutside = false;

        for (class_742 p : client.field_1687.method_18456()) {
            if (p == client.field_1724 || !p.method_5805() || p.method_7325()) continue;
            if (FriendManager.isPlayerFriend(p)) continue;

            double dist = client.field_1724.method_5739(p);
            if (dist > 15.0) continue;

            if (isPlayerInsideTrap(p)) enemyInside = p;
            else enemyOutside = true;
        }

        if (enemyInside != null && !enemyOutside) {
            Autotpa.sendFeedback("§a§l[Escape Override] Враг в ловушке! Отмена побега -> В БОЙ!");
            Autotpa.currentBotState = Autotpa.BotState.IDLE_TRAPPING;
            client.field_1690.field_1904.method_23481(false);
            client.field_1690.field_1832.method_23481(false);
            restoreGappleToSlot4(client);
            ensureSwordInHand(client);
            stateTimerTicks = 0;
            escapeTpaSendTimer = 0;
            escapeTpaCheckPos = null;
            return true;
        }
        return false;
    }

    public static boolean hasSword(class_310 client) {
        if (client.field_1724 == null) return false;
        for (int i = 0; i <= 35; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7909().toString().toLowerCase().contains("sword")) return true;
        }
        return false;
    }

    public static int countItem(class_310 client, class_1792 item) {
        if (client.field_1724 == null) return 0;
        int total = 0;
        for (int i = 0; i < client.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(item)) total += stack.method_7947();
        }
        return total;
    }

    public static int getEmptySlotCount(class_310 client) {
        if (client == null || client.field_1724 == null) return 36;
        int empty = 0;
        for (int i = 9; i <= 35; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_7960()) empty++;
        }
        return empty;
    }

    public static void saveTrap(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        class_2338 p = client.field_1724.method_24515();
        savedWalls.clear();
        savedCobweb.clear();

        // 1 блок паутины строго под ногами игрока
        savedCobweb.add(p);

        // Сканируем окружающие стены 3x3 на высоту 2 блоков (уровень ног и уровень головы)
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                if (x == 0 && z == 0) continue;
                for (int y = 0; y <= 1; y++) {
                    class_2338 target = p.method_10069(x, y, z);
                    class_2680 s = client.field_1687.method_8320(target);
                    if (s.method_27852(class_2246.field_10443) || s.method_27852(class_2246.field_10540)) {
                        savedWalls.add(target);
                    }
                }
            }
        }
        saveTrapToFile();
        Autotpa.sendFeedback("§a[TrapBot] Ловушка 1x1 сохранена (Паутина: 1, Стены: " + savedWalls.size() + ", Без крыши)");
    }

    private static void saveTrapToFile() {
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(trapFile), StandardCharsets.UTF_8))) {
            for (class_2338 pos : savedWalls) { w.write("wall;" + pos.method_10263() + ";" + pos.method_10264() + ";" + pos.method_10260()); w.newLine(); }
            for (class_2338 pos : savedCobweb) { w.write("cobweb;" + pos.method_10263() + ";" + pos.method_10264() + ";" + pos.method_10260()); w.newLine(); }
        } catch (Exception ignored) {}
    }

    private static void loadTrap() {
        if (!trapFile.exists()) return;
        savedWalls.clear();
        savedCobweb.clear();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(trapFile), StandardCharsets.UTF_8))) {
            String l;
            while ((l = r.readLine()) != null) {
                String[] p = l.split(";");
                if (p.length >= 4) {
                    class_2338 pos = new class_2338(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]));
                    if (p[0].equals("wall") || p[0].equals("obsidian") || p[0].equals("ender_chest")) savedWalls.add(pos);
                    if (p[0].equals("cobweb")) savedCobweb.add(pos);
                }
            }
        } catch (Exception ignored) {}
    }

    public static void resetSession(class_310 client) {
        currentEnemy = null;
        lastCombatEnemy = null;
        swordCombatTimerTicks = 0;
        bowShotsFired = 0;
        isFinishingWithBow = false;
        isEatingGapple = false;
        isDrinkingPotion = false;
        combatRepairLockTicks = 0;
        isMending = false;
        isRepairingTrap = false;
        isVerifyingHome1 = false;
        activePotionHotbarSlot = 0;
        wasCleaningEndermite = false;
        endermiteCobwebPos = null;
        serverCombatSeconds = 0;
        combatExpiration = 0;
        postKillLootTimer = 0;
        needsAutoSellAfterKill = false;
        BlockInteractionHelper.stopBreaking(client);
        releaseControls(client);
    }
}